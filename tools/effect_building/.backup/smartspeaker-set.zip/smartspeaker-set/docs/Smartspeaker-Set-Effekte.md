# Smartspeaker-Set

* Die slugs / bezeichnungen unter denen die Effekte geführt werden sollen habe ich in Klammern dahinter geschrieben jeweils

## 1. States

### Bereit / Idle       (ready_state)

* **Effekt:** sanftes, langsames Atmen in Grün oder Blau
* **Bedeutung:** Gerät ist bereit, aber tut gerade nichts
* **Gut weil:** unaufdringlich

### Wartend       (waiting)

* **Effekt:** einzelner langsamer rotierender Punkt
* **Bedeutung:** wartet auf Eingabe / Ereignis
* **Alternative:** langsames cyan Pulsieren

### Verarbeitung       (processing)

* **Effekt:** mehrere Punkte drehen sich gleichmäßig
* **Bedeutung:** System arbeitet aktiv
* **Farbe:** Blau
* **Gut weil:** wirkt “maschinell beschäftigt”

### Netzwerk - reconnect       (reconnect_network_state)

* **Effekt:*** langsames Atmen in Gelb - heller und dunkler Gelbton abwechselnd (jede zweite led )
* **Bedeutung:** Server-Verbindung fehlt

### Mikrofon/Hardware - reconnect       (reconnect_mic_state)

* **Effekt:** langsames Atmen in Orange - heller und dunkler Orangeton abwechselnd (jede zweite led )
* **Bedeutung:** Mikrofon/Hardware - Verbindung fehlt

### Zuhören       (listening)

* **Effekt:** ruhiges Cyan/Blau-Atmen
* **Bedeutung:** Mikrofon aktiv, wartet auf Sprache

### Verstehen / Transkription läuft       (transcribe)

* **Effekt:** schneller, fokussierter blauer Rotations-Effekt
* **Bedeutung:** Sprache wird verarbeitet

### Antwort wird erzeugt       (thinking)

* **Effekt:** langsamer, gleichmäßiger Lila- oder Blau-Sweep
* **Bedeutung:** “denkt gerade”

### Spricht / Audioausgabe aktiv       (speaking)

* **Effekt:** audio-reaktiver Puls oder rhythmische Segmente
* **Bedeutung:** Gerät gibt Antwort aus

### Mikrofon stumm       (mic_mute)

* **Effekt:** statisches Rot oder rotes X-artiges Segmentmuster
* **Bedeutung:** Mic muted
* **Sehr wichtig**, falls du Sprachsteuerung planst

---

## 2. Overlays

### Fortschritt       (progress_ring)

* **Effekt:** Ring füllt sich proportional
* **Bedeutung:** klassischer Progress
* **Sehr sinnvoll:** einer der wichtigsten Effekte überhaupt

### Ladevorgang       (loading_spinner)

* **Effekt:** kreisender heller Abschnitt auf dunklem Hintergrund
* **Bedeutung:** unbestimmter Fortschritt

### Countdown / Timer       (countdown_ring)

* **Effekt:** Ring leert sich langsam im Uhrzeigersinn
* **Bedeutung:** Restzeit läuft ab
* **Zusatz:** letzte Sekunden schneller / Farbe wechselt von Grün → Gelb → Rot

### Warten auf Timeout       (timeout_segment)

* **Effekt:** langsames Abschmelzen eines Segments
* **Bedeutung:** etwas läuft ab, aber unkritisch

---

## 3.  Events

### Initialisierung / Start       (init_event)

* **Effekt:** Ring füllt sich von 0 auf 100 %, dann kurzer Weiß-Blitz
* **Bedeutung:** System startet / Module laden

### Verbunden       (connected_event)

* **Effekt:** kurzer grüner Rundlauf, dann aus oder soft idle
* **Bedeutung:** Verbindung erfolgreich hergestellt

### Erfolg       (success_event)

* **Effekt:** kurzer grüner Aufleucht-Impuls oder Ring einmal komplett grün
* **Bedeutung:** Aktion erfolgreich abgeschlossen

### Fehler       (error_event)

* **Effekt:** 2–3 schnelle rote Pulse
* **Bedeutung:** Aktion fehlgeschlagen
* **Optional:** bei kritischem Fehler zusätzlich kurze Pause und Wiederholung

### Warnung       (warn_event)

* **Effekt:** gelbes Blinken, aber langsamer und weniger aggressiv als Fehler
* **Bedeutung:** Achtung, aber nicht kritisch

### Neue Benachrichtigung       (notification_event)

* **Effekt:** kurzer farbiger Sweep oder 1–2 freundliche Pulse
* **Bedeutung:** neue Nachricht / Event / Hinweis
* **Farbe je nach Typ:** z. B. Cyan, Lila, Weiß

### Bestätigung       (confirm_event)

* **Effekt:** ein kurzer, weicher grüner Puls
* **Bedeutung:** Eingabe angenommen

### Ablehnung       (reject_event)

* **Effekt:** kurzer roter Gegenschlag / inverser Impuls
* **Bedeutung:** Eingabe nicht zulässig

### Sprache erkannt       (wakeword_detected)

* **Effekt:** kurze, reaktive Pegelanzeige oder kurzer Cyan-Blitz
* **Bedeutung:** Wake Word / Sprache erkannt

---
