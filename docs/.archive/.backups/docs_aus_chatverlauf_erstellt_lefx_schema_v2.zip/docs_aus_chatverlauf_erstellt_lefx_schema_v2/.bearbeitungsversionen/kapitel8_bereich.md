## Kapitel 8: Pakete, IDs und Presets

**Ziel:** Erklären, wie Definitionen verpackt, identifiziert, vorkonfiguriert und zu Sets zusammengestellt werden.

#-> Gliederung

1. Quelle gegenüber gebautem Paket
2. Anatomie eines LEFX-Pakets
3. Source-ID
4. Package-ID
5. Definition-ID
6. qualifizierte ID
7. Preset-ID
8. globale Namensräume
9. Preset-Auflösung
10. LEFXSET
11. thematische Paketsets
12. Versionen und Kompatibilität

**Schwerpunkte:**

- Ein LEFX-Paket enthält genau eine Definition.
- Definition- und Preset-IDs teilen einen global eindeutigen öffentlichen Namensraum.
- Die kurze ID ist die normale Benutzerform.
- Qualifizierte IDs dienen expliziten Quellenangaben und Diagnosen.
- Ein Preset enthält ausschließlich Konfiguration.
- Ein LEFXSET fügt kein Verhalten hinzu.
- Thematische Sets sind kuratierte Distributionen und keine technischen Effektkategorien.
- Buildbefehle folgen erst in Kapitel 10.

Für die spätere Überarbeitung der mitgelieferten Pakete würde ich Beispiele wie diese verwenden:

```text
core-states.lefxset
status-overlays.lefxset
notification-events.lefxset
respeaker-doa.lefxset
```

Das sind zunächst nur Veranschaulichungen und noch keine festgelegten Produktnamen.

**Entscheidungen:**

- **8A:** Kurze IDs als kanonische Benutzerform beibehalten? Empfehlung: Ja.
- **8B:** Definition- und Preset-IDs weiterhin global eindeutig halten? Empfehlung: Ja.
- **8C:** Qualifizierte IDs hauptsächlich für Diagnose und explizite Quellenauswahl erklären? Empfehlung: Ja.
- **8D:** Thematische LEFXSETs als kuratierte Auslieferungseinheiten behandeln, nicht als neue fachliche Typen? Empfehlung: Ja.
- **8E:** Die endgültigen Namen und Inhalte der produktiven Sets erst bei der anschließenden Effektüberarbeitung festlegen? Empfehlung: Ja.



### USER__019 -> Dokumentation - Kapitel 9-11: Bedienung (CLI/API), Validierung und Build, Architekturgrenzen

Also bei sechs stimme ich vollumfänglich zu und habe auch keine Anmerkungen. Bei Kapitel sieben würde ich sagen, da würde ich dir auch großenteils zustimmen. Aber ich würde bei den, bei den Beispielen für die Overlays würde ich auch noch ein ganz normales Beispiel wie so einen Countdown oder so eine Lautstärkeregelung oder sowas nehmen. Vielleicht meintest du das auch. So, zu Kapitel 8 wäre es mir tatsächlich am liebsten, wenn wir die Presets ein bisschen in den Hintergrund rücken, als, ich sag mal, als Vorschläge und eher in den Vordergrund drücken, dass man auch seine eigenen Werte setzen kann, damit das nicht so hinten überfällt bei den Presets. Weil dann der Eindruck entstehen kann, die Presets hätten wir jetzt extra vorbereitet. Aber eigentlich soll die Hauptfunktion sein, dass man da frei ist. Die Presets, die sind halt nur so eine Empfehlung mehr oder weniger. Und das würde die dann vielleicht ein bisschen unauffälliger machen. Wäre ein Punkt. Und ja, der Rest kann bei 8 eigentlich auch so bleiben.


