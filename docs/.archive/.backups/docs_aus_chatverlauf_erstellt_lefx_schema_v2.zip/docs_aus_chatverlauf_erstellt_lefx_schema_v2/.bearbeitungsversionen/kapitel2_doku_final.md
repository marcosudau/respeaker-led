# Kapitel 2: Begriffe und Systemobjekte

**Geltungsbereich:** LED-Controller / LEFX Schema V2

**Ziel:** Nach diesem Kapitel ist eindeutig, ob über eine bearbeitbare Quelle, ein gebautes Paket, eine Definition, eine Konfiguration oder eine laufende Instanz gesprochen wird.

Kapitel 1 ist laut Dokumentationsfahrplan inhaltlich freigegeben. Dieses Kapitel führt die verbindlichen Begriffe und Systemobjekte ein. Vollständige Schema- und Lifecycle-Regeln werden hier bewusst noch nicht erklärt; sie folgen in den nachfolgenden Kapiteln.

## 1. Warum feste Begriffe notwendig sind

- Das Wort „Effekt“ wurde historisch für verschiedene Dinge verwendet.
- Daraus entstanden Missverständnisse zwischen Datei, Definition, Preset und laufender Ausführung.
- V2 verwendet deshalb präzise Begriffe.
- Derselbe Begriff muss in Dokumentation, Fehlermeldungen, CLI und API dieselbe Bedeutung besitzen.

Die folgende Übersicht führt die in diesem Kapitel verbindlich eingeführten Begriffe auf; jeder Begriff wird in seinem eigenen Abschnitt definiert:

| Begriff | Bedeutung in V2 |
|---|---|
| LEFX-Quelle | bearbeitbares Verzeichnis, aus dem ein LEFX-Paket gebaut wird |
| LEFX-Paket | gebautes `.lefx`-Artefakt mit genau einer vollständigen Definition |
| Definition | Beschreibung eines State, eines Overlay oder eines Event |
| Preset | benannte, paketinterne Vorkonfiguration genau einer Definition |
| Konfiguration | beim Aktivieren aufgelöste Werte für die Instanz |
| Runtime-Eingaben | während der Laufzeit veränderliche Werte |
| Steuerungskommando | gewünschte Operation, die vor jeder Runtime-Änderung vollständig validiert wird |
| Laufende Instanz | konkrete Aktivierung einer Definition |
| Overlay-Channel | eindeutiger Runtime-Name einer kontrollierten Overlay-Instanz |
| Layer | von der Engine verwaltete interne Kompositionsstufe für LED-Frames |
| LEFXSET | Distributionspaket, das mehrere eigenständige LEFX-Pakete zusammenfasst |

## 2. Die Objektkette (Quelle → Paket → Definition → Instanz)

Die Objektkette ist die zentrale Darstellung des Kapitels. Sie zeigt, wie aus einer Quelle über das Paket und die Definition eine laufende Instanz entsteht:

```mermaid
flowchart LR
    A["LEFX-Quelle"] -->|"Build"| B["LEFX-Paket"]
    B -->|"Laden"| C["Registrierte Definition"]
    C -->|"Steuerungskommando + Konfiguration"| D["Laufende Instanz"]
    E["Preset"] -->|"Vorkonfiguration"| C
    F["Runtime-Eingaben"] -->|"Aktualisierung"| D
```

Wichtig dabei:

- Die Quelle ist bearbeitbar.
- Das Paket ist das gebaute, unveränderliche Artefakt.
- Die Definition beschreibt Möglichkeiten und Regeln.
- Die Instanz ist die konkrete laufende Ausführung.
- Presets konfigurieren eine Definition.
- Runtime-Eingaben verändern eine laufende kontrollierte Overlay-Instanz.

### Drei Kategorien: Container, Beschreibung, Ausführung

Die Objektkette ordnet sich in drei Kategorien, die strikt zu unterscheiden sind:

- **Container:** Quelle und Paket — sie halten Inhalte, führen selbst aber nichts aus.
- **Beschreibung:** die Definition — sie legt Möglichkeiten und Regeln fest, ohne ausgeführt zu werden.
- **Ausführung:** die laufende Instanz — sie ist die konkrete Ausführung zur Laufzeit.

```mermaid
flowchart TB
    subgraph Container["Container"]
        A["LEFX-Quelle"] -->|"Build"| B["LEFX-Paket"]
    end
    subgraph Beschreibung["Beschreibung"]
        C["Definition"]
    end
    subgraph Ausfuehrung["Ausführung"]
        D["Laufende Instanz"]
    end
    B -->|"Laden"| C
    C -->|"Steuerungskommando + Konfiguration"| D
    E["Preset"] -->|"Vorkonfiguration"| C
    F["Runtime-Eingaben"] -->|"Aktualisierung"| D
```

| Objekt | Kategorie | Eigenschaft | Rolle |
|---|---|---|---|
| LEFX-Quelle | Container | bearbeitbar | Ausgangsmaterial, aus dem ein Paket gebaut wird |
| LEFX-Paket | Container | gebaut, unveränderlich | ausgeliefertes Artefakt mit genau einer Definition |
| Definition | Beschreibung | keine laufende Ausführung | beschreibt Möglichkeiten und Regeln |
| Laufende Instanz | Ausführung | konkrete Aktivierung | laufende Ausführung mit aufgelöster Konfiguration |

## 3. LEFX-Quelle

> **Verbindliche Definition:** Eine LEFX-Quelle ist das bearbeitbare Verzeichnis, aus dem ein LEFX-Paket gebaut wird.

Sie enthält beispielsweise:

- `effect.yaml`
- `effect.py`
- `presets.yaml`
- lokale Module
- Assets

**Wichtig:** Die Quelle ist nicht das ausgelieferte Paket und keine laufende Instanz.

## 4. LEFX-Paket

> **Verbindliche Definition:** Ein LEFX-Paket ist ein gebautes `.lefx`-Artefakt, das genau eine vollständige State-, Overlay- oder Event-Definition enthält.

Das Paket besitzt:

- Definition und Schema
- Renderlogik
- Metadaten
- optionale Presets
- lokale Assets und Module

**Sprachliche Festlegung:** **LEFX-Paket** ist der Standardbegriff. Der Begriff **Artefakt** kommt nur zum Einsatz, wenn ausdrücklich über ein Build-Ergebnis gesprochen wird.

## 5. Definition

Der Begriff **Effektdefinition** wird an dieser Stelle einmalig eingeführt und im Folgenden durchgängig zur Kurzform **Definition** verkürzt.

> **Verbindliche Definition:** Eine Definition beschreibt einen State, ein Overlay oder ein Event, aber noch keine laufende Ausführung.

Sie enthält:

- Typ
- Metadaten
- Konfigurationsschema
- gegebenenfalls Runtime-Input-Schema
- Defaults
- Capabilities
- Layer- und Lifecycle-Vertrag
- visuelle Merkmale

Wichtige Abgrenzung:

- Die Definition enthält keinen aktiven Runtime-Zustand.
- Die Renderlogik gehört zum Paket.
- Eine Definition wird durch ein Preset nicht zu einem anderen Typ.

## 6. Preset

> **Verbindliche Definition:** Ein Preset ist eine benannte, paketinterne Vorkonfiguration genau einer Definition.

Ein Preset darf:

- Farben auswählen
- Geschwindigkeit setzen
- Helligkeit konfigurieren
- andere deklarierte Konfigurationswerte vorbelegen

Ein Preset darf nicht:

- aus einem State ein Event machen
- den Overlay-Modus verändern
- andere Layer auswählen
- Runtime-Eingaben enthalten
- eine eigene Definition darstellen

**Kernaussage:** Ein Preset ist keine Unterart einer Definition.

## 7. Konfiguration und Runtime-Eingaben

Konfiguration und Runtime-Eingaben werden bereits an dieser Stelle getrennt, weil sie sich in Herkunft, Lebensdauer und Wirkung grundlegend unterscheiden:

| Konfiguration | Runtime-Eingaben |
|---|---|
| wird beim Aktivieren aufgelöst | verändert sich während der Laufzeit |
| stammt aus Defaults, Preset und Overrides | stammt aus Push- oder Pull-Daten |
| bleibt für die Instanz stabil | darf kontrollierte Overlays aktualisieren |
| beispielsweise Farbe oder Geschwindigkeit | beispielsweise Richtung oder Fortschritt |

Besonders relevant ist diese Unterscheidung für DoA:

```text
color = Konfiguration
direction_deg = Runtime-Eingabe
```

## 8. Steuerungskommando

> **Verbindliche Definition:** Ein Steuerungskommando beschreibt eine gewünschte Operation, die vor jeder Runtime-Änderung vollständig validiert wird.

Beispiele:

- State setzen
- Overlay öffnen
- Overlay aktualisieren
- Event auslösen
- Instanz entfernen

**Sprachliche Festlegung:** Der normale Begriff ist **Steuerungskommando**. Der technische Begriff `Request` wird nur ergänzend genannt und gehört in die technische Referenz.

## 9. Laufende Instanz

> **Verbindliche Definition:** Eine laufende Instanz ist die konkrete Aktivierung einer Definition mit aufgelöster Konfiguration, Startzeit, Lebenszyklusdaten und gegebenenfalls Runtime-Eingaben.

Wichtig:

- Definition und Instanz sind getrennt.
- Eine Definition kann nacheinander mehrfach instanziiert werden.
- Events können als getrennte Instanzen in der Queue liegen.
- Kontrollierte Overlays werden über ihren Channel adressiert.

Der interne Klassenname `EffectInvocation` wird in diesem allgemeinen Kapitel nicht verwendet; er gehört in die technische Referenz.

## 10. Overlay-Channel

> **Verbindliche Definition:** Ein Overlay-Channel ist der eindeutige Runtime-Name einer kontrollierten Overlay-Instanz.

Er dient zum:

- Aktualisieren
- Senden eines Lebenszeichens
- Schließen der Instanz

Ein Channel ist:

- keine Definition-ID
- keine Package-ID
- kein Layer
- kein Preset

Der Overlay-Channel ist damit eine **Runtime-Adresse**: Er benennt eine konkrete laufende Instanz, nicht eine Definition oder ein Paket.

```mermaid
flowchart LR
    S["Steuerungskommando"] -->|"adressiert"| CH["Overlay-Channel"]
    CH -->|"identifiziert"| I["Kontrollierte Overlay-Instanz"]
```

## 11. Layer

> **Verbindliche Definition:** Ein Layer ist eine von der Engine verwaltete interne Kompositionsstufe für LED-Frames.

An dieser Stelle wird nur der Begriff eingeführt. Noch nicht erklärt werden:

- vollständige Layerliste
- Prioritäten
- Queue-Verhalten
- Persistenz

Das folgt in Kapitel 4.

## 12. LEFXSET

> **Verbindliche Definition:** Ein LEFXSET ist ein Distributionspaket, das mehrere bereits eigenständige LEFX-Pakete zusammenfasst.

Wichtig:

- Es fügt kein neues Verhalten hinzu.
- Es verändert keine Definition.
- Es ist keine übergeordnete Definition mit mehreren Unterdefinitionen.
- Seine Mitglieder bleiben getrennte Definitionen.

## 13. IDs und Namensräume

In diesem Kapitel werden nur die Arten von IDs und Namensräumen eingeführt:

| ID-Art | Bezug |
|---|---|
| Definition-ID | identifiziert eine Definition |
| Preset-ID | identifiziert ein Preset |
| Source-ID | identifiziert eine LEFX-Quelle |
| Package-ID | identifiziert ein LEFX-Paket |
| qualifizierte ID | Namensraum-gebundene ID-Form |
| Overlay-Channel | Runtime-Name einer kontrollierten Overlay-Instanz |

Die Auflösungsregeln und die globale Eindeutigkeit folgen ausführlich in Kapitel 8.

## 14. Sprachregel „Effekt“

| Begriff | Verwendung |
|---|---|
| **Effektsystem** | bleibt der Oberbegriff |
| **Effektentwicklung** | darf als allgemeiner Tätigkeitsbegriff verwendet werden |
| **Effektpaket** | akzeptabel, wenn eindeutig ein LEFX-Paket gemeint ist |
| **Effekt** (alleinstehend) | wird in technischen Aussagen vermieden |

Stattdessen werden State, Overlay, Event, Definition, Paket, Preset oder Instanz verwendet.

Beispiel:

```text
Ungenau:
Der Effekt wird aktualisiert.

Präzise:
Die Runtime-Eingaben der kontrollierten Overlay-Instanz werden aktualisiert.
```

## 15. Veraltete Begriffe

Alte Planungsunterlagen aus V1 verwenden Begriffe, die in V2 keine Entsprechung mehr haben (beispielsweise „generischer Effekt“ oder „Embedded Command“). Eine Übersetzungstabelle der veralteten V1-Begriffe mit ihren V2-Entsprechungen wird im **Archivbereich** gepflegt; sie ist nicht Bestandteil der aktuellen Dokumentation. Beim Lesen alter Planungsunterlagen sollte die Übersetzungstabelle im Archivbereich zu Rate gezogen werden.

## Entscheidungen zu Kapitel 2

Die folgenden Festlegungen gelten verbindlich für dieses Kapitel und die gesamte Dokumentation:

1. **LEFX-Paket** ist der Standardbegriff. Der Begriff **Artefakt** wird ausschließlich im Build-Kontext verwendet.
2. Der Begriff **Effektdefinition** wird einmalig eingeführt (Abschnitt 5); anschließend wird durchgängig die Kurzform **Definition** verwendet.
3. Deutsche Begriffe sind die Norm: **laufende Instanz** und **Steuerungskommando**. Technische Namen wie `EffectInvocation` und `Request` erscheinen ausschließlich in der technischen Referenz.
4. **Steuerungskommando** ist der normale Begriff — nicht „Steueranfrage“. Der technische Begriff `Request` wird nur ergänzend genannt.
5. Das einzelne Wort **Effekt** wird in technischen Aussagen vermieden.
6. Die Übersetzungstabelle der veralteten V1-Begriffe gehört in den **Archivbereich** und nicht in die aktuelle Dokumentation. Dieses Kapitel erwähnt ihre Existenz und verweist darauf; sie dient als historische Übersetzung und nicht als Migrationsunterstützung.
