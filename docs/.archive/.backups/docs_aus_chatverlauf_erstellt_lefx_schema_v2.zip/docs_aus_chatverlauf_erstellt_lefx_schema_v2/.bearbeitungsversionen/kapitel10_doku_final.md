# Kapitel 10: Validierung und Build

**Geltungsbereich:** LED-Controller / LEFX Schema V2

**Ziel:** Den Weg von einer bearbeitbaren Quelle zu einem geprüften Distributionspaket erklären.

**Hinweis:** Dieses Dokument enthält Kapitel 10 der technischen Dokumentation zum LED-Controller (LEFX Schema V2). Kapitel 1, 2, 3, 6, 7 und 8 sind laut Dokumentationsfahrplan inhaltlich freigegeben; die dort eingeführten Begriffe werden hier als bekannt vorausgesetzt und verwendet.

Kapitel 10 beschreibt die Build-Pipeline vollständig: von der Validierung der bearbeitbaren Quelle über die einzelnen Prüfschritte bis zum gebauten und verifizierten LEFX-Paket sowie der optionalen Aufnahme in ein LEFXSET. Die verbindlichen Definitionen der Begriffe Quelle, LEFX-Paket und LEFXSET enthält Kapitel 2. Dieses Kapitel legt fest, wie aus einer Quelle ein geprüftes Distributionspaket entsteht und welche Qualitätsgrenzen dabei gelten.

## 1. Qualitätsgrenze des Builds

Der Build ist die Qualitätsgrenze zwischen dem bearbeitbaren Zustand und dem ausgelieferten Artefakt. Alles links dieser Grenze darf verändert werden; alles rechts davon ist ein gebautes Ergebnis, das nicht mehr als Quelle dient.

Für das Build-Verzeichnis gelten folgende verbindliche Grundsätze:

- `build/` enthält ausschließlich reproduzierbare Ergebnisse.
- Autoritative Quellen liegen niemals unter `build/`.
- Fertige Ausgaben und temporäre Zwischenstände werden klar unterschieden.
- Ein LEFXSET wird bevorzugt aus bereits geprüften LEFX-Paketen gebaut (Abschnitt 8).
- Standard- und Fremdpakete verwenden dieselben grundlegenden Prüfschritte (Abschnitt 9).
- Der Smoke-Render ergänzt Tests, ersetzt sie aber nicht (Abschnitt 5).
- Zwischen-Caches werden nach erfolgreichem Build entfernt (Abschnitt 10).

### Die Build-Pipeline

Der gesamte Ablauf folgt einer festen Reihenfolge. Jeder Schritt hat eine eindeutige Eingabe und eine eindeutige Ausgabe; ein Schritt beginnt erst, wenn der vorherige bestanden ist:

```text
Quelle
→ validieren
→ importieren
→ Vertrag prüfen
→ Probe-Frame rendern
→ LEFX bauen
→ LEFX verifizieren
→ optional in LEFXSET aufnehmen
```

Die Pipeline als Ablaufdiagramm:

```mermaid
flowchart LR
    Q["Quelle"]
    V["validieren"]
    I["importieren"]
    K["Vertrag prüfen"]
    R["Probe-Frame rendern"]
    B["LEFX bauen"]
    P["LEFX verifizieren"]
    S["optional in LEFXSET aufnehmen"]
    Q --> V --> I --> K --> R --> B --> P --> S
```

Die Schritte 2 bis 7 sind Pflichtschritte. Der letzte Schritt ist optional: Er findet nur statt, wenn das geprüfte LEFX-Paket in ein LEFXSET aufgenommen werden soll.

### Verbindliche Build-Checkliste

Zusätzlich zum erklärenden Text gilt die folgende kompakte Checkliste verbindlich für jeden Build. Sie fasst die Pipeline in sieben Prüfschritte zusammen; die Erläuterungen folgen in den Abschnitten 2 bis 8:

| # | Prüfschritt | Prüfgegenstand | Akzeptanzkriterium | Abschnitt |
|---|---|---|---|---|
| 1 | Quellenvalidierung | Quelle | Die Quelle ist vollständig und konsistent; die Validierung ergibt keinen Befund | 2 |
| 2 | Import- und Strukturprüfung | importierter Inhalt | Der Import ist fehlerfrei; die Struktur entspricht der Erwartung | 3 |
| 3 | Schema- und Vertragsprüfung | Schema und Vertrag | Die Definition entspricht dem Schema und dem Vertrag vollständig | 4 |
| 4 | Smoke-Render | Renderpfad | Der Probe-Frame wird plausibel gerendert | 5 |
| 5 | LEFX-Build | Paket | Das LEFX-Paket ist gebaut | 6 |
| 6 | Paketverifikation | gebautes LEFX-Paket | Die Verifikation ist bestanden; das Paket gilt als geprüft | 7 |
| 7 | Aufnahme in LEFXSET (optional) | LEFXSET | Es werden ausschließlich geprüfte LEFX-Pakete aufgenommen | 8 |

Ein Build ist erst dann abgeschlossen, wenn alle Pflichtschritte der Checkliste bestanden sind.

## 2. Quellenvalidierung

Die Quelle ist der bearbeitbare Ausgangspunkt eines Builds; der Begriff ist in Kapitel 2 verbindlich definiert. Die Quellenvalidierung ist der erste Schritt der Pipeline. Sie prüft die Quelle in ihrem bearbeitbaren Zustand, bevor irgendetwas importiert oder gebaut wird.

Zweck der Quellenvalidierung:

- Befunde so früh wie möglich erkennen, bevor Folgeprüfungen laufen
- entscheiden, ob die Quelle überhaupt in die Pipeline eintreten darf
- fehlerhafte Quellen vom weiteren Ablauf ausschließen

Die Validierung betrachtet die Quelle als Ganzes: Vollständigkeit, Konsistenz und inhaltliche Stimmigkeit. Ein Befund in der Quellenvalidierung stoppt den Build vor dem Import; die späteren Schritte werden nicht erreicht.

## 3. Import- und Strukturprüfung

Erst nach bestandener Quellenvalidierung wird die Quelle importiert. Der Import überführt die bearbeitbare Quelle in einen geprüften, weiterverarbeitbaren Zustand.

Die anschließende Strukturprüfung stellt fest, ob der importierte Inhalt der erwarteten Struktur entspricht. Geprüft wird dabei die Anordnung und Zuordnung der Bestandteile; die inhaltliche Bedeutung wird an dieser Stelle noch nicht beurteilt. Das leistet der nächste Schritt.

Wichtig:

- Der importierte Zustand ist ein temporärer Zwischenstand, keine fertige Ausgabe.
- Ein Befund in der Strukturprüfung betrifft die Struktur des Imports.
- Der Build wird bei einem Befund vor der Vertragsprüfung abgebrochen.

## 4. Schema- und Vertragsprüfung

Der dritte Schritt prüft, ob die Definition dem Schema und dem Vertrag entspricht. Dabei sind zwei Ebenen zu unterscheiden:

- **Schema:** Die Definition muss formal gültig sein, das heißt dem vorgegebenen Schema entsprechen.
- **Vertrag:** Die Definition muss die zugesicherten Regeln erfüllen, die an die jeweilige Art der Definition geknüpft sind.

Die Prüfung ist verbindlich. Eine Abweichung vom Schema oder vom Vertrag führt zum Abbruch des Builds. Erst nach bestandener Schema- und Vertragsprüfung darf der Renderpfad betreten werden.

## 5. Smoke-Render

Der Smoke-Render erzeugt einen Probe-Frame mit der Renderlogik der Definition. Der Probe-Frame dient als früher, sichtbarer Nachweis, dass der Renderpfad grundsätzlich funktioniert.

Grundsätze des Smoke-Renders:

- Der Smoke-Render ergänzt Tests, ersetzt sie aber nicht.
- Ein erfolgreicher Probe-Frame ist ein Indiz für einen funktionierenden Renderpfad, kein vollständiger Nachweis der Korrektheit.
- Offensichtliche Renderfehler werden an dieser Stelle erkannt und stoppen den Build vor dem Bauen.
- Der erzeugte Probe-Frame ist ein temporärer Zwischenstand, keine fertige Ausgabe.

## 6. LEFX-Build

Der Build überführt den geprüften Zwischenstand in ein LEFX-Paket. Ein LEFX-Paket ist ein gebautes `.lefx`-Artefakt mit genau einer vollständigen Definition; die Definition des Begriffs enthält Kapitel 2.

Gebaut wird ausschließlich, wenn alle vorherigen Schritte bestanden sind:

```text
Quelle validiert
→ Import und Struktur geprüft
→ Schema und Vertrag geprüft
→ Probe-Frame gerendert
→ LEFX bauen
```

Das Ergebnis des Builds ist das Artefakt, das im nächsten Schritt verifiziert wird. In kanonischer Kurzform:

```json
{
  "schritt": "LEFX bauen",
  "eingabe": "geprüfter Zwischenstand",
  "ausgabe": "LEFX-Paket (.lefx)"
}
```

Vollständige Formate und die zugehörigen Befehle dokumentiert der Entwicklerbereich (Entscheidung 10B).

## 7. Paketverifikation

Nach dem Bauen wird das gebaute LEFX-Paket verifiziert. Die Verifikation prüft das Artefakt selbst; die Quelle wird an dieser Stelle nicht erneut geprüft.

Grundsätze der Paketverifikation:

- Ein LEFX-Paket gilt erst nach bestandener Verifikation als geprüftes Distributionspaket.
- Ein Paket, das die Verifikation nicht besteht, wird nicht weitergegeben.
- Ein nicht verifiziertes Paket wird nicht in ein LEFXSET aufgenommen.

In kanonischer Kurzform:

```json
{
  "schritt": "LEFX verifizieren",
  "eingabe": "LEFX-Paket",
  "status": "geprüft"
}
```

## 8. LEFXSET aus vorgebauten LEFX-Paketen

Ein LEFXSET ist ein Distributionspaket, das mehrere eigenständige LEFX-Pakete zusammenfasst; die Definition des Begriffs enthält Kapitel 2.

Verbindliche Vorgehensweise: Ein LEFXSET wird bevorzugt aus bereits geprüften LEFX-Paketen gebaut. Das bedeutet:

- Die Mitglieder werden nicht erneut gebaut.
- Die Mitglieder sind bereits verifiziert; das LEFXSET wiederholt keine Inhaltsprüfungen.
- Das LEFXSET fügt kein Verhalten hinzu und verändert keine Definition; seine Mitglieder bleiben getrennte Definitionen (Kapitel 2).

```mermaid
flowchart LR
    P1["LEFX-Paket (geprüft)"] --> S["LEFXSET"]
    P2["LEFX-Paket (geprüft)"] --> S
    P3["LEFX-Paket (geprüft)"] --> S
```

In kanonischer Kurzform:

```json
{
  "schritt": "in LEFXSET aufnehmen",
  "eingabe": ["geprüftes LEFX-Paket", "geprüftes LEFX-Paket"],
  "ausgabe": "LEFXSET"
}
```

## 9. Standard-Build

Der Standard-Build ist der reguläre Ablauf: Eine Quelle durchläuft die vollständige Pipeline von der Validierung bis zum verifizierten LEFX-Paket. Er entspricht damit exakt der in Abschnitt 1 dargestellten Pipeline und der verbindlichen Build-Checkliste.

Für Standard- und Fremdpakete gilt derselbe Maßstab:

| Aspekt | Standard-Paket | Fremdpaket |
|---|---|---|
| Herkunft der Quelle | aus dem Standard-Bestand | von außerhalb bereitgestellt |
| Grundlegende Prüfschritte | identisch | identisch |
| Ergebnis bei bestandener Prüfung | geprüftes LEFX-Paket | geprüftes LEFX-Paket |

Der Unterschied zwischen Standard- und Fremdpaketen liegt ausschließlich in der Herkunft der Quelle. An der Prüfkette ändert sich dadurch nichts: Beide verwenden dieselben grundlegenden Prüfschritte.

## 10. Cache und Cleanup

Während eines Builds entstehen Zwischenstände und temporäre Dateien: der importierte Zustand, der gerenderte Probe-Frame und weitere temporäre Zwischenstände. Diese sind keine fertigen Ausgaben.

Verbindliche Regeln:

- Zwischen-Caches werden nach erfolgreichem Build entfernt.
- Fertige Ausgaben und temporäre Zwischenstände werden klar unterschieden.
- Unter `build/` verbleiben ausschließlich reproduzierbare Ergebnisse, also fertige Ausgaben.

Das Cache-Verhalten im Überblick:

| Zwischenstand | Zweck | Lebensdauer | Entfernung |
|---|---|---|---|
| Importzustand | Grundlage der Strukturprüfung | bis zur Vertragsprüfung | nach erfolgreichem Build |
| gerenderter Probe-Frame | Nachweis des Smoke-Renders | bis zur Paketverifikation | nach erfolgreichem Build |
| temporäre Build-Dateien | Zwischenspeicher während des Bauens | bis zum Abschluss des Builds | nach erfolgreichem Build |
| fertige Ausgaben unter `build/` | reproduzierbare Ergebnisse | dauerhaft | werden nicht entfernt |

## 11. Typische Fehler

Fehler werden nach Quelle, Schema, Import, Render und Paketstruktur gruppiert. Die Gruppierung bestimmt, an welcher Stelle der Build abgebrochen wird und welcher Prüfschritt die Ursache erkannt hat:

```mermaid
flowchart TD
    F{"Fehler beim Build?"} -->|"nein"| OK["LEFX-Paket gilt als geprüft"]
    F -->|"ja"| G{"Wo tritt der Fehler auf?"}
    G -->|"Quelle"| G1["Gruppe Quelle – Abbruch vor dem Import"]
    G -->|"Import"| G2["Gruppe Import – Abbruch vor der Vertragsprüfung"]
    G -->|"Schema"| G3["Gruppe Schema – Abbruch vor dem Render"]
    G -->|"Render"| G4["Gruppe Render – Abbruch vor dem Build"]
    G -->|"Paketstruktur"| G5["Gruppe Paketstruktur – Paket gilt nicht als geprüft"]
```

Die Fehlergruppen im Überblick:

| Gruppe | Erkennung in Schritt | Beispiele typischer Befunde | Konsequenz |
|---|---|---|---|
| Quelle | Quellenvalidierung (Abschnitt 2) | unvollständige Quelle; widersprüchliche Angaben; fehlende Bestandteile | Abbruch vor dem Import |
| Import | Import- und Strukturprüfung (Abschnitt 3) | Struktur entspricht nicht der Erwartung; Bestandteile nicht zuordenbar; unerwartete Inhalte | Abbruch vor der Vertragsprüfung |
| Schema | Schema- und Vertragsprüfung (Abschnitt 4) | Definition verletzt das Schema; Vertrag wird nicht erfüllt | Abbruch vor dem Render |
| Render | Smoke-Render (Abschnitt 5) | Probe-Frame nicht plausibel; Renderlauf schlägt fehl | Abbruch vor dem Build |
| Paketstruktur | Paketverifikation (Abschnitt 7) | gebautes Paket unvollständig; Paketstruktur verletzt; Inhalt fehlt | Paket gilt nicht als geprüft; keine Aufnahme in ein LEFXSET |

Jeder Befund wird genau einer Gruppe zugeordnet. Nach Behebung der Ursache läuft der Build erneut durch die Pipeline; die Reihenfolge der Prüfschritte bleibt dabei unverändert.

## Entscheidungen zu Kapitel 10

Die folgenden Festlegungen gelten verbindlich für dieses Kapitel:

1. **Verbindliche Build-Checkliste (10A):** Eine kompakte verbindliche Build-Checkliste ergänzt den erklärenden Text. Sie steht in Abschnitt 1 und gilt für jeden Build; die zugehörigen Erläuterungen folgen in den Abschnitten 2 bis 8.
2. **Befehle im Entwicklerbereich (10B):** Befehle und vollständige Formate werden nur einmal vollständig im Entwicklerbereich dokumentiert. Dieses Kapitel erklärt den Ablauf und zeigt ausschließlich kanonische Kurzausschnitte.
3. **Fehlergruppen (10C):** Fehler werden nach Quelle, Schema, Import, Render und Paketstruktur gruppiert. Die Zuordnung und die Konsequenzen stehen in Abschnitt 11.
