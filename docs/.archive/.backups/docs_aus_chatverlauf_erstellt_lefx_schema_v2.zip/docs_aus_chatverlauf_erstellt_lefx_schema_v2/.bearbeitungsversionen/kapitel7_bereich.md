## Kapitel 7: Runtime-Eingaben

**Ziel:** Den vollständigen Datenweg kontrollierter Overlays erklären, ohne Push und Pull zu Untertypen aufzuwerten.

#-> Gliederung

1. Konfiguration gegenüber Runtime-Eingabe
2. Warum nur kontrollierte Overlays mutable Eingaben besitzen
3. Overlay-Channel
4. Push als Bezugsmodus
5. Pull als Bezugsmodus
6. Sampling-Intervall
7. Heartbeat und Karenzzeit
8. Input-Health
9. fehlende Werte und `None`
10. DoA-Datenfluss
11. Verantwortungsgrenze zur Integration

Push:

```text
Externe Integration
→ Channel-Update
→ Validierung
→ laufende Overlay-Instanz
→ render()
```

Pull:

```text
Engine-Zeitplan
→ sample_inputs()
→ Validierung
→ laufende Overlay-Instanz
→ render()
```

**Schwerpunkte:**

- Push und Pull betreffen nur die Herkunft der Runtime-Eingaben.
- `render()` erzeugt unabhängig davon den Frame.
- Ein leeres Push-Update ist ein Lebenszeichen und behält vorhandene Werte.
- Erfolgreiche Eingänge aktualisieren einen engine-eigenen Empfangszeitpunkt.
- Während der Karenzzeit bleibt der letzte gültige Wert bestehen.
- Nach Ablauf erhält der Renderer für deklarierte Eingaben `None`.
- Die Definition entscheidet, wie fehlende Daten dargestellt werden.
- USB- und Hardwarelogik bleibt in der Integration.

**Entscheidungen:**

- **7A:** Allgemein von „Bezugsmodus für Runtime-Eingaben“ sprechen und `InputMode.PUSH/PULL` technisch ergänzen? Empfehlung: Ja.
- **7B:** Standard-Heartbeat `1000 ms × 3` erklären, aber als durch die Definition anpassbare Policy darstellen? Empfehlung: Ja.
- **7C:** DoA als durchgängiges Push-Beispiel und ein neutrales Sensorszenario als Pull-Beispiel verwenden? Empfehlung: Ja.
- **7D:** Deutlich sagen, dass die Engine Empfangsgesundheit bewertet, nicht die fachliche Qualität eines Messwertes? Empfehlung: Ja.

