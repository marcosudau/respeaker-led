# Kapitel 6: Parameter und Werte

> **Dokumentationsstand:** Kapitel 1 und 2 sind laut Dokumentationsfahrplan inhaltlich freigegeben, Kapitel 3–5 sind validiert; dieses Dokument enthält Kapitel 6.

**Ziel:** Erklären, welche Werte Definitionen anbieten, wie Eingaben benutzerfreundlich angenommen und intern strikt vereinheitlicht werden.

> **Hinweis zur Abgrenzung:** Push und Pull werden erst in Kapitel 7 als Bezugsmodi für Runtime-Eingaben behandelt und sind daher in diesem Kapitel nicht Gegenstand.

---

## 6.1 Aufgabe eines Parameters

Ein Parameter ist die benannte Stelle, an der eine Definition einen Wert aufnimmt. Über Parameter wird festgelegt, mit welchen Werten eine **laufende Instanz** arbeitet: Helligkeit, Geschwindigkeit, Richtung, Winkel, Fortschritt, Lebensdauer sowie die Farbwerte.

Ein Parameter verbindet drei Ebenen:

- **Definition:** Sie legt fest, welche Parameter es gibt und welche Defaults sie tragen.
- **Steuerungskommando:** Es liefert zur Laufzeit explizite Werte für die Parameter.
- **Laufende Instanz:** Sie arbeitet ausschließlich mit den aufgelösten, kanonischen Werten.

Daraus ergibt sich die zentrale Doppelaufgabe dieses Kapitels: Eingaben werden an der Systemgrenze benutzerfreundlich angenommen (tolerante Eingabegrenze), intern jedoch strikt vereinheitlicht (strenges Datenmodell). Beide Seiten sind klar getrennt (siehe Abschnitte 6.6 bis 6.8).

## 6.2 Konfigurationsauflösung

Die Werte eines Parameters entstehen nicht unmittelbar aus einer einzigen Quelle, sondern aus einer festen Auflösungsreihenfolge. Sie lautet wörtlich:

```text
Definition-Defaults
→ Preset
→ explizite Werte des Steuerungskommandos
→ Validierung und Kanonisierung
```

Die vier Stufen im Einzelnen:

1. **Definition-Defaults:** Die Definition liefert die Grundeinstellung für jeden ihrer Parameter.
2. **Preset:** Eine vorgefertigte Konfiguration überschreibt die Defaults der Definition.
3. **Explizite Werte des Steuerungskommandos:** Werte, die ein Steuerungskommando ausdrücklich mitgibt, haben Vorrang vor Preset und Defaults.
4. **Validierung und Kanonisierung:** Die letzte Stufe prüft die aufgelösten Werte und überführt sie in die kanonische interne Darstellung. Erst danach gelten sie für die laufende Instanz.

```mermaid
flowchart LR
    A[Definition-Defaults] --> B[Preset]
    B --> C[explizite Werte des Steuerungskommandos]
    C --> D[Validierung und Kanonisierung]
    D --> E[kanonische Werte für die laufende Instanz]
```

## 6.3 Verpflichtende und optionale Werte

Parameterwerte sind grundsätzlich **optional**: Fehlt ein Wert im Steuerungskommando, wird er aus dem Preset oder aus den Definition-Defaults aufgelöst. Die Auflösungsreihenfolge aus Abschnitt 6.2 stellt sicher, dass immer ein Wert vorhanden ist.

**Verpflichtend** wird ein Wert nur dann, wenn das zugehörige Merkmal an der Definition vorhanden ist. Es gibt keine pauschal verpflichtenden Parameter — die Pflicht entsteht erst aus dem Merkmal (siehe Abschnitt 6.4). Fehlt ein verpflichtender Wert, wird die Konfiguration in der Validierungsstufe abgewiesen (siehe Abschnitt 6.8); eine stillschweigende Ersetzung findet nicht statt.

## 6.4 Standardparameter

Standardparameter sind die Werte, die nur bei Vorhandensein des passenden Merkmals verlangt werden. Die folgende Matrix ordnet jedem Merkmal den zugehörigen Standardparameter zu:

| Merkmal der Definition | verpflichtender Standardparameter |
|---|---|
| farbige Definition | `brightness` |
| animierte Definition | `speed` |
| gerichtete Definition | `reverse` |
| Winkel | `direction_deg` |
| Fortschritt | `progress` |
| endliche Lebensdauer | `duration_ms` oder `total_ms` |

Zwei Besonderheiten:

- **`speed` ist ein Multiplikator der entworfenen Grundgeschwindigkeit, keine FPS-Angabe.** Ein Wert von 2 bedeutet die doppelte Grundgeschwindigkeit, ein Wert von 0,5 die halbe. Die Angabe sagt nichts über Bildwiederholraten aus.
- Bei endlicher Lebensdauer wird entweder `duration_ms` **oder** `total_ms` verlangt; die beiden Größen decken gemeinsam das Merkmal ab.

## 6.5 Farbmodelle

Farbmodelle legen fest, wie viele und welche Farbwerte eine Definition trägt. Jedes unterstützte Modell wird getrennt erklärt; die Beispiele sind illustrativ für die Wertgestalt und verwenden die kanonische `#RRGGBB`-Darstellung (siehe Abschnitt 6.7).

| Farbmodell | Bedeutung | kleines Beispiel |
|---|---|---|
| `none` | keine Farbkomponente; die Definition trägt keinen Farbwert | `none` |
| `mono` | genau eine Farbe | `mono`, `#0000FF` |
| `dual` | zwei Farben | `dual`, `#0000FF` und `#FFFFFF` |
| `palette` | mehrere Farben aus einer Palette | `palette`, drei Farbwerte |
| `gradient` | ein Verlauf zwischen Farben | `gradient`, von `#0000FF` zu `#FFFFFF` |
| `random_range` | Zufallsfarbe aus einem Bereich | `random_range` mit `random_seed` |

Für `random_range` gilt: Zufallsfarben bleiben durch **`random_seed` reproduzierbar**. Derselbe Seed ergibt dieselbe Farbwahl; damit sind Zufallsfarben in der laufenden Instanz nachvollziehbar und wiederholbar.

## 6.6 Komfortnotationen und Aliase

An der Systemgrenze ist die Eingabe bewusst tolerant. Benutzer dürfen für dieselbe Farbe unterschiedliche Notationen verwenden, beispielsweise `blau`, `blue`, `#0000FF` oder `0x0000FF`. Intern existiert nur der kanonische Wert.

**Aliase gelten nur an der Systemgrenze:** Sie werden ausschließlich bei der Annahme von Eingaben aufgelöst. Nach der Kanonisierung spielen sie keine Rolle mehr — interne Verarbeitung und Renderer sehen ausschließlich kanonische Werte.

Der Alias-Bestand wird als Referenztabelle geführt (deutsche Namen → englische Namen → kanonischer `#RRGGBB`-Wert) statt als lange Liste im Fließtext:

| deutscher Name | englischer Name | kanonischer Wert |
|---|---|---|
| blau | blue | `#0000FF` |
| rot | red | `#FF0000` |
| grün | green | `#00FF00` |
| gelb | yellow | `#FFFF00` |
| weiß | white | `#FFFFFF` |
| schwarz | black | `#000000` |

Die Tabelle zeigt die Struktur des Alias-Bestands; weitere Einträge folgen demselben Muster und werden an derselben Stelle gepflegt. Maßgeblich ist immer der kanonische Wert in der rechten Spalte.

## 6.7 Kanonische interne Werte

Nach der Auflösung aller Notationen und Aliase hält das System ausschließlich die **kanonische Darstellung**. `blau`, `blue`, `#0000FF` und `0x0000FF` münden in genau einen internen Wert (`#0000FF`); die eingegebene Schreibweise wird nicht weitergereicht.

Daraus folgt eine verbindliche Regel für die Darstellungsschicht: **Renderer sollen nicht erneut eigene Eingabeparser erfinden.** Parsen, Alias-Auflösung und Normalisierung sind ausschließlich Aufgabe der Eingabegrenze; Renderer empfangen bereits kanonisierte Werte und werten diese direkt aus.

```mermaid
flowchart LR
    A[Benutzereingabe: blau, blue, #0000FF, 0x0000FF] --> B[Alias-Auflösung an der Systemgrenze]
    B --> C[Validierung]
    C --> D[Kanonisierung]
    D --> E[kanonischer Wert: #0000FF]
    E --> F[laufende Instanz]
    F --> G[Renderer ohne eigenen Eingabeparser]
    C --> H[Abweisung bei mehrdeutigen oder unbekannten Werten]
```

## 6.8 Grenzen und Validierungsfehler

Zwischen der toleranten Eingabegrenze und dem strengen internen Datenmodell wird klar getrennt. Die Toleranz endet an der Systemgrenze: **Mehrdeutige und unbekannte Werte werden abgewiesen.**

- **Mehrdeutig** ist ein Wert, der sich nicht eindeutig einem Alias oder kanonischen Wert zuordnen lässt.
- **Unbekannt** ist ein Wert, für den weder Alias noch kanonische Entsprechung existiert.
- Ebenso abgewiesen wird eine Konfiguration, der ein verpflichtender Standardparameter fehlt (siehe Abschnitte 6.3 und 6.4).

Die Abweisung erfolgt in der Validierungsstufe der Konfigurationsauflösung (Abschnitt 6.2), bevor irgendein Wert in eine laufende Instanz gelangt. Es findet keine stillschweigende Korrektur oder Ersetzung statt — ein abgewiesener Wert erreicht das interne Datenmodell nicht.

```mermaid
flowchart LR
    subgraph Eingabegrenze [tolerante Eingabegrenze]
        A[blau]
        B[blue]
        C[#0000FF]
        D[0x0000FF]
    end
    E[Validierung und Kanonisierung]
    subgraph Intern [strenges internes Datenmodell]
        F[kanonischer Wert: #0000FF]
    end
    A --> E
    B --> E
    C --> E
    D --> E
    E --> F
```

---

## Entscheidungen zu Kapitel 6

Die folgenden Festlegungen sind verbindlich:

- **6A — Standardparameter nur bei passendem Merkmal verpflichtend:** Festgelegt. Standardparameter werden ausschließlich dann verlangt, wenn das zugehörige Merkmal vorhanden ist: `brightness` (farbige Definition), `speed` (animierte Definition), `reverse` (gerichtete Definition), `direction_deg` (Winkel), `progress` (Fortschritt), `duration_ms` oder `total_ms` (endliche Lebensdauer).
- **6B — Alle unterstützten Farbmodelle mit Beispiel:** Festgelegt. Die Farbmodelle `none`, `mono`, `dual`, `palette`, `gradient` und `random_range` werden jeweils mit einem kleinen Beispiel dargestellt (Abschnitt 6.5).
- **6C — Farbalias-Tabelle als Referenztabelle:** Festgelegt. Der Alias-Bestand wird als eigene Referenztabelle geführt (deutsche Namen → englische Namen → kanonischer `#RRGGBB`-Wert) statt als lange Liste im Fließtext (Abschnitt 6.6).
- **6D — Trennung Eingabegrenze und internes Datenmodell:** Festgelegt. Zwischen der toleranten Eingabegrenze und dem strengen internen Datenmodell wird klar getrennt; Aliase gelten nur an der Systemgrenze, intern existiert ausschließlich der kanonische Wert (Abschnitte 6.6 bis 6.8).
