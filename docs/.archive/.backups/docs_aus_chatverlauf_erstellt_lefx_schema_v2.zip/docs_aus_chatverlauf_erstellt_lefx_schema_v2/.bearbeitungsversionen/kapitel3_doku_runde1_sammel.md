# LEFX – Dokumentation Kapitel 3 bis 5 (Schema V2)

> **Hinweis zum Dokumentationsstand:** Kapitel 1 und 2 sind laut Dokumentationsfahrplan inhaltlich freigegeben. Dieses Dokument enthält die Kapitel 3 (Layer und Komposition), 4 (Typen und Lebenszyklen) und 5 (Schema V2) in der verbindlichen Ziel-Reihenfolge.

**Hinweis zur Reihenfolge und zu Push/Pull (Nutzerentscheidung USER__018):** Das Layer-Prinzip (Kapitel 3) steht vor dem Typenverständnis (Kapitel 4), weil die übereinanderliegenden Layer die Grundlage für das Verständnis der Typen bilden. Push und Pull sind keine Untervarianten des kontrollierten Overlays, sondern **Bezugsmodi für Runtime-Eingaben**: Sie beschreiben einen Aspekt davon, wie die Engine Frames bezieht. Das kontrollierte Overlay bleibt ein Typ mit zwei Bezugsmodi.

**Faktenbasis:** Alle Aussagen dieses Dokuments stammen ausschließlich aus `kapitel3_bereich.md` (Abschnitte AGENT_017 und USER__018). Es wurden keine externen Fakten ergänzt.

---

# Kapitel 3: Layer und Komposition

**Ziel:** Verständlich zeigen, wie laufende Instanzen angeordnet, ersetzt, aktualisiert und beendet werden.

## Gliederung

1. Layer als interne Engine-Struktur
2. Prioritätsstapel
3. Background State und Primary State
4. Setzen, Ersetzen und Löschen eines States
5. Lifecycle eines kontrollierten Overlays
6. Lifecycle eines zeitgesteuerten Overlays
7. Event-Queue
8. Transparenz und Komposition
9. Rückkehr zum darunterliegenden Bild
10. Verantwortung der Engine

## 3.1 Layer als interne Engine-Struktur

Layer sind eine interne Struktur der Engine. Sie ordnen die laufenden Instanzen vertikal an und bestimmen, welche Anzeige über welcher anderen liegt. Aufrufer wählen keine beliebigen Layer: Die öffentliche freie Layerauswahl ist ausdrücklich ausgeschlossen. Welche Ebene eine Instanz erhält, bestimmen der Typ der Definition und – bei Overlays – der Overlay-Modus; die Platzierung geschieht damit vollständig innerhalb der Engine.

Die Lesbarkeit steht an erster Stelle: Im Dialog werden die lesbaren Schichtnamen verwendet, die technischen Enum-Namen stehen ergänzend dabei. Die folgende Tabelle ordnet beides zu.

| Lesbarer Name | Technischer Enum-Name |
|---|---|
| Event | `EVENT_LAYER` |
| Controlled Overlay | `ONGOING_OVERLAY_LAYER` |
| Timed Overlay | `TEMP_OVERLAY_LAYER` |
| Primary State | `STATE_LAYER` |
| Background State | `BACKGROUND_STATE_LAYER` |

## 3.2 Prioritätsstapel

Der Layer-Stapel ist ein fester Prioritätsstapel. Seine Reihenfolge von oben nach unten ist verbindlich:

```text
Event                  (EVENT_LAYER)
Controlled Overlay     (ONGOING_OVERLAY_LAYER)
Timed Overlay          (TEMP_OVERLAY_LAYER)
Primary State          (STATE_LAYER)
Background State       (BACKGROUND_STATE_LAYER)
```

Die Reihenfolge wird bewusst beibehalten, insbesondere Controlled Overlay über Timed Overlay: Eine laufende Funktionsanzeige bleibt sichtbar, während darunter zeitlich begrenzte Anzeigen laufen. Wirklich priorisierte Unterbrechungen gehören nicht in die Overlay-Ebenen, sondern auf die Event-Ebene ganz oben.

Die Ebenen liegen übereinander; obere Ebenen werden über den unteren komponiert. Die Ebenen können dabei transparent sein: Transparente Frames geben den darunterliegenden Wert frei (siehe Abschnitt 3.8).

```mermaid
flowchart TB
    E["Event (EVENT_LAYER)"]
    CO["Controlled Overlay (ONGOING_OVERLAY_LAYER)"]
    TO["Timed Overlay (TEMP_OVERLAY_LAYER)"]
    PS["Primary State (STATE_LAYER)"]
    BS["Background State (BACKGROUND_STATE_LAYER)"]
    N["Hinweis: Die Ebenen liegen übereinander; jede Ebene kann transparente Frames liefern (None = darunterliegenden Wert erhalten)."]
    E --- CO
    CO --- TO
    TO --- PS
    PS --- BS
    N -.-> E
    classDef top fill:#fce4ec,stroke:#b71c1c;
    classDef overlay fill:#e3f2fd,stroke:#0d47a1;
    classDef state fill:#e8f5e9,stroke:#1b5e20;
    class E top;
    class CO,TO overlay;
    class PS,BS state;
```

*Schaubild 3.1: Layer-Stapel von oben nach unten mit lesbaren Namen und ergänzenden Enum-Namen.*

## 3.3 Background State und Primary State

Der Stapel kennt zwei unterschiedliche State-Plätze: Background State und Primary State. Sie sind zwei getrennte Ebenen, keine Varianten desselben Platzes. Der Background State bildet die unterste Ebene des Stapels, der Primary State liegt darüber. Die beiden Plätze bleiben auch dann getrennt, wenn nur einer von ihnen belegt ist.

## 3.4 Setzen, Ersetzen und Löschen eines States

States werden über Steuerungskommandos geführt. Es gibt drei Kommandos:

| Steuerungskommando | Wirkung |
|---|---|
| Setzen | platziert einen State auf dem vorgesehenen State-Platz |
| Ersetzen | tauscht die laufende Instanz auf dem State-Platz aus |
| Löschen | beendet die laufende Instanz auf dem State-Platz |

```mermaid
sequenceDiagram
    participant A as Aufrufer
    participant E as Engine
    Note over E: Stapel mit Background State und Primary State
    A->>E: Steuerungskommando „State setzen“
    E->>E: platziert den State auf dem State-Platz
    A->>E: Steuerungskommando „State ersetzen“
    E->>E: ersetzt die laufende Instanz auf dem State-Platz
    A->>E: Steuerungskommando „State löschen“
    E->>E: beendet die Instanz; das darunterliegende Bild wird sichtbar
```

*Schaubild 3.2: Ablauf der Steuerungskommandos für einen State.*

Zeitachse des States – die Lebensdauer der Instanz ist unbestimmt; die Kommandos Setzen, Ersetzen und Löschen markieren die Eingriffe:

```mermaid
gantt
    title Lebenszyklus: State (Zeitachse)
    dateFormat X
    axisFormat %s
    section Lebensdauer der Instanz
    Instanz aktiv (unbestimmt): 0, 100
    section Steuerungskommandos
    Setzen: 0, 0
    Ersetzen: 40, 40
    Löschen: 80, 80
```

*Schaubild 3.3: Zeitachse des States mit Steuerungskommandos.*

## 3.5 Lifecycle eines kontrollierten Overlays

Für jede Lebenszyklusform sind drei Zeitdimensionen zu trennen: die Lebensdauer der Instanz, die zeitliche Animation ihres Frames und die Aktualisierung ihrer Runtime-Eingaben.

| Zeitdimension | Bedeutung |
|---|---|
| Lebensdauer einer Instanz | wie lange die laufende Instanz existiert |
| zeitliche Animation ihres Frames | wie sich das Frame im Verlauf der Zeit entwickelt |
| Aktualisierung ihrer Runtime-Eingaben | ob Eingaben während der Laufzeit geändert werden können |

Ein kontrolliertes Overlay hat eine unbestimmte Lebensdauer: Die Instanz bleibt, bis sie beendet wird. Ihre Frames entwickeln sich zeitlich (Animation). Ihre Runtime-Eingaben können während der Laufzeit aktualisiert werden; Push und Pull beschreiben, wie die Engine die Frames bezieht (siehe Kapitel 4, Abschnitt 4.3).

```mermaid
gantt
    title Lebenszyklus: kontrolliertes Overlay (Zeitachse)
    dateFormat X
    axisFormat %s
    section Lebensdauer der Instanz
    Instanz aktiv (unbestimmt): 0, 100
    section Zeitliche Animation des Frames
    Frames entwickeln sich zeitlich: 0, 100
    section Aktualisierung der Runtime-Eingaben
    Eingaben aktualisierbar: 0, 100
```

*Schaubild 3.4: Zeitachse des kontrollierten Overlays mit den drei getrennten Zeitdimensionen.*

## 3.6 Lifecycle eines zeitgesteuerten Overlays

Ein zeitgesteuertes Overlay hat eine endliche Lebensdauer. Nach der Aktivierung ist es nicht aktualisierbar; die Engine beendet die Instanz am Ende der Laufzeit. Auch hier sind die drei Zeitdimensionen getrennt zu betrachten: Die Instanz lebt endlich, die Frames entwickeln sich zeitlich, und die Runtime-Eingaben werden nicht aktualisiert.

```mermaid
gantt
    title Lebenszyklus: zeitgesteuertes Overlay (Zeitachse)
    dateFormat X
    axisFormat %s
    section Lebensdauer der Instanz
    Instanz aktiv (endlich): 0, 30
    section Zeitliche Animation des Frames
    Frames entwickeln sich zeitlich: 0, 30
    section Aktualisierung der Runtime-Eingaben
    nach Aktivierung nicht aktualisierbar: 0, 30
```

*Schaubild 3.5: Zeitachse des zeitgesteuerten Overlays.*

## 3.7 Event-Queue

Events sind endlich, priorisiert und nicht nachträglich veränderbar. Die Engine verwaltet die Event-Queue; Events erreichen über sie die oberste Ebene des Stapels, die Event-Ebene. Als priorisierte Unterbrechungen liegen Events über allen anderen Ebenen.

```mermaid
gantt
    title Lebenszyklus: Event (Zeitachse)
    dateFormat X
    axisFormat %s
    section Lebensdauer der Instanz
    Instanz aktiv (endlich, priorisiert): 0, 8
    section Aktualisierung
    nicht nachträglich veränderbar: 0, 8
    section Zustellung
    Eingang über die Event-Queue: 0, 0
```

*Schaubild 3.6: Zeitachse des Events.*

## 3.8 Transparenz und Komposition

Die Ebenen des Stapels werden übereinander komponiert; einzelne Ebenen können transparent sein. `None` bedeutet bei transparenten Frames: darunterliegenden Wert erhalten. Ein transparentes Frame einer oberen Ebene gibt damit den Farbwert der darunterliegenden Ebene frei, statt ihn zu überdecken.

```mermaid
flowchart LR
    subgraph S["Ausschnitt des Stapels (von oben nach unten)"]
        direction TB
        A["Controlled Overlay — Frame = None (transparent)"]
        B["Timed Overlay — Frame mit Farbwert"]
        C["Primary State — Frame mit Farbwert"]
        A --- B --- C
    end
    R["Sichtbares Bild: Der transparente Frame des Controlled Overlays gibt den Farbwert des Timed Overlays frei."]
    S --> R
```

*Schaubild 3.7: Komposition mit transparentem Frame; `None` erhält den darunterliegenden Wert.*

## 3.9 Rückkehr zum darunterliegenden Bild

Wird eine laufende Instanz beendet oder gelöscht, fällt ihre Ebene weg und das darunterliegende Bild wird wieder sichtbar. Das gilt für alle Ebenen: Endet ein Overlay, erscheint darunter der State; wird ein State gelöscht, erscheint darunter der jeweils andere State-Platz beziehungsweise der Background State.

## 3.10 Verantwortung der Engine

Die Engine trägt die Verantwortung für den Lebenszyklus im Stapel:

- Sie beendet endliche Instanzen (zeitgesteuerte Overlays und Events) selbst.
- Sie verwaltet die Event-Queue.
- Sie führt die Komposition der übereinanderliegenden Ebenen aus.
- Sie bestimmt die Platzierung jeder Instanz – Aufrufer wählen keine Layer.

Ein Paket besitzt keinen parallelen Lifecycle: Pakete führen keinen eigenen Lebenszyklus neben den laufenden Instanzen.

## Entscheidungen zu Kapitel 3

1. **Reihenfolge beibehalten:** Controlled Overlay liegt über Timed Overlay. Wirklich priorisierte Unterbrechungen gehören auf die Event-Ebene.
2. **Öffentliche freie Layerauswahl ausgeschlossen:** Aufrufer wählen keine beliebigen Layer; Typ und Overlay-Modus bestimmen die interne Platzierung.
3. **Layer als interne Engine-Struktur:** Die Erklärung erfolgt mit einem Schaubild der übereinanderliegenden, auch transparenten Layer (Schaubilder 3.1 und 3.7).

---

# Kapitel 4: Typen und Lebenszyklen

**Ziel:** Der Leser soll sicher entscheiden können, welcher Typ und welcher Lebenszyklus zu seiner Anzeige passt.

## Gliederung

1. Vergleichsmatrix aller Lebenszyklusformen
2. State
3. Kontrolliertes Overlay (Push/Pull als Bezugsmodi)
4. Zeitgesteuertes Overlay
5. Event
6. Entscheidungshilfe
7. Ungültige Kombinationen

## 4.1 Vergleichsmatrix aller Lebenszyklusformen

Es gibt drei fachliche Typen – State, Overlay und Event –, aber vier deutlich dargestellte Lebenszyklusformen, weil das Overlay in zwei Modi auftritt. Die Lebenszyklus-Matrix ist verbindlich:

| Typ | Modus | Laufzeit | Runtime-Eingaben |
|---|---|---|---|
| State | immer kontrolliert | unbestimmt | nein |
| Overlay | `controlled` | unbestimmt | ja |
| Overlay | `timed` | endlich | nein |
| Event | fest vorgegeben | endlich | nein |

Die zentrale Tabelle zeigt darüber hinaus die weiteren Aspekte der Lebenszyklusformen: Zweck, Lebensdauer, Aktivierung, Aktualisierbarkeit, Beendigung, Runtime-Eingaben, Channel, Queue und Komposition.

| Aspekt | State | Kontrolliertes Overlay | Zeitgesteuertes Overlay | Event |
|---|---|---|---|---|
| Zweck | Grunddarstellung über zwei State-Plätze | laufende Funktionsanzeige | zeitlich begrenzte Anzeige | priorisierte Unterbrechung |
| Lebensdauer | unbestimmt | unbestimmt | endlich | endlich |
| Aktivierung | Setzen per Steuerungskommando | Aktivierung | Aktivierung | Eingang über die Event-Queue |
| Aktualisierbarkeit | Ersetzen per Steuerungskommando | Runtime-Eingaben aktualisierbar | nach der Aktivierung nicht aktualisierbar | nicht nachträglich veränderbar |
| Beendigung | Löschen per Steuerungskommando | — | durch die Engine (endliche Laufzeit) | durch die Engine (endliche Laufzeit) |
| Runtime-Eingaben | nein | ja (Bezugsmodi Push und Pull) | nein | nein |
| Channel | — | Push/Pull (Bezug der Frames) | — | — |
| Queue | — | — | — | Event-Queue |
| Komposition | unterste Ebenen des Stapels | über dem zeitgesteuerten Overlay | unter dem kontrollierten Overlay | oberste Ebene (Event-Ebene) |

> **Hinweis:** Zellen mit „—“ sind im vorliegenden Schema-Stand nicht festgelegt; die verbindliche technische Referenz folgt in Kapitel 5. Die Einordnung von Push/Pull unter „Channel“ folgt der Nutzerentscheidung USER__018: Push und Pull beschreiben, wie die Engine die Frames bezieht.

## 4.2 State

Der State ist eine unveränderliche Lebenszyklusform, keine Presetvariante. Er ist immer kontrolliert, hat eine unbestimmte Laufzeit und erhält keine Runtime-Eingaben. Er wird über die Steuerungskommandos Setzen, Ersetzen und Löschen geführt und belegt einen der beiden State-Plätze (Background State oder Primary State). Neutrales Beispiel: eine dauerhafte Grunddarstellung ohne zeitliche Begrenzung und ohne laufende Eingaben.

## 4.3 Kontrolliertes Overlay (Push/Pull als Bezugsmodi)

Das kontrollierte Overlay ist ein Typ mit dem Modus `controlled`: unbestimmte Laufzeit und Runtime-Eingaben, die während der Laufzeit aktualisiert werden können. Es ist eine unveränderliche Lebenszyklusform, keine Presetvariante.

Push und Pull sind keine Untervarianten des kontrollierten Overlays und keine Overlay-Untertypen. Sie sind **Bezugsmodi für Runtime-Eingaben**: Sie beschreiben einen Aspekt davon, wie die Engine Frames bezieht. Das kontrollierte Overlay bleibt in beiden Fällen ein Typ mit zwei Bezugsmodi.

```mermaid
flowchart LR
    subgraph Q["Eingabequelle (Runtime-Eingaben)"]
        V["Werte der Eingabequelle"]
    end
    subgraph EN["Engine"]
        F["Frame-Erzeugung des kontrollierten Overlays"]
    end
    V -->|"Push: Die Quelle schiebt Werte zur Engine"| F
    F -->|"Pull: Die Engine zieht Werte von der Quelle"| V
```

*Schaubild 4.1: Die Bezugsmodi Push und Pull für Runtime-Eingaben.*

Neutrales Beispiel: eine laufende Anzeige, deren Inhalt sich aus Eingaben speist und während der Laufzeit aktualisiert werden kann.

## 4.4 Zeitgesteuertes Overlay

Das zeitgesteuerte Overlay ist ein Typ mit dem Modus `timed`: endliche Laufzeit und keine Runtime-Eingaben. Nach der Aktivierung ist es nicht aktualisierbar; die Engine beendet die Instanz am Ende der Laufzeit. Es ist eine unveränderliche Lebenszyklusform, keine Presetvariante. Neutrales Beispiel: ein kurzer Hinweis, der automatisch endet.

## 4.5 Event

Das Event ist eine unveränderliche Lebenszyklusform mit fester Vorgabe: endliche Laufzeit, keine Runtime-Eingaben, priorisiert und nicht nachträglich veränderbar. Events erreichen über die Event-Queue die oberste Ebene des Stapels und unterbrechen als priorisierte Unterbrechung alle darunterliegenden Ebenen. Neutrales Beispiel: eine sofortige, vorrangige Unterbrechungsmeldung mit fest vorgegebenem Inhalt.

## 4.6 Entscheidungshilfe

Die Entscheidung für eine Lebenszyklusform lässt sich an drei Fragen festmachen: Werden Runtime-Eingaben benötigt? Ist die Laufzeit endlich? Handelt es sich um eine priorisierte Unterbrechung mit fester Vorgabe?

```mermaid
flowchart TB
    A{"Werden Runtime-Eingaben benötigt?"}
    A -->|"ja"| B{"Ist die Laufzeit endlich?"}
    B -->|"ja"| X["Ungültige Kombination<br/>(siehe Abschnitt 4.7)"]
    B -->|"nein"| CO["Kontrolliertes Overlay<br/>Laufzeit unbestimmt, Bezugsmodi Push/Pull"]
    A -->|"nein"| C{"Ist die Laufzeit endlich?"}
    C -->|"nein"| ST["State<br/>Laufzeit unbestimmt, immer kontrolliert"]
    C -->|"ja"| D{"Priorisierte Unterbrechung mit fester Vorgabe?"}
    D -->|"ja"| EV["Event<br/>endlich, priorisiert, fest vorgegeben"]
    D -->|"nein"| TO["Zeitgesteuertes Overlay<br/>endlich, nach Aktivierung fixiert"]
```

*Schaubild 4.2: Entscheidungsfluss zur Wahl der Lebenszyklusform.*

Typvertrag und fachliche Verwendung werden getrennt behandelt: Die Regeln der Lebenszyklusformen sind verbindlich; fachliche Einsatzzwecke sind Orientierung und keine zusätzliche Schemaeinschränkung. Die in der Quelle genannten Beispiele (etwa eine DoA-Anzeige oder eine Fortschrittsanzeige) sind Empfehlungen. Solange der produktive Effektkatalog noch überarbeitet wird, verwendet dieses Dokument vorläufig neutrale Beispiele.

```mermaid
gantt
    title Lebenszyklusformen im Vergleich (Laufzeit)
    dateFormat X
    axisFormat %s
    section State
    Laufzeit unbestimmt: 0, 100
    section Kontrolliertes Overlay
    Laufzeit unbestimmt: 0, 100
    section Zeitgesteuertes Overlay
    Laufzeit endlich: 0, 30
    section Event
    Laufzeit endlich: 0, 8
```

*Schaubild 4.3: Vergleich der Laufzeiten aller vier Lebenszyklusformen.*

## 4.7 Ungültige Kombinationen

Aus der Lebenszyklus-Matrix und den Festlegungen der Typen ergeben sich folgende ungültige Kombinationen:

- **Zeitgesteuertes Overlay mit Runtime-Eingaben:** Die Matrix ordnet dem Modus `timed` keine Runtime-Eingaben zu.
- **Event mit Runtime-Eingaben:** Das Event ist fest vorgegeben und erhält keine Runtime-Eingaben.
- **State mit Overlay-Modus:** `overlay_mode` gilt nur für Overlays; der State ist immer kontrolliert.
- **Bezugsmodi außerhalb des kontrollierten Overlays:** Push und Pull sind Bezugsmodi für Runtime-Eingaben; ohne Runtime-Eingaben (State, zeitgesteuertes Overlay, Event) sind sie unzulässig.
- **Aktualisierung nach der Aktivierung:** Ein zeitgesteuertes Overlay ist nach der Aktivierung nicht aktualisierbar; ein Event ist nicht nachträglich veränderbar.

## Entscheidungen zu Kapitel 4

1. **Push und Pull als Bezugsmodi für Runtime-Eingaben:** Sie sind keine Untervarianten des kontrollierten Overlays (abweichend von der ursprünglichen Empfehlung 3B); das kontrollierte Overlay bleibt ein Typ mit zwei Bezugsmodi, die beschreiben, wie die Engine Frames bezieht.
2. **Drei fachliche Typen, vier Lebenszyklusformen:** State, Overlay und Event bleiben unveränderliche Typen, keine Presetvarianten; die vier Lebenszyklusformen werden deutlich dargestellt (State, kontrolliertes Overlay, zeitgesteuertes Overlay, Event).
3. **Fachliche Einsatzzwecke als Orientierung:** Sie sind keine zusätzliche Schemaeinschränkung; die Regeln des Typvertrags sind verbindlich.
4. **Vorläufig neutrale Beispiele:** Solange der produktive Effektkatalog überarbeitet wird, werden neutrale Beispiele verwendet; die fachlichen Beispiele aus der Quelle (DoA, Fortschrittsanzeige) bleiben Empfehlungen.

---

# Kapitel 5: Schema V2

**Ziel:** Verbindliche technische Referenz für jede gültige Definition.

## Gliederung

1. Zweck des Schemas
2. Aufbau einer `EffectDefinition`
3. Identität und Metadaten
4. Typ und Overlay-Modus
5. Konfigurationsschema
6. Runtime-Input-Schema
7. Defaults
8. Capabilities
9. Layer-Regeln
10. Farbmodell und Komposition
11. Animation und Richtung
12. Input-Sampling
13. Bedingte Pflichtfelder
14. Übergreifende Invarianten
15. Ungültige Kombinationen
16. Verweis auf vollständige Beispiele

## 5.1 Zweck des Schemas

Das Schema ist die verbindliche technische Referenz für jede gültige Definition. Es legt fest, welche Felder eine Definition haben darf und muss, welche Kombinationen zulässig sind und welche Regeln für jeden Typ gelten. Unbekannte Felder und ungültige Kombinationen werden strikt abgewiesen. Die bisherige Schemadatei `planning/lefx_schema_v2.md` wird in diese Referenz überführt; am alten Ort verbleibt nur ein Archivhinweis.

## 5.2 Aufbau einer `EffectDefinition`

Eine `EffectDefinition` gliedert sich in die Abschnitte Identität und Metadaten, Typ und Overlay-Modus, Konfigurationsschema, Runtime-Input-Schema, Defaults und Capabilities.

```mermaid
flowchart TB
    D["EffectDefinition"]
    D --> I["Identität und Metadaten<br/>id · tags"]
    D --> T["Typ und Overlay-Modus<br/>overlay_mode"]
    D --> K["Konfigurationsschema"]
    D --> R["Runtime-Input-Schema<br/>input_sampling"]
    D --> F["Defaults"]
    D --> C["Capabilities"]
```

*Schaubild 5.1: Aufbau einer `EffectDefinition`.*

Diese Referenz zeigt kleine kanonische Ausschnitte statt vollständiger Definitionen; vollständige Beispiele bleiben in `effect-development` (siehe Abschnitt 5.16).

## 5.3 Identität und Metadaten

Die Referenztabelle des Schemas (Feld, Status, Bedeutung):

| Feld | Status | Bedeutung |
|---|---|---|
| `id` | verpflichtend | global eindeutige Definition-ID |
| `overlay_mode` | bedingt | nur für Overlays |
| `runtime_input_schema` | bedingt | nur für kontrollierte Overlays |
| `input_sampling` | bedingt | nur bei Runtime-Eingaben |
| `tags` | optional | Suche und Katalogisierung |

Die Identität einer Definition wird über die global eindeutige `id` hergestellt **[Verpflichtend]**. `tags` dienen der Suche und Katalogisierung **[Optional]**.

## 5.4 Typ und Overlay-Modus

Das Schema kennt die fachlichen Typen State, Overlay und Event. `overlay_mode` ist ein bedingtes Feld **[Bedingt]**: Es ist nur für Overlays zulässig und nimmt die Modi `controlled` (kontrolliertes Overlay) und `timed` (zeitgesteuertes Overlay) auf. Push und Pull sind keine Werte des Overlay-Modus: Sie sind Bezugsmodi für Runtime-Eingaben (siehe Abschnitt 5.6).

## 5.5 Konfigurationsschema

Das Konfigurationsschema beschreibt die typspezifischen Einstellungen einer Definition. Die konkreten Felder sind typabhängig; diese Referenz führt sie vollständig, zeigt aber nur kanonische Ausschnitte als Beispiele.

## 5.6 Runtime-Input-Schema

Das Runtime-Input-Schema ist ein bedingtes Feld **[Bedingt]**: Es ist nur für kontrollierte Overlays zulässig. Es beschreibt die Runtime-Eingaben einer laufenden Instanz. Die Bezugsmodi Push und Pull legen fest, wie die Engine die Frames bezieht: Push schiebt die Werte von der Quelle zur Engine, Pull zieht sie von der Quelle.

## 5.7 Defaults

Der Abschnitt Defaults hält die Standardwerte, die gelten, wenn eine Definition eine Angabe nicht explizit setzt. Die konkreten Defaults werden in der vollständigen Feldreferenz geführt.

## 5.8 Capabilities

Der Abschnitt Capabilities führt die Fähigkeiten auf, die eine Definition für ihre Laufzeit beansprucht. Die konkreten Angaben werden in der vollständigen Feldreferenz geführt.

## 5.9 Layer-Regeln

Die Platzierung einer laufenden Instanz bestimmen der Typ und – bei Overlays – der Overlay-Modus. Aufrufer wählen keine beliebigen Layer; die Zuordnung ist Teil des Schemas.

| Typ / Overlay-Modus | Platzierung im Stapel |
|---|---|
| State | `STATE_LAYER` oder `BACKGROUND_STATE_LAYER` |
| Overlay, Modus `controlled` | `ONGOING_OVERLAY_LAYER` |
| Overlay, Modus `timed` | `TEMP_OVERLAY_LAYER` |
| Event | `EVENT_LAYER` |

```mermaid
flowchart LR
    ST["State"] --> P["STATE_LAYER oder BACKGROUND_STATE_LAYER"]
    CO["Overlay, Modus controlled"] --> O["ONGOING_OVERLAY_LAYER"]
    TO["Overlay, Modus timed"] --> T["TEMP_OVERLAY_LAYER"]
    EV["Event"] --> EL["EVENT_LAYER"]
```

*Schaubild 5.2: Typ und Overlay-Modus bestimmen die Layer-Platzierung.*

## 5.10 Farbmodell und Komposition

Die Komposition der übereinanderliegenden Ebenen folgt den Regeln aus Kapitel 3: Ebenen können transparent sein; `None` bedeutet bei transparenten Frames, den darunterliegenden Wert zu erhalten. Das Farbmodell legt fest, wie die Farbwerte der Frames aufgebaut sind und wie sie beim Übereinanderlegen komponiert werden.

## 5.11 Animation und Richtung

Die Animation betrifft die zeitliche Entwicklung der Frames einer laufenden Instanz. Sie ist getrennt zu sehen von der Lebensdauer der Instanz und von der Aktualisierung der Runtime-Eingaben (Kapitel 3, Abschnitt 3.5). Die konkreten Animations- und Richtungsangaben werden in der vollständigen Feldreferenz geführt.

## 5.12 Input-Sampling

`input_sampling` ist ein bedingtes Feld **[Bedingt]**: Es ist nur bei Runtime-Eingaben zulässig. Es regelt die Abtastung der Runtime-Eingaben; die Bezugsmodi Push und Pull beschreiben, wie die Engine die Frames von der Eingabequelle bezieht (Abschnitt 5.6).

## 5.13 Bedingte Pflichtfelder

Bedingte Pflichtfelder sind nur unter einer bestimmten Bedingung zulässig beziehungsweise erforderlich:

| Feld | Bedingung |
|---|---|
| `overlay_mode` | nur für Overlays |
| `runtime_input_schema` | nur für kontrollierte Overlays |
| `input_sampling` | nur bei Runtime-Eingaben |

Außerhalb ihrer Bedingung sind die Felder unzulässig; die Definition wird dann strikt abgewiesen.

## 5.14 Übergreifende Invarianten

Die folgenden Invarianten gelten für jede Definition:

- **[Verpflichtend]** Unbekannte Felder werden strikt abgewiesen.
- **[Verpflichtend]** Ungültige Kombinationen werden strikt abgewiesen.
- **[Verpflichtend]** State, Overlay und Event sind unveränderliche Typen, keine Presetvarianten.
- **[Verpflichtend]** Aufrufer wählen keine beliebigen Layer; Typ und Overlay-Modus bestimmen die Platzierung.
- **[Verpflichtend]** Ein Paket besitzt keinen parallelen Lifecycle.
- **[Empfehlung]** Fachliche Einsatzzwecke sind Orientierung, keine Schemaeinschränkung.

## 5.15 Ungültige Kombinationen

Für jeden Typ gelten separate Invariantenlisten, aus denen sich die ungültigen Kombinationen ergeben.

**State**

- Gültig: immer kontrolliert, Laufzeit unbestimmt, keine Runtime-Eingaben, Platz auf `STATE_LAYER` oder `BACKGROUND_STATE_LAYER`.
- Ungültig: ein `overlay_mode` (nur für Overlays), ein Runtime-Input-Schema, endliche Laufzeit.

**Kontrolliertes Overlay**

- Gültig: Modus `controlled`, Laufzeit unbestimmt, Runtime-Eingaben mit den Bezugsmodi Push/Pull, Platz auf `ONGOING_OVERLAY_LAYER`.
- Ungültig: Modus `timed` (widerspricht der Matrix), `input_sampling` ohne Runtime-Eingaben, Bezugsmodi außerhalb des kontrollierten Overlays.

**Zeitgesteuertes Overlay**

- Gültig: Modus `timed`, Laufzeit endlich, keine Runtime-Eingaben, Platz auf `TEMP_OVERLAY_LAYER`.
- Ungültig: Runtime-Eingaben oder ein Runtime-Input-Schema, Aktualisierung nach der Aktivierung.

**Event**

- Gültig: fest vorgegeben, Laufzeit endlich, priorisiert, Platz auf `EVENT_LAYER`, Eingang über die Event-Queue.
- Ungültig: Runtime-Eingaben, nachträgliche Veränderung.

## 5.16 Verweis auf vollständige Beispiele

Diese Referenz enthält ausschließlich kleine kanonische Ausschnitte. Vollständige Beispiele bleiben in `effect-development` und werden von hier aus verlinkt. Die bisherige Schemadatei `planning/lefx_schema_v2.md` ist in diese Referenz überführt; am alten Ort verbleibt nur ein Archivhinweis.

## Entscheidungen zu Kapitel 5

1. **Sprache:** Deutscher Erklärungstext; technische Feld- und Enum-Namen bleiben unverändert Englisch.
2. **Umfang:** Vollständige Feldreferenz; vollständige Beispieldateien werden nur verlinkt (in `effect-development`); diese Referenz zeigt kleine kanonische Ausschnitte.
3. **Kennzeichnung:** Regeln sind sichtbar als `Verpflichtend`, `Bedingt`, `Optional` oder `Empfehlung` gekennzeichnet.
4. **Überführung:** Die bisherige V2-Schemadatei aus `planning` wird in diese Referenz überführt; am alten Ort verbleibt nur ein Archivhinweis.
