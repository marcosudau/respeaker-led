# Kapitel 7: Runtime-Eingaben

> **Einordnung:** Kapitel 1, 2, 3, 6 und 8 sind laut Dokumentationsfahrplan inhaltlich freigegeben; dieses Dokument enthält Kapitel 7. Push und Pull wurden bereits in Kapitel 4 als Bezugsmodi eingeführt und werden hier im Detail behandelt.

**Ziel:** Den vollständigen Datenweg kontrollierter Overlays erklären, ohne Push und Pull zu Untertypen aufzuwerten.

---

## 7.1 Konfiguration gegenüber Runtime-Eingabe

Ein kontrolliertes Overlay ist durch zwei zeitlich getrennte Arten von Informationen bestimmt:

- **Konfiguration:** Alle Festlegungen, die zum Zeitpunkt der Definition getroffen werden. Dazu gehören die deklarierten Eingaben, ihre Darstellung und die für den Betrieb maßgeblichen Policy-Werte (beispielsweise die Heartbeat-Policy, siehe Abschnitt 7.7). Die Konfiguration ist statisch; sie ändert sich während des Betriebs einer laufenden Instanz nicht.
- **Runtime-Eingaben:** Alle Werte, die erst während des Betriebs entstehen und in die laufende Instanz gelangen. Sie sind veränderlich und stammen aus einer Integration — entweder aktiv zugestellt (Push) oder durch die Engine abgefragt (Pull). Die Herkunft der Runtime-Eingaben beschreibt der jeweilige Bezugsmodus (Abschnitte 7.4 und 7.5).

Die Konfiguration legt also fest, *welche* Eingaben existieren und wie sie behandelt werden; die Runtime-Eingaben liefern die *aktuellen Werte* zu diesen Eingaben. Beide fließen in die laufende Overlay-Instanz, die daraus den Frame erzeugt:

```mermaid
flowchart LR
    subgraph Definition
        K["Konfiguration (statisch)"]
        D["Deklaration der Eingaben"]
    end
    subgraph Laufzeit
        R["Runtime-Eingaben (veränderlich)"]
    end
    K --> I["Laufende Overlay-Instanz"]
    D --> I
    R --> I
    I --> F["render()"]
```

| Aspekt | Konfiguration | Runtime-Eingabe |
|---|---|---|
| Zeitpunkt | Definition (statisch) | Laufzeit (veränderlich) |
| Inhalt | Deklaration, Darstellung, Policies | Aktuelle Werte aus der Integration |
| Änderbarkeit | Nicht änderbar während des Betriebs | Änderbar mit jedem Eingang |
| Zuständigkeit | Overlay-Definition | Bezugsmodus (Push oder Pull) |

## 7.2 Warum nur kontrollierte Overlays veränderliche Eingaben besitzen

Runtime-Eingaben sind Steuerungseingaben: Sie übermitteln Werte, die das Verhalten der laufenden Instanz beeinflussen. Genau das kennzeichnet ein **kontrolliertes Overlay** — es wird zur Laufzeit gesteuert und empfängt dafür Steuerungskommandos beziehungsweise Messwerte über seinen Overlay-Channel (Abschnitt 7.3).

Ein Overlay ohne Steuerungsanteil besitzt keine veränderlichen Eingaben: Es gibt nichts, was zur Laufzeit von außen zugeführt werden müsste, und damit auch keinen Datenweg für Runtime-Eingaben. Veränderliche Eingaben sind daher kein optionales Merkmal beliebiger Overlays, sondern an die Steuerbarkeit des kontrollierten Overlays gebunden.

Wichtig für die Einordnung: **Push und Pull sind keine Untertypen des kontrollierten Overlays und keine Untervarianten davon.** Sie betreffen ausschließlich die *Herkunft* der Runtime-Eingaben — ob die Werte aktiv zugestellt oder aktiv abgefragt werden. Das kontrollierte Overlay selbst bleibt in beiden Fällen dasselbe; `render()` erzeugt unabhängig vom Bezugsmodus den Frame (Abschnitte 7.4 und 7.5).

## 7.3 Overlay-Channel

Der **Overlay-Channel** ist der Übertragungsweg, über den Runtime-Eingaben zur laufenden Overlay-Instanz gelangen. Er ist der gemeinsame Eintrittspunkt für beide Bezugsmodi:

- Im **Push-Bezugsmodus** stößt die externe Integration ein Channel-Update an und übermittelt es über den Channel an die laufende Instanz.
- Im **Pull-Bezugsmodus** fragt die Engine nach dem Engine-Zeitplan Werte ab und führt sie der laufenden Instanz über denselben Channel zu.

Ein **Channel-Update** ist die Dateneinheit des Channels: Es trägt Werte für die deklarierten Eingaben des kontrollierten Overlays. Jedes Update durchläuft vor der laufenden Instanz die Validierung; erst danach gelangt es in die Instanz und schließlich in `render()`.

Der Channel trennt die Integration vom Overlay: Die Integration kennt den Channel, aber nicht die innere Verarbeitung der laufenden Instanz; die Engine verwaltet den Channel und die darauf eingehenden Updates.

## 7.4 Push als Bezugsmodus

Im **Push-Bezugsmodus** ist die Herkunft der Runtime-Eingaben die externe Integration. Sie stößt Updates aktiv an, ohne dass die Engine dazu auffordert. Der Datenweg ist:

```text
Externe Integration
→ Channel-Update
→ Validierung
→ laufende Overlay-Instanz
→ render()
```

```mermaid
flowchart LR
    A["Externe Integration"] --> B["Channel-Update"]
    B --> C["Validierung"]
    C --> D["Laufende Overlay-Instanz"]
    D --> E["render()"]
```

Merkmale des Push-Bezugsmodus:

- Die Integration bestimmt den Zeitpunkt der Übermittlung; die Engine wartet auf eingehende Updates.
- Ein **leeres Push-Update ist ein Lebenszeichen**: Es trägt keine neuen Werte, bestätigt aber, dass die Integration weiterhin verbunden ist, und behält die vorhandenen Werte bei.
- **Erfolgreiche Eingänge** — also Updates, die die Validierung bestehen — aktualisieren einen **engine-eigenen Empfangszeitpunkt**. Dieser Zeitpunkt ist die Grundlage der Empfangsgesundheit (Abschnitt 7.8) und der Karenzzeit (Abschnitt 7.7).

Durchgängiges Beispiel für den Push-Bezugsmodus ist das **DoA-Szenario** (Abschnitt 7.10): Die Integration übermittelt Datenzustände als Push-Updates, die Engine validiert und führt sie der laufenden Instanz zu, der Renderer stellt sie dar.

## 7.5 Pull als Bezugsmodus

Im **Pull-Bezugsmodus** ist die Herkunft der Runtime-Eingaben der Engine-Zeitplan. Die Engine fragt Werte aktiv ab; die Integration antwortet auf die Abfrage. Der Datenweg ist:

```text
Engine-Zeitplan
→ sample_inputs()
→ Validierung
→ laufende Overlay-Instanz
→ render()
```

```mermaid
flowchart LR
    A["Engine-Zeitplan"] --> B["sample_inputs()"]
    B --> C["Validierung"]
    C --> D["Laufende Overlay-Instanz"]
    D --> E["render()"]
```

Merkmale des Pull-Bezugsmodus:

- Die Engine bestimmt den Zeitpunkt der Abfrage über den Engine-Zeitplan; das Sampling-Intervall (Abschnitt 7.6) gibt den Abstand der Abfragen vor.
- `sample_inputs()` erhebt die Werte bei der Integration; auch diese Eingänge durchlaufen die Validierung.
- Erfolgreiche Eingänge aktualisieren denselben engine-eigenen Empfangszeitpunkt wie im Push-Bezugsmodus; die Empfangsgesundheit wird einheitlich bewertet.

Beispiel für den Pull-Bezugsmodus ist ein **neutrales Sensorszenario**: Ein Sensorwert wird in festen Abständen vom Engine-Zeitplan abgefragt, validiert und der laufenden Instanz zugeführt. Darüber hinaus sind alltägliche Beispiele zulässig, etwa ein Countdown oder eine Lautstärkeregelung, deren Werte die Engine in definierten Intervallen abfragt.

| Aspekt | Push | Pull |
|---|---|---|
| Herkunft der Runtime-Eingaben | Externe Integration | Engine-Zeitplan |
| Auslöser der Übermittlung | Integration (aktives Zustellen) | Engine (aktives Abfragen) |
| Dateneinheit | Channel-Update | `sample_inputs()`-Ergebnis |
| Zeitsteuerung | Ankunftsrate der Updates | Sampling-Intervall |
| Gemeinsam | Validierung → laufende Instanz → `render()` | Validierung → laufende Instanz → `render()` |

Beide Bezugsmodi münden in denselben weiteren Datenweg: **`render()` erzeugt unabhängig vom Bezugsmodus den Frame.**

## 7.6 Sampling-Intervall

Das **Sampling-Intervall** bestimmt im Pull-Bezugsmodus den zeitlichen Abstand, in dem die Engine `sample_inputs()` aufruft. Es ist Teil des Engine-Zeitplans und legt fest, wie häufig Runtime-Eingaben erhoben werden.

Das Sampling-Intervall wirkt sich auf zwei Beobachtungen aus:

- **Aktualität:** Ein kürzeres Intervall liefert häufigere Werte, ein längeres Intervall reduziert die Abfragehäufigkeit gegenüber der Integration.
- **Empfangsgesundheit:** Auch im Pull-Bezugsmodus fließen die Ergebnisse der Abfragen in den engine-eigenen Empfangszeitpunkt ein. Bleiben Ergebnisse aus, greifen Heartbeat und Karenzzeit (Abschnitt 7.7) wie im Push-Bezugsmodus.

Im Push-Bezugsmodus übernimmt die Ankunftsrate der Channel-Updates die Rolle der zeitlichen Steuerung; ein eigenes Sampling-Intervall entfällt dort, weil die Integration den Zeitpunkt der Übermittlung bestimmt.

## 7.7 Heartbeat und Karenzzeit

Die Engine stellt sicher, dass eine laufende Instanz nicht dauerhaft mit veralteten Werten arbeitet, ohne dies zu bemerken. Dazu dient der **Heartbeat** als Lebenszeichen der Integration und die daran geknüpfte **Karenzzeit** als Übergangsfrist.

Der Standard-Heartbeat beträgt **1000 ms × 3**. Er ist als Policy zu verstehen, die durch die Definition anpassbar ist:

| Heartbeat-Policy | Standard | Bedeutung |
|---|---|---|
| Intervall | 1000 ms | Erwarteter Abstand zwischen zwei Lebenszeichen |
| Anzahl | 3 | Anzahl ausbleibender Lebenszeichen, nach der die Karenzzeit abläuft |
| Anpassbarkeit | durch die Definition | Intervall und Anzahl sind als Policy-Werte der Definition konfigurierbar |

Ablauf im Einzelnen:

1. Im Push-Bezugsmodus gilt jedes eingehende Channel-Update — auch ein leeres — als Lebenszeichen; im Pull-Bezugsmodus übernehmen die erfolgreichen `sample_inputs()`-Ergebnisse diese Rolle.
2. Jeder erfolgreiche Eingang aktualisiert den engine-eigenen Empfangszeitpunkt.
3. Bleiben Lebenszeichen aus, beginnt die Karenzzeit. **Während der Karenzzeit bleibt der letzte gültige Wert bestehen**; die laufende Instanz arbeitet mit diesem Wert weiter.
4. Nach Ablauf der Karenzzeit — im Standard nach drei ausbleibenden Lebenszeichen — **erhält der Renderer für deklarierte Eingaben `None`**.

```mermaid
sequenceDiagram
    participant I as Integration
    participant E as Engine
    participant R as Renderer
    Note over I,E: Push-Bezugsmodus, Standard-Heartbeat 1000 ms × 3
    I->>E: Channel-Update (Lebenszeichen)
    E->>E: Empfangszeitpunkt aktualisieren
    I->>E: Leeres Push-Update (Lebenszeichen)
    E->>E: Empfangszeitpunkt aktualisieren
    Note over I: Drei ausbleibende Lebenszeichen
    Note over E: Karenzzeit beginnt — letzter gültiger Wert bleibt bestehen
    Note over E: Karenzzeit abgelaufen
    E->>R: None für deklarierte Eingaben
```

Die Karenzzeit ist damit die Frist, in der ein Ausbleiben der Runtime-Eingaben toleriert wird, ohne die Darstellung zu verändern; erst nach ihrem Ablauf wechselt die laufende Instanz auf den Zustand „fehlende Werte“ (Abschnitt 7.9).

## 7.8 Input-Health

Unter **Input-Health** (Empfangsgesundheit) fasst die Engine die Beurteilung der eingehenden Runtime-Eingaben zusammen. Bewertet wird die *Gesundheit des Empfangs* — also ob und in welchem Abstand Lebenszeichen eintreffen — und nicht die fachliche Qualität eines Messwertes.

Ausdrücklich gilt: **Die Engine bewertet Empfangsgesundheit, nicht die fachliche Qualität eines Messwertes.** Ob ein übermittelter Wert fachlich korrekt, plausibel oder genau ist, ist keine Aufgabe der Empfangsgesundheit; die Engine stellt nur fest, ob Eingänge erfolgreich eintreffen, den Empfangszeitpunkt aktualisieren und innerhalb der Heartbeat-Policy liegen.

| Input-Health-Zustand | Bedingung | Verhalten |
|---|---|---|
| Gesund | Lebenszeichen treffen innerhalb der Heartbeat-Policy ein | Empfangszeitpunkt wird aktualisiert; Werte fließen in die laufende Instanz |
| Karenzzeit | Lebenszeichen bleiben aus, Frist noch nicht abgelaufen | Letzter gültiger Wert bleibt bestehen |
| Abgelaufen | Lebenszeichen bleiben über die Karenzzeit hinaus aus | Renderer erhält `None` für deklarierte Eingaben |

Die Zustände gelten unabhängig vom Bezugsmodus: Sowohl im Push- als auch im Pull-Bezugsmodus ist die Empfangsgesundheit an den engine-eigenen Empfangszeitpunkt gekoppelt.

## 7.9 Fehlende Werte und `None`

Fehlende Runtime-Eingaben sind ein definierter Zustand, kein Verarbeitungsfehler. Nach Ablauf der Karenzzeit erhält der Renderer für **deklarierte** Eingaben den Wert `None` — vorausgesetzt, die Eingaben sind in der Definition deklariert; nur für diese besteht überhaupt ein Erwartungswert.

**Die Definition entscheidet, wie fehlende Daten dargestellt werden.** `None` ist das Signal an den Renderer, dass kein gültiger Wert vorliegt; die Darstellung dieses Zustands — etwa ein Platzhalter, eine neutrale Anzeige oder das Ausblenden des betroffenen Elements — legt die Definition fest. Damit bleibt die Darstellungsentscheidung beim Overlay, während die Engine nur den Zustand „kein gültiger Wert“ zuverlässig meldet.

Wichtig ist die Abgrenzung: Während der Karenzzeit gilt ein Wert nicht als fehlend — der letzte gültige Wert bleibt bestehen (Abschnitt 7.7). Erst nach Ablauf der Karenzzeit wechselt die laufende Instanz auf `None`.

## 7.10 DoA-Datenfluss

Das **DoA-Szenario** („Dead on Arrival“) ist das durchgängige Beispiel für den Push-Bezugsmodus. Es zeigt den vollständigen Datenweg von der externen Integration bis zum Frame:

```text
Externe Integration
→ Channel-Update
→ Validierung
→ laufende Overlay-Instanz
→ render()
```

1. **Externe Integration:** Die Integration erzeugt ein Channel-Update mit den Datenzuständen des DoA-Szenarios und stößt die Übermittlung aktiv an.
2. **Channel-Update:** Das Update gelangt über den Overlay-Channel zur Engine; auch ein leeres Update zählt als Lebenszeichen und behält vorhandene Werte.
3. **Validierung:** Die Engine prüft das Update; erfolgreiche Eingänge aktualisieren den engine-eigenen Empfangszeitpunkt.
4. **Laufende Overlay-Instanz:** Die validierten Werte fließen in die laufende Instanz des kontrollierten Overlays ein.
5. **render():** Der Renderer erzeugt den Frame — unabhängig davon, dass die Werte im Push-Bezugsmodus angekommen sind.

Bleiben die Push-Updates aus, greifen Heartbeat und Karenzzeit: Der letzte gültige DoA-Zustand bleibt während der Karenzzeit bestehen, danach erhält der Renderer `None` für die deklarierten Eingaben (Abschnitte 7.7 und 7.9).

## 7.11 Verantwortungsgrenze zur Integration

Der Datenweg endet an klar definierten Zuständigkeiten. **Die USB- und Hardwarelogik bleibt in der Integration:** Die Integration ist der Ort, an dem Hardware angebunden, Daten erhoben oder Zustände erzeugt werden. Diese Logik dringt weder in die Engine noch in das kontrollierte Overlay vor.

| Ebene | Zuständigkeit |
|---|---|
| Integration | USB- und Hardwarelogik, Erzeugung der Werte, Zustellung (Push) oder Beantwortung der Abfragen (Pull) |
| Engine | Channel-Verwaltung, Validierung, Empfangszeitpunkt, Heartbeat, Karenzzeit, Input-Health |
| Kontrolliertes Overlay | Laufende Instanz, Verarbeitung der Runtime-Eingaben, Darstellung fehlender Werte |
| Renderer | Erzeugung des Frames aus der laufenden Instanz |

Die Integration kommuniziert mit der Engine über den Overlay-Channel und nicht über interne Schnittstellen der Engine. Dadurch bleibt die Hardwarelogik austauschbar, ohne dass sich der Datenweg des kontrollierten Overlays ändert: Egal ob eine Integration Werte per Push zustellt oder die Engine sie per Pull abfragt, die Grenze zwischen Integration und Engine bleibt dieselbe, und `render()` erzeugt unabhängig vom Bezugsmodus den Frame.

---

## Entscheidungen zu Kapitel 7

Die folgenden Festlegungen wurden für dieses Kapitel getroffen:

- **7A — Bezugsmodus als Begriff:** Es wird allgemein von „Bezugsmodus für Runtime-Eingaben“ gesprochen; `InputMode.PUSH/PULL` wird nur technisch ergänzt. Push und Pull sind damit weder Untertypen noch Untervarianten des kontrollierten Overlays — sie betreffen ausschließlich die Herkunft der Runtime-Eingaben.
- **7B — Heartbeat-Policy:** Der Standard-Heartbeat beträgt `1000 ms × 3` und wird als durch die Definition anpassbare Policy dargestellt (Intervall und Anzahl sind konfigurierbar).
- **7C — Beispiele:** Das DoA-Szenario dient als durchgängiges Push-Beispiel, ein neutrales Sensorszenario als Pull-Beispiel; ergänzend sind alltägliche Beispiele wie Countdown oder Lautstärkeregelung zulässig.
- **7D — Empfangsgesundheit:** Die Dokumentation sagt deutlich, dass die Engine Empfangsgesundheit (Input-Health) bewertet, nicht die fachliche Qualität eines Messwertes.
