# Faktenquelle Kapitel 5: Schema V2 (Einzel-Durchlauf)
# Extrahiert aus kapitel3_bereich.md (AGENT_017, "Kapitel 5: Schema V2")

## Kapitel 5: Schema V2

**Ziel:** Verbindliche technische Referenz für jede gültige Definition.

#-> Gliederung

1. Zweck des Schemas
2. Aufbau einer `EffectDefinition`
3. Identität und Metadaten
4. Typ und Overlay-Modus
5. Konfigurationsschema
6. Runtime-Input-Schema
7. Defaults
8. Capabilities
9. Layer-Regeln
10. Farbmodell und Komposition
11. Animation und Richtung
12. Input-Sampling
13. bedingte Pflichtfelder
14. übergreifende Invarianten
15. ungültige Kombinationen
16. Verweis auf vollständige Beispiele

Die Felder werden in einer Referenztabelle dargestellt:

| Feld | Status | Bedeutung |
|---|---|---|
| `id` | verpflichtend | global eindeutige Definition-ID |
| `overlay_mode` | bedingt | nur für Overlays |
| `runtime_input_schema` | bedingt | nur für kontrollierte Overlays |
| `input_sampling` | bedingt | nur bei Runtime-Eingaben |
| `tags` | optional | Suche und Katalogisierung |

Zusätzlich kommen separate Invariantenlisten für State, kontrolliertes Overlay, zeitgesteuertes Overlay und Event.

**Schwerpunkte:**

- Vollständige Referenz, aber keine riesigen JSON-Ausgaben.
- Kleine kanonische Ausschnitte statt drei vollständiger Definitionen.
- Vollständige Beispiele bleiben in `effect-development`.
- Unbekannte Felder und ungültige Kombinationen werden strikt abgewiesen.
- Die bestehende `planning/lefx_schema_v2.md` wird in diese aktuelle Referenz überführt.

**Entscheidungen:**

- **5A:** Deutscher Erklärungstext, technische Feld- und Enum-Namen unverändert Englisch?  
  Empfehlung: Ja.
- **5B:** Vollständige Feldreferenz, aber vollständige Effektquellen nur verlinken?  
  Empfehlung: Ja.
- **5C:** Regeln sichtbar als `Verpflichtend`, `Bedingt`, `Optional` oder `Empfehlung` kennzeichnen?  
  Empfehlung: Ja.
- **5D:** Die bisherige V2-Schemadatei aus `planning` in die neue Referenz überführen und am alten Ort nur einen Archivhinweis hinterlassen?  
  Empfehlung: Ja.


