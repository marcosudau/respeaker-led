### AGENT_018

Die Korrekturen sind im Fahrplan festgehalten. Kapitel 3 heißt jetzt **Layer und Komposition**, Kapitel 4 **Typen und Lebenszyklen**. Push und Pull werden erst in Kapitel 7 als Bezugsmodi für Runtime-Eingaben behandelt.

## Kapitel 6: Parameter und Werte

**Ziel:** Erklären, welche Werte Definitionen anbieten, wie Eingaben benutzerfreundlich angenommen und intern strikt vereinheitlicht werden.

#-> Gliederung

1. Aufgabe eines Parameters
2. Konfigurationsauflösung
3. verpflichtende und optionale Werte
4. Standardparameter
5. Farbmodelle
6. Komfortnotationen und Aliase
7. Kanonische interne Werte
8. Grenzen und Validierungsfehler

Konfigurationsreihenfolge:

```text
Definition-Defaults
→ Preset
→ explizite Werte des Steuerungskommandos
→ Validierung und Kanonisierung
```

Standardfelder werden nur verlangt, wenn das Merkmal vorhanden ist:

- farbige Definition: `brightness`
- animierte Definition: `speed`
- gerichtete Definition: `reverse`
- Winkel: `direction_deg`
- Fortschritt: `progress`
- endliche Lebensdauer: `duration_ms` oder `total_ms`

Die Farbmodelle werden getrennt erklärt:

- `none`
- `mono`
- `dual`
- `palette`
- `gradient`
- `random_range`

**Schwerpunkte:**

- `speed` ist ein Multiplikator der entworfenen Grundgeschwindigkeit, keine FPS-Angabe.
- Benutzer dürfen `blau`, `blue`, `#0000FF` oder `0x0000FF` eingeben; intern existiert nur der kanonische Wert.
- Aliase gelten nur an der Systemgrenze.
- Mehrdeutige und unbekannte Werte werden abgewiesen.
- Zufallsfarben bleiben durch `random_seed` reproduzierbar.
- Renderer sollen nicht erneut eigene Eingabeparser erfinden.

**Entscheidungen:**

- **6A:** Standardparameter nur bei passendem Merkmal verpflichtend machen? Empfehlung: Ja.
- **6B:** Alle unterstützten Farbmodelle mit jeweils einem kleinen Beispiel darstellen? Empfehlung: Ja.
- **6C:** Farbalias-Tabelle als eigene Referenztabelle statt langer Liste im Fließtext? Empfehlung: Ja.
- **6D:** Klar trennen zwischen toleranter Eingabegrenze und strengem internen Datenmodell? Empfehlung: Ja.

