# Kapitel 5: Schema V2 — Technische Referenz (LEFX Schema V2)

> **Hinweis:** Dieses Dokument enthält Kapitel 5 der technischen Dokumentation zum LED-Controller (LEFX Schema V2). Kapitel 1, 2, 3, 4, 6, 7, 8, 9, 10, 11 und 12 sind laut Dokumentationsfahrplan inhaltlich freigegeben.

---

## Inhalt dieses Kapitels

**Ziel:** Verbindliche technische Referenz für jede gültige Definition.

Das Schema V2 beschreibt, nach welchen Regeln eine Definition aufgebaut sein muss, damit sie gültig ist. Diese Referenz ist der verbindliche Maßstab: Sie listet die Felder einer `EffectDefinition`, kennzeichnet ihren Status, definiert die Invarianten je Typ und legt fest, welche Kombinationen abgewiesen werden. Die Referenz arbeitet bewusst mit kleinen kanonischen Ausschnitten; vollständige Definitionen werden nicht in diesem Kapitel abgedruckt, sondern über die Effektquellen in `effect-development` bereitgestellt.

### Kennzeichnung von Regeln

Alle Regeln in diesem Kapitel sind sichtbar gekennzeichnet:

| Kennzeichnung | Bedeutung |
|---|---|
| `Verpflichtend` | Gilt für jede gültige Definition ohne Ausnahme. |
| `Bedingt` | Pflicht, sobald die genannte Bedingung erfüllt ist; unzulässig, wenn die Bedingung nicht erfüllt ist. |
| `Optional` | Darf gesetzt werden, muss aber nicht gesetzt werden. |
| `Empfehlung` | Empfohlenes Vorgehen; keine Bedingung für die Gültigkeit. |

Erklärungstexte sind deutsch. Technische Feld- und Enum-Namen bleiben unverändert englisch.

---

## 1. Zweck des Schemas

Das Schema V2 ist die verbindliche technische Referenz für jede gültige Definition. Es beantwortet für jede `EffectDefinition` die Fragen:

- Welche Felder sind Teil einer Definition?
- Welche Felder sind `Verpflichtend`, welche `Bedingt`, welche `Optional`?
- Welche Invarianten gelten übergreifend und je Typ?
- Welche Kombinationen sind ungültig und werden abgewiesen?

**`Verpflichtend`:** Unbekannte Felder und ungültige Kombinationen werden strikt abgewiesen. Eine Definition, die ein Feld enthält, das diese Referenz nicht kennt, oder eine Kombination, die diese Referenz verbietet, ist nicht gültig.

**`Verpflichtend`:** Diese Referenz ist vollständig in Bezug auf die Felder. Vollständige Effektquellen werden nur verlinkt und nicht in diesem Kapitel dupliziert.

**`Empfehlung`:** Für die Arbeit mit konkreten Definitionen sollten die vollständigen Beispiele in `effect-development` herangezogen werden; dieses Kapitel liefert die zugehörige verbindliche Feld- und Regelreferenz.

---

## 2. Aufbau einer `EffectDefinition`

Eine `EffectDefinition` ist die Einheit, die das Schema V2 beschreibt. Die Referenztabelle (Abschnitt 3) führt die Felder; das folgende Diagramm zeigt die Struktur einer Definition als Baum:

```mermaid
flowchart TD
    ED["EffectDefinition"] --> ID["id<br/>Verpflichtend — global eindeutige Definition-ID"]
    ED --> OM["overlay_mode<br/>Bedingt — nur für Overlays"]
    ED --> RIS["runtime_input_schema<br/>Bedingt — nur für kontrollierte Overlays"]
    ED --> IS["input_sampling<br/>Bedingt — nur bei Runtime-Eingaben"]
    ED --> TG["tags<br/>Optional — Suche und Katalogisierung"]
```

Kanonischer Minimalausschnitt einer Definition auf Ebene der dokumentierten Felder:

```json
{
  "id": "example:minimal"
}
```

**`Verpflichtend`:** Jede Definition führt das Feld `id`.

**`Verpflichtend`:** Ein Feld, das im Baum bzw. in der Referenztabelle nicht aufgeführt ist, ist unbekannt und wird strikt abgewiesen.

**`Empfehlung`:** Für den vollständigen Aufbau einer Definition die Effektquellen in `effect-development` verwenden; dieses Kapitel zeigt bewusst nur kleine kanonische Ausschnitte.

---

## 3. Identität und Metadaten

Die Felderreferenz ist verbindlich und wird hier in der festgelegten Form übernommen und um die Kennzeichnung ergänzt:

| Feld | Status | Kennzeichnung | Bedeutung |
|---|---|---|---|
| `id` | verpflichtend | `Verpflichtend` | global eindeutige Definition-ID |
| `overlay_mode` | bedingt | `Bedingt` | nur für Overlays |
| `runtime_input_schema` | bedingt | `Bedingt` | nur für kontrollierte Overlays |
| `input_sampling` | bedingt | `Bedingt` | nur bei Runtime-Eingaben |
| `tags` | optional | `Optional` | Suche und Katalogisierung |

**`Verpflichtend`:** `id` ist die global eindeutige Definition-ID. Zwei verschiedene Definitionen dürfen nicht dieselbe `id` tragen.

**`Optional`:** `tags` dient der Suche und Katalogisierung und kann weggelassen werden. Das Weglassen von `tags` berührt die Gültigkeit einer Definition nicht.

Kanonischer Ausschnitt für Identität und Metadaten:

```json
{
  "id": "example:minimal",
  "tags": ["beispiel", "katalog"]
}
```

---

## 4. Typ und Overlay-Modus

Jede Definition gehört einem Typ an. Das Schema V2 unterscheidet für die Invarianten vier Kategorien mit separaten Invariantenlisten: **State**, **kontrolliertes Overlay**, **zeitgesteuertes Overlay** und **Event**.

Overlays tragen den Overlay-Modus im Feld `overlay_mode`:

| Wert von `overlay_mode` | Entsprechende Kategorie |
|---|---|
| `controlled` | kontrolliertes Overlay |
| `timed` | zeitgesteuertes Overlay |

Kanonische Ausschnitte:

```json
{
  "id": "example:overlay-timed",
  "overlay_mode": "timed"
}
```

**`Bedingt`:** `overlay_mode` ist nur für Overlays zulässig und dort Pflicht.

**`Verpflichtend`:** Für Definitionen der Kategorien State und Event sind Overlay-Felder unzulässig.

---

## 5. Konfigurationsschema

Das Konfigurationsschema ist der Teil einer Definition, der die Konfiguration der Definition beschreibt. Es unterliegt vollständig den Regeln dieser Referenz.

**`Verpflichtend`:** Auch innerhalb des Konfigurationsschemas werden unbekannte Felder strikt abgewiesen; es gilt dieselbe Feldmenge wie in der Referenztabelle (Abschnitt 3).

**`Empfehlung`:** Konkrete Konfigurationsausschnitte sind den Effektquellen in `effect-development` zu entnehmen; dieses Kapitel bildet nur die verbindliche Feld- und Regelreferenz ab.

---

## 6. Runtime-Input-Schema

Das Feld `runtime_input_schema` beschreibt die Runtime-Eingaben einer Definition.

**`Bedingt`:** `runtime_input_schema` ist nur für kontrollierte Overlays zulässig und dort Pflicht. Für alle anderen Typen ist das Feld unzulässig.

Kanonischer Ausschnitt:

```json
{
  "id": "example:overlay-controlled",
  "overlay_mode": "controlled",
  "runtime_input_schema": {}
}
```

Der Platzhalter `{}` markiert, dass der vollständige Inhalt des `runtime_input_schema` über die Effektquellen abgebildet wird; diese Referenz legt den Status des Feldes fest, nicht seinen Inhalt.

---

## 7. Defaults

Defaults sind die Werte, die gelten, wenn ein Feld nicht angegeben wird. Für die Felder dieser Referenz gilt:

**`Verpflichtend`:** Ein Default ersetzt niemals ein verpflichtendes Feld. `id` ist in jeder Definition anzugeben.

**`Optional`:** Für `tags` ist das Weglassen zulässig; es ist keine Pflichtangabe.

**`Empfehlung`:** Das konkrete Default-Verhalten der Definitionen ist den vollständigen Effektquellen in `effect-development` zu entnehmen; diese Referenz legt keine Feldwerte neu fest.

---

## 8. Capabilities

Capabilities beschreiben die Fähigkeiten einer Definition. Das Schema V2 behandelt sie als Bestandteil der Definition und unterwirft sie denselben Regeln wie alle Felder.

**`Verpflichtend`:** Capability-Angaben, die nicht der dokumentierten Feldmenge entsprechen, werden als unbekannte Felder strikt abgewiesen.

**`Empfehlung`:** Die vollständige Darstellung der Capabilities einer Definition erfolgt über die Effektquellen in `effect-development`.

---

## 9. Layer-Regeln

Layer-Regeln regeln die Zusammensetzung mehrerer Definitionen im Betrieb des LED-Controllers. Sie sind Bestandteil der Referenzstruktur und unterliegen den Invarianten dieses Kapitels.

**`Verpflichtend`:** Für jede Definition gelten die übergreifenden Invarianten (Abschnitt 14) und die Invarianten des jeweiligen Typs; ungültige Kombinationen (Abschnitt 15) werden strikt abgewiesen.

**`Empfehlung`:** Die konkrete Ausgestaltung der Layer-Regeln ist den Effektquellen in `effect-development` zu entnehmen.

---

## 10. Farbmodell und Komposition

Farbmodell und Komposition sind Teil des gültigen Aufbaus einer Definition.

**`Verpflichtend`:** Farb- und Kompositionsangaben unterliegen derselben strikten Feldprüfung wie alle anderen Angaben; unbekannte Felder werden abgewiesen.

**`Empfehlung`:** Die konkreten Festlegungen zu Farbmodell und Komposition werden über die vollständigen Effektquellen in `effect-development` abgebildet; dieses Kapitel hält die übergeordneten Invarianten fest.

---

## 11. Animation und Richtung

Animation und Richtung sind Bestandteil der Referenzstruktur einer Definition.

**`Verpflichtend`:** Auch Animations- und Richtungsangaben dürfen nur dokumentierte Felder verwenden; alles andere wird strikt abgewiesen.

**`Empfehlung`:** Konkrete Animationen und Richtungsangaben sind den vollständigen Effektquellen in `effect-development` zu entnehmen.

---

## 12. Input-Sampling

Das Feld `input_sampling` regelt, wie Runtime-Eingaben abgetastet werden.

**`Bedingt`:** `input_sampling` ist nur bei Runtime-Eingaben zulässig und dort Pflicht. Das Feld setzt damit voraus, dass die Definition Runtime-Eingaben verarbeitet — also ein kontrolliertes Overlay mit `runtime_input_schema` ist.

**`Verpflichtend`:** Ohne Runtime-Eingaben ist `input_sampling` unzulässig und wird abgewiesen.

Kanonischer Ausschnitt:

```json
{
  "id": "example:overlay-controlled",
  "overlay_mode": "controlled",
  "runtime_input_schema": {},
  "input_sampling": {}
}
```

Die Abhängigkeiten der bedingten Felder zeigt das folgende Diagramm:

```mermaid
flowchart LR
    T["Typ der Definition"] -->|"State, Event"| A["Keine Overlay-Felder:<br/>kein overlay_mode,<br/>kein runtime_input_schema,<br/>kein input_sampling"]
    T -->|"Overlay"| OM["overlay_mode<br/>(controlled / timed)"]
    OM -->|"overlay_mode = controlled"| RIS["runtime_input_schema"]
    RIS -->|"Runtime-Eingaben vorhanden"| IS["input_sampling"]
    OM -->|"overlay_mode = timed"| B["Kein runtime_input_schema,<br/>kein input_sampling"]
```

---

## 13. Bedingte Pflichtfelder

Ein bedingtes Feld ist Pflicht, sobald seine Bedingung erfüllt ist, und unzulässig, wenn sie nicht erfüllt ist.

| Feld | Bedingung | Folge bei erfüllter Bedingung | Folge bei nicht erfüllter Bedingung |
|---|---|---|---|
| `overlay_mode` | Definition ist ein Overlay | Feld ist Pflicht | Feld ist unzulässig |
| `runtime_input_schema` | Definition ist ein kontrolliertes Overlay | Feld ist Pflicht | Feld ist unzulässig |
| `input_sampling` | Definition verarbeitet Runtime-Eingaben | Feld ist Pflicht | Feld ist unzulässig |

**`Bedingt`:** Jedes der drei Felder ist genau dann Pflicht, wenn die in der Tabelle genannte Bedingung erfüllt ist.

**`Verpflichtend`:** Die Bedingungen sind kumulativ — `input_sampling` setzt Runtime-Eingaben voraus, Runtime-Eingaben setzen ein kontrolliertes Overlay voraus, und ein kontrolliertes Overlay setzt ein Overlay voraus.

---

## 14. Übergreifende Invarianten

### Übergreifende Invarianten (gelten für jede Definition)

**`Verpflichtend`:** Jede Definition führt eine global eindeutige Definition-ID (`id`).

**`Verpflichtend`:** Unbekannte Felder werden strikt abgewiesen.

**`Verpflichtend`:** Ungültige Kombinationen werden strikt abgewiesen.

**`Verpflichtend`:** Die Regeln dieser Referenz sind verbindlich für jede gültige Definition.

### Separate Invariantenlisten je Typ

Zusätzlich zu den übergreifenden Invarianten gelten separate Invariantenlisten für die vier Kategorien:

| Kategorie | Invariantenliste |
|---|---|
| State | Keine Overlay-Felder: `overlay_mode`, `runtime_input_schema` und `input_sampling` sind unzulässig. |
| kontrolliertes Overlay | `overlay_mode` mit Wert `controlled` ist Pflicht; `runtime_input_schema` ist Pflicht; `input_sampling` ist Pflicht, sobald Runtime-Eingaben vorhanden sind. |
| zeitgesteuertes Overlay | `overlay_mode` mit Wert `timed` ist Pflicht; `runtime_input_schema` und `input_sampling` sind unzulässig. |
| Event | Keine Overlay-Felder: `overlay_mode`, `runtime_input_schema` und `input_sampling` sind unzulässig. |

**`Verpflichtend`:** Für jede Definition gilt genau eine der vier Invariantenlisten entsprechend ihres Typs.

---

## 15. Ungültige Kombinationen

Die folgenden Kombinationen sind ungültig und werden strikt abgewiesen:

| Ungültige Kombination | Grund |
|---|---|
| `overlay_mode` in einer State- oder Event-Definition | `overlay_mode` ist nur für Overlays zulässig |
| `runtime_input_schema` ohne kontrolliertes Overlay | `runtime_input_schema` ist nur für kontrollierte Overlays zulässig |
| `input_sampling` ohne Runtime-Eingaben | `input_sampling` ist nur bei Runtime-Eingaben zulässig |
| `overlay_mode: "controlled"` ohne `runtime_input_schema` | `runtime_input_schema` ist bei kontrollierten Overlays Pflicht |
| `overlay_mode: "timed"` mit `runtime_input_schema` | `runtime_input_schema` ist nur für kontrollierte Overlays zulässig |
| Beliebiges unbekanntes Feld | Unbekannte Felder werden strikt abgewiesen |
| Definition ohne `id` | `id` ist verpflichtend |

**`Verpflichtend`:** Jede dieser Kombinationen macht eine Definition ungültig; die Definition wird strikt abgewiesen.

Kanonischer Ausschnitt einer ungültigen Definition:

```json
{
  "id": "example:invalid",
  "overlay_mode": "controlled",
  "runtime_input_schema": {},
  "unknown_field": true
}
```

Diese Definition wird abgewiesen: `unknown_field` ist ein unbekanntes Feld.

---

## 16. Verweis auf vollständige Beispiele

Vollständige Definitionen werden nicht in dieser Referenz abgedruckt.

**`Verpflichtend`:** Vollständige Beispielquellen befinden sich in `effect-development`; diese Referenz enthält ausschließlich kleine kanonische Ausschnitte.

**`Verpflichtend`:** Die Ausschnitte dieser Referenz ersetzen die vollständigen Definitionen nicht; für jede konkrete Definition gelten die Effektquellen in `effect-development` zusammen mit den Regeln dieses Kapitels.

### Überführung der bisherigen Schemadatei

Die bisherige V2-Schemadatei `planning/lefx_schema_v2.md` wird in diese aktuelle Referenz überführt. Am alten Ort verbleibt nur ein Archivhinweis:

```markdown
> Archivhinweis: Diese Datei wurde in die Referenz „Kapitel 5: Schema V2"
> (kapitel5_doku_runde1.md) überführt. Aktueller Stand: siehe dort.
```

---

## Entscheidungen zu Kapitel 5

Die folgenden Festlegungen gelten für dieses Kapitel verbindlich:

| Kennung | Festlegung | Inhalt |
|---|---|---|
| 5A | Festgelegt | Deutscher Erklärungstext; technische Feld- und Enum-Namen bleiben unverändert englisch. |
| 5B | Festgelegt | Vollständige Feldreferenz in diesem Kapitel; vollständige Effektquellen werden nur verlinkt. |
| 5C | Festgelegt | Regeln werden sichtbar als `Verpflichtend`, `Bedingt`, `Optional` oder `Empfehlung` gekennzeichnet. |
| 5D | Festgelegt | Die bisherige V2-Schemadatei aus `planning` wird in die neue Referenz überführt; am alten Ort verbleibt nur ein Archivhinweis. |
