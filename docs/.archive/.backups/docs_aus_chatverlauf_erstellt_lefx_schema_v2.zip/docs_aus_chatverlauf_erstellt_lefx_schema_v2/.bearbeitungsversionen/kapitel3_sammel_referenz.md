# Kapitel 3: Layer und Komposition

**Ziel:** Verständlich zeigen, wie laufende Instanzen angeordnet, ersetzt, aktualisiert und beendet werden.

## Gliederung

1. Layer als interne Engine-Struktur
2. Prioritätsstapel
3. Background State und Primary State
4. Setzen, Ersetzen und Löschen eines States
5. Lifecycle eines kontrollierten Overlays
6. Lifecycle eines zeitgesteuerten Overlays
7. Event-Queue
8. Transparenz und Komposition
9. Rückkehr zum darunterliegenden Bild
10. Verantwortung der Engine

## 3.1 Layer als interne Engine-Struktur

Layer sind eine interne Struktur der Engine. Sie ordnen die laufenden Instanzen vertikal an und bestimmen, welche Anzeige über welcher anderen liegt. Aufrufer wählen keine beliebigen Layer: Die öffentliche freie Layerauswahl ist ausdrücklich ausgeschlossen. Welche Ebene eine Instanz erhält, bestimmen der Typ der Definition und – bei Overlays – der Overlay-Modus; die Platzierung geschieht damit vollständig innerhalb der Engine.

Die Lesbarkeit steht an erster Stelle: Im Dialog werden die lesbaren Schichtnamen verwendet, die technischen Enum-Namen stehen ergänzend dabei. Die folgende Tabelle ordnet beides zu.

| Lesbarer Name | Technischer Enum-Name |
|---|---|
| Event | `EVENT_LAYER` |
| Controlled Overlay | `ONGOING_OVERLAY_LAYER` |
| Timed Overlay | `TEMP_OVERLAY_LAYER` |
| Primary State | `STATE_LAYER` |
| Background State | `BACKGROUND_STATE_LAYER` |

## 3.2 Prioritätsstapel

Der Layer-Stapel ist ein fester Prioritätsstapel. Seine Reihenfolge von oben nach unten ist verbindlich:

```text
Event                  (EVENT_LAYER)
Controlled Overlay     (ONGOING_OVERLAY_LAYER)
Timed Overlay          (TEMP_OVERLAY_LAYER)
Primary State          (STATE_LAYER)
Background State       (BACKGROUND_STATE_LAYER)
```

Die Reihenfolge wird bewusst beibehalten, insbesondere Controlled Overlay über Timed Overlay: Eine laufende Funktionsanzeige bleibt sichtbar, während darunter zeitlich begrenzte Anzeigen laufen. Wirklich priorisierte Unterbrechungen gehören nicht in die Overlay-Ebenen, sondern auf die Event-Ebene ganz oben.

Die Ebenen liegen übereinander; obere Ebenen werden über den unteren komponiert. Die Ebenen können dabei transparent sein: Transparente Frames geben den darunterliegenden Wert frei (siehe Abschnitt 3.8).

```mermaid
flowchart TB
    E["Event (EVENT_LAYER)"]
    CO["Controlled Overlay (ONGOING_OVERLAY_LAYER)"]
    TO["Timed Overlay (TEMP_OVERLAY_LAYER)"]
    PS["Primary State (STATE_LAYER)"]
    BS["Background State (BACKGROUND_STATE_LAYER)"]
    N["Hinweis: Die Ebenen liegen übereinander; jede Ebene kann transparente Frames liefern (None = darunterliegenden Wert erhalten)."]
    E --- CO
    CO --- TO
    TO --- PS
    PS --- BS
    N -.-> E
    classDef top fill:#fce4ec,stroke:#b71c1c;
    classDef overlay fill:#e3f2fd,stroke:#0d47a1;
    classDef state fill:#e8f5e9,stroke:#1b5e20;
    class E top;
    class CO,TO overlay;
    class PS,BS state;
```

*Schaubild 3.1: Layer-Stapel von oben nach unten mit lesbaren Namen und ergänzenden Enum-Namen.*

## 3.3 Background State und Primary State

Der Stapel kennt zwei unterschiedliche State-Plätze: Background State und Primary State. Sie sind zwei getrennte Ebenen, keine Varianten desselben Platzes. Der Background State bildet die unterste Ebene des Stapels, der Primary State liegt darüber. Die beiden Plätze bleiben auch dann getrennt, wenn nur einer von ihnen belegt ist.

## 3.4 Setzen, Ersetzen und Löschen eines States

States werden über Steuerungskommandos geführt. Es gibt drei Kommandos:

| Steuerungskommando | Wirkung |
|---|---|
| Setzen | platziert einen State auf dem vorgesehenen State-Platz |
| Ersetzen | tauscht die laufende Instanz auf dem State-Platz aus |
| Löschen | beendet die laufende Instanz auf dem State-Platz |

```mermaid
sequenceDiagram
    participant A as Aufrufer
    participant E as Engine
    Note over E: Stapel mit Background State und Primary State
    A->>E: Steuerungskommando „State setzen“
    E->>E: platziert den State auf dem State-Platz
    A->>E: Steuerungskommando „State ersetzen“
    E->>E: ersetzt die laufende Instanz auf dem State-Platz
    A->>E: Steuerungskommando „State löschen“
    E->>E: beendet die Instanz; das darunterliegende Bild wird sichtbar
```

*Schaubild 3.2: Ablauf der Steuerungskommandos für einen State.*

Zeitachse des States – die Lebensdauer der Instanz ist unbestimmt; die Kommandos Setzen, Ersetzen und Löschen markieren die Eingriffe:

```mermaid
gantt
    title Lebenszyklus: State (Zeitachse)
    dateFormat X
    axisFormat %s
    section Lebensdauer der Instanz
    Instanz aktiv (unbestimmt): 0, 100
    section Steuerungskommandos
    Setzen: 0, 0
    Ersetzen: 40, 40
    Löschen: 80, 80
```

*Schaubild 3.3: Zeitachse des States mit Steuerungskommandos.*

## 3.5 Lifecycle eines kontrollierten Overlays

Für jede Lebenszyklusform sind drei Zeitdimensionen zu trennen: die Lebensdauer der Instanz, die zeitliche Animation ihres Frames und die Aktualisierung ihrer Runtime-Eingaben.

| Zeitdimension | Bedeutung |
|---|---|
| Lebensdauer einer Instanz | wie lange die laufende Instanz existiert |
| zeitliche Animation ihres Frames | wie sich das Frame im Verlauf der Zeit entwickelt |
| Aktualisierung ihrer Runtime-Eingaben | ob Eingaben während der Laufzeit geändert werden können |

Ein kontrolliertes Overlay hat eine unbestimmte Lebensdauer: Die Instanz bleibt, bis sie beendet wird. Ihre Frames entwickeln sich zeitlich (Animation). Ihre Runtime-Eingaben können während der Laufzeit aktualisiert werden; Push und Pull beschreiben, wie die Engine die Frames bezieht (siehe Kapitel 4, Abschnitt 4.3).

```mermaid
gantt
    title Lebenszyklus: kontrolliertes Overlay (Zeitachse)
    dateFormat X
    axisFormat %s
    section Lebensdauer der Instanz
    Instanz aktiv (unbestimmt): 0, 100
    section Zeitliche Animation des Frames
    Frames entwickeln sich zeitlich: 0, 100
    section Aktualisierung der Runtime-Eingaben
    Eingaben aktualisierbar: 0, 100
```

*Schaubild 3.4: Zeitachse des kontrollierten Overlays mit den drei getrennten Zeitdimensionen.*

## 3.6 Lifecycle eines zeitgesteuerten Overlays

Ein zeitgesteuertes Overlay hat eine endliche Lebensdauer. Nach der Aktivierung ist es nicht aktualisierbar; die Engine beendet die Instanz am Ende der Laufzeit. Auch hier sind die drei Zeitdimensionen getrennt zu betrachten: Die Instanz lebt endlich, die Frames entwickeln sich zeitlich, und die Runtime-Eingaben werden nicht aktualisiert.

```mermaid
gantt
    title Lebenszyklus: zeitgesteuertes Overlay (Zeitachse)
    dateFormat X
    axisFormat %s
    section Lebensdauer der Instanz
    Instanz aktiv (endlich): 0, 30
    section Zeitliche Animation des Frames
    Frames entwickeln sich zeitlich: 0, 30
    section Aktualisierung der Runtime-Eingaben
    nach Aktivierung nicht aktualisierbar: 0, 30
```

*Schaubild 3.5: Zeitachse des zeitgesteuerten Overlays.*

## 3.7 Event-Queue

Events sind endlich, priorisiert und nicht nachträglich veränderbar. Die Engine verwaltet die Event-Queue; Events erreichen über sie die oberste Ebene des Stapels, die Event-Ebene. Als priorisierte Unterbrechungen liegen Events über allen anderen Ebenen.

```mermaid
gantt
    title Lebenszyklus: Event (Zeitachse)
    dateFormat X
    axisFormat %s
    section Lebensdauer der Instanz
    Instanz aktiv (endlich, priorisiert): 0, 8
    section Aktualisierung
    nicht nachträglich veränderbar: 0, 8
    section Zustellung
    Eingang über die Event-Queue: 0, 0
```

*Schaubild 3.6: Zeitachse des Events.*

## 3.8 Transparenz und Komposition

Die Ebenen des Stapels werden übereinander komponiert; einzelne Ebenen können transparent sein. `None` bedeutet bei transparenten Frames: darunterliegenden Wert erhalten. Ein transparentes Frame einer oberen Ebene gibt damit den Farbwert der darunterliegenden Ebene frei, statt ihn zu überdecken.

```mermaid
flowchart LR
    subgraph S["Ausschnitt des Stapels (von oben nach unten)"]
        direction TB
        A["Controlled Overlay — Frame = None (transparent)"]
        B["Timed Overlay — Frame mit Farbwert"]
        C["Primary State — Frame mit Farbwert"]
        A --- B --- C
    end
    R["Sichtbares Bild: Der transparente Frame des Controlled Overlays gibt den Farbwert des Timed Overlays frei."]
    S --> R
```

*Schaubild 3.7: Komposition mit transparentem Frame; `None` erhält den darunterliegenden Wert.*

## 3.9 Rückkehr zum darunterliegenden Bild

Wird eine laufende Instanz beendet oder gelöscht, fällt ihre Ebene weg und das darunterliegende Bild wird wieder sichtbar. Das gilt für alle Ebenen: Endet ein Overlay, erscheint darunter der State; wird ein State gelöscht, erscheint darunter der jeweils andere State-Platz beziehungsweise der Background State.

## 3.10 Verantwortung der Engine

Die Engine trägt die Verantwortung für den Lebenszyklus im Stapel:

- Sie beendet endliche Instanzen (zeitgesteuerte Overlays und Events) selbst.
- Sie verwaltet die Event-Queue.
- Sie führt die Komposition der übereinanderliegenden Ebenen aus.
- Sie bestimmt die Platzierung jeder Instanz – Aufrufer wählen keine Layer.

Ein Paket besitzt keinen parallelen Lifecycle: Pakete führen keinen eigenen Lebenszyklus neben den laufenden Instanzen.

## Entscheidungen zu Kapitel 3

1. **Reihenfolge beibehalten:** Controlled Overlay liegt über Timed Overlay. Wirklich priorisierte Unterbrechungen gehören auf die Event-Ebene.
2. **Öffentliche freie Layerauswahl ausgeschlossen:** Aufrufer wählen keine beliebigen Layer; Typ und Overlay-Modus bestimmen die interne Platzierung.
3. **Layer als interne Engine-Struktur:** Die Erklärung erfolgt mit einem Schaubild der übereinanderliegenden, auch transparenten Layer (Schaubilder 3.1 und 3.7).

---

