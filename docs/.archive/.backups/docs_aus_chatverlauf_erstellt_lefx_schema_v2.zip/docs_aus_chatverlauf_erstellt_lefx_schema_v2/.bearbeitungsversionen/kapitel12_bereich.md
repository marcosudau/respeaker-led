### AGENT_020

Kapitel 9 bis 11 sind verbindlich festgehalten. Damit kommen die letzten drei Planungspunkte.

## 1. Kapitel 12: Status und Ausblick

**Ziel:** Klar trennen zwischen umgesetzt, verifiziert, noch offen und nur als Zukunftsidee vorgemerkt.

#-> Gliederung

1. Status von LEFX V2
2. umgesetzte Kernfunktionen
3. verifizierte Bereiche
4. bewusst offene Arbeiten
5. Stand der DoA-Integration
6. Überarbeitung des produktiven Effektkatalogs
7. Kompatibilitätsgrenzen
8. mögliche V3-Themen
9. Verweis auf das historische Archiv

Zentrale Statusmatrix:

| Status | Bedeutung |
|---|---|
| Implementiert | Bestandteil des aktuellen Systems |
| Verifiziert | durch automatisierte oder praktische Prüfung bestätigt |
| Offen | gehört grundsätzlich noch zur aktuellen Ausbaustufe |
| V3-Idee | nicht beschlossen und nicht Teil von V2 |

**Wichtige Aussagen:**

- Schema, Runtime, CLI/API, Build und Paketvalidierung von V2 sind umgesetzt.
- Die ReSpeaker-Firmware mit entkoppelten DoA-Werten ist installiert.
- Die produktive Live-USB-Integration ist noch getrennt fertigzustellen.
- Die mitgelieferten Definitionen werden noch qualitativ überarbeitet und thematisch gruppiert.
- LEFX-V1-Pakete werden nicht automatisch geraten oder still konvertiert.
- Lifecycle-Hooks bleiben eine V3-Idee.
- Ausführliche Entwicklungsgeschichte gehört ausschließlich ins Archiv.

**Empfehlung:** Keine ständig veraltende Aufgabenliste und keine feste Testanzahl aufnehmen. Der Abschnitt beschreibt dauerhafte Fähigkeiten und bekannte Grenzen.

## 2. Zielstruktur von `docs`

```text
docs/
├── index.md
├── getting_started.md
├── api_guide.md
├── troubleshooting.md
├── effects.md
│
├── effect-system/
│   ├── README.md
│   └── 01 bis 12
│
├── effect-development/
│   ├── templates/
│   ├── tutorials/
│   └── snippets/
│
├── examples/
│   └── effects/
│
├── dev/
│   ├── index.md
│   ├── architecture.md
│   ├── build.md
│   └── public_entry_points.md
│
├── planning/
│   ├── index.md
│   └── v3/
│
└── archive/
    ├── README.md
    ├── project-history/
    ├── effect-concepts/
    ├── sanitation-reports/
    └── prompts/
```

**Einordnung des Bestands:**

- `effects.md` bleibt ein kurzer Verteiler.
- `current_approach.md` wird in aktuelle Architekturkapitel eingearbeitet.
- `presets.md` geht in Kapitel 8 auf.
- `lefx_schema_v2.md` geht in Kapitel 5 auf.
- `reports/*` wandert unter `archive/sanitation-reports/`.
- `history_and_legacy/*` wandert unter `archive/project-history/`.
- Alte Effektkonzepte und die Reihe `konzept_effekt_dateien` wandern unter `archive/effect-concepts/`.
- Abgearbeitete Prompts wandern unter `archive/prompts/`.
- Die V3-Lifecycle-Idee wandert aus `effect-development` nach `planning/v3/`.
- Unter `planning` bleiben danach nur tatsächlich offene Planungen.

Jeder Archivbereich erhält eine README mit dem Hinweis, dass die Inhalte historisch und nicht normativ sind.

## 3. Bereinigungs- und Migrationsverfahren

1. Neue Ist-Dokumentation vollständig schreiben.
2. Für jede alte Datei festhalten, welche Aussagen übernommen wurden.
3. Zielpfad jeder Bestandsdatei in einer Migrationstabelle dokumentieren.
4. Alle internen Links auf die neue Struktur umstellen.
5. Historisch einzigartige Dateien ins Archiv verschieben.
6. Exakte Duplikate und leere Zwischenartefakte separat auflisten.
7. Erst nach deiner Freigabe diese leeren oder vollständig redundanten Dateien entfernen.
8. Markdown-Links und referenzierte Pfade automatisiert prüfen.
9. Archiv und aktuelle Doku deutlich gegeneinander kennzeichnen.
10. Die Dokumentationsmigration im späteren gemeinsamen V2-Commit mitführen.

Für wichtige alte Einstiegspfade würde ich nur dort kleine Verweisdateien behalten, wo reale externe oder interne Links wahrscheinlich weiterbestehen. Ansonsten vermeiden wir einen neuen Bestand aus zahllosen Weiterleitungsdateien.

**Letzte Entscheidungen:**

- **12A:** Kapitel 12 wie beschrieben, ohne volatile Aufgabenliste? Empfehlung: Ja.
- **12B:** Zielstruktur übernehmen? Empfehlung: Ja.
- **12C:** Historisch einzigartige Inhalte archivieren, leere und exakte Duplikate erst nach separater Freigabeliste löschen? Empfehlung: Ja.
- **12D:** Nur für wirklich relevante alte Einstiegspfade Verweisdateien behalten? Empfehlung: Ja.



### USER__021 -> Dokumentationsfahrplan verbindlich festgehalten

Ja, ich würde in der Dokumentation die alten Dateien eigentlich alle archivieren, aber halt in einem Archiv, weißt du? Aber ansonsten, ja, ist auch wieder genau meine Vorstellung. Also stimme ich auch in allen Punkten zu.


