# Kapitel 1: Überblick und Grundidee

**Dokumentationsreihe:** LEFX Schema V2 – Effektsystem-Dokumentation
**Status:** Inhaltlich freigegeben (festgehalten im Dokumentationsfahrplan `effect_system_documentation_roadmap.md`)

## Ziel dieses Kapitels

Nach der Lektüre dieses Kapitels soll das Effektsystem grundsätzlich verstanden sein, ohne dass bereits Schemafelder, Commands oder Layerdetails bekannt sein müssen. Es geht um das Bild im Kopf, nicht um technische Einzelheiten: Welche Objekte das System kennt, warum die Logik getrennt wurde, wer welche Verantwortung trägt und wie ein vollständiger Datenfluss aussieht. Die verbindlichen Detaildefinitionen folgen ab Kapitel 2.

### Schwerpunkte

- Autonomie der Effektpakete
- Der Controller kennt Verträge, keine konkrete Effektbedeutung
- Drei Typen, aber zwei Overlay-Modi
- Definition, Paket und laufende Instanz sind unterschiedliche Dinge
- DoA als Beispiel für die saubere Verantwortungsgrenze

### Bewusst nicht behandelt

Schemafelder, vollständige Layerregeln, Heartbeatdetails, ID-Auflösung und Buildbefehle werden in diesem Kapitel bewusst noch nicht ausführlich behandelt. Sie sind Gegenstand der nachfolgenden Kapitel.

---

## 1. Was ist das Effektsystem?

Das Effektsystem ist der Bestandteil des LED-Controllers, der die visuellen Aufgaben auf dem LED-Ring übernimmt. Es steuert, was auf dem Ring zu sehen ist, und stellt dafür unterschiedliche visuelle Aufgaben bereit.

Das System lässt sich durch vier grundlegende Eigenschaften beschreiben:

- **Steuerung eines LED-Rings:** Das Effektsystem erzeugt die Darstellung, die auf dem LED-Ring ausgegeben wird.
- **Unterschiedliche visuelle Aufgaben:** Es deckt verschiedene Anzeigeformen ab, vom dauerhaften Grundzustand über laufend aktualisierte Anzeigen bis zu kurzen, einmaligen Signalen.
- **Trennung zwischen Controller und visueller Fachlogik:** Der Controller selbst enthält keine visuelle Fachlogik; er stellt nur den Rahmen bereit, in dem diese Logik ausgeführt wird.
- **Erweiterbarkeit durch eigenständige Pakete:** Neue visuelle Aufgaben können als eigenständige Pakete ergänzt werden, ohne das Hauptprogramm zu verändern.

Konkreter Hauptanwendungsfall ist der ReSpeaker. Die Architektur des Systems ist jedoch nicht an diese Hardware gebunden: Das Effektsystem funktioniert unabhängig davon, welche Hardware die Werte liefert. Der ReSpeaker bleibt als Anwendungsfall sichtbar, die Architektur bleibt allgemein gehalten.

An dieser Stelle genügt dieses grundsätzliche Bild. Technische Erklärungen, etwa zu Schemafeldern oder einzelnen Kommandos, folgen in den späteren Kapiteln.

## 2. Warum wurde die Logik getrennt?

Die Trennung von Controller und visueller Fachlogik ist das Ergebnis einer bewussten Neuausrichtung. In der ursprünglichen Umsetzung waren die Effekte direkt im Controller hartkodiert. Dadurch kannte der Controller konkrete Effekte und ihre Bedeutung: Er wusste nicht nur, *dass* ein Effekt läuft, sondern auch, *was* er fachlich bedeutet. Jede Änderung an einem Effekt erforderte eine Änderung am Hauptprogramm.

LEFX V2 kehrt dieses Verhältnis um:

- Darstellung, Parametersemantik und Presets wandern in autonome Pakete.
- Die Engine kennt nur noch allgemeine Typ- und Lifecycle-Verträge.
- Der Controller behandelt alle Pakete gleich; die konkrete visuelle Bedeutung liegt ausschließlich im jeweiligen Paket.

Der Unterschied zwischen früher und heute lässt sich in vier Zeilen zusammenfassen:

| Früher | V2 |
|---|---|
| Controller kennt konkrete Effekte | Controller kennt nur Typverträge |
| Effektlogik im Hauptcode | Effektlogik im LEFX-Paket |
| Gemeinsame Sonderlogik | Autarke Paketlogik |
| Bedeutung durch Layer oder Preset veränderbar | Typ und Lebenszyklus unveränderlich |

**Schwerpunkt:** Es geht nicht um die Entwicklungsgeschichte. Ein kurzer Vorher-Nachher-Vergleich genügt, um die Motivation hinter der Trennung zu verstehen.

## 3. Das mentale Grundmodell

Das gesamte System lässt sich auf eine Kette von vier Objekten zurückführen. Wer diese Kette versteht, versteht die Grundarchitektur:

```mermaid
flowchart LR
    Q["LEFX-Quelle<br/>(bearbeitbares Verzeichnis)"] --> P["LEFX-Paket<br/>(gebautes Artefakt, .lefx)"]
    P --> D["geladene Definition<br/>(beschreibt genau einen State,<br/>ein Overlay oder ein Event)"]
    D --> I["laufende Instanz<br/>(aktuell laufende Ausführung)"]
```

Die vier Objekte der Kette sowie der Preset als fünftes, begleitendes Objekt:

- **LEFX-Quelle:** Die Quelle ist das bearbeitbare Verzeichnis. Hier entsteht der Effekt; hier wird gearbeitet und verändert.
- **LEFX-Paket:** Das Paket ist das gebaute Artefakt. Eine LEFX-Datei ist das Ergebnis des Builds – die Form, in der eine visuelle Definition ausgeliefert und geladen wird.
- **Definition:** Eine Definition beschreibt genau einen State, ein Overlay oder ein Event. Sie ist die Beschreibung, nicht die Ausführung.
- **Laufende Instanz:** Eine Instanz ist die aktuell laufende Ausführung einer Definition. Sie entsteht beim Aktivieren und endet, wenn ihre Laufzeit vorbei ist oder sie beendet wird.
- **Preset:** Ein Preset ist nur eine vorbereitete Konfiguration. Er ist kein eigener Typ und keine eigene Definition, sondern legt fest, mit welchen Werten eine Definition gestartet wird.

Daraus folgt ein zentraler Grundsatz, der sich durch die gesamte Dokumentation zieht: **Definition, Paket und laufende Instanz sind unterschiedliche Dinge.** Das Paket enthält die Definition, die Instanz führt sie aus – beide sind weder miteinander noch mit dem Paket identisch. Die verbindlichen Detaildefinitionen dieser Objekte kommen erst in Kapitel 2.

## 4. Drei Typen, vier Lebenszyklusformen

Das Effektsystem kennt drei fachliche Typen:

- **State** – der dauerhafte Grundzustand der Anzeige.
- **Overlay** – eine darüberliegende, zusätzliche Anzeige.
- **Event** – ein einmaliges, priorisiertes Signal.

Die Overlays besitzen zwei klar getrennte Modi:

- **kontrolliert** – die Anzeige wird laufend aktualisiert.
- **zeitgesteuert** – die Anzeige ist zeitlich begrenzt und läuft nach der Aktivierung selbstständig ab.

Diese Formulierung ist bewusst gewählt: Sie vermeidet sowohl die Vorstellung von „vier Effekttypen“ als auch das Verstecken der fundamentalen Unterschiede zwischen den beiden Overlay-Modi. Das System spricht deshalb von **drei Typen, aber vier Lebenszyklusformen**.

Eine sehr kurze Entscheidungshilfe ordnet typische Anzeigeaufgaben dem passenden Typ beziehungsweise Modus zu:

| Anzeigeaufgabe | Typ beziehungsweise Modus |
|---|---|
| Dauerhafter Grundzustand | State |
| Laufend aktualisierte Anzeige | Kontrolliertes Overlay |
| Zeitlich begrenzte Einblendung | Zeitgesteuertes Overlay |
| Einmaliges priorisiertes Signal | Event |

Die ausführliche Behandlung der Typen und ihrer Lebenszyklen erfolgt in Kapitel 4.

## 5. Verantwortungsgrenzen

Die Verantwortungsgrenzen zwischen den Bestandteilen des Systems gehören zu den wichtigsten Aussagen dieses Kapitels. Sie legen fest, wer für was zuständig ist – und wer ausdrücklich nicht:

| Bestandteil | Verantwortung |
|---|---|
| LEFX-Paket | Darstellung, Parameter, Presets und Effektlogik |
| Engine | Lebenszyklus, Layer, Komposition und Hardwareausgabe |
| Integration | Hardwarewerte und anwendungsspezifische Daten |
| CLI/API | validierte Steuerung des Systems |

Die einzelnen Rollen im Überblick:

- **LEFX-Paket:** Das Paket ist der Ort der visuellen Fachlogik. Es entscheidet, wie etwas dargestellt wird, welche Parameter es gibt und welche Presets angeboten werden.
- **Engine:** Die Engine verwaltet den Betrieb: Sie führt Lebenszyklen aus, hält Layer und Komposition zusammen und übernimmt die Hardwareausgabe.
- **Integration:** Integrationen liefern die Werte von außen. Sie bringen Hardwarewerte und anwendungsspezifische Daten in das System ein.
- **CLI/API:** Die Schnittstelle ermöglicht die validierte Steuerung des Systems. Kommandos werden geprüft, bevor sie wirken.

> **Kernaussage:** Der Controller soll wissen, wie ein Overlay grundsätzlich funktioniert, aber nicht, was `doa_direction` fachlich bedeutet. Die fachliche Bedeutung eines Wertes gehört ins Paket, die allgemeine Mechanik in die Engine.

Diese Grenze gilt bereits in Kapitel 1 ausdrücklich und verbindlich: **LEFX-Pakete besitzen keinen eigenen Lifecycle-Thread und keine Controllerzugriffe.** Controllerzugriffe sind klar ausgeschlossen; Threads und weitere technische Einzelheiten werden erst in Kapitel 11 behandelt.

## 6. Ein vollständiger Datenfluss

Zwei Beispiele zeigen, wie die Bestandteile aus Abschnitt 5 im Zusammenspiel funktionieren. Das erste Beispiel führt den Datenfluss mit DoA durch das gesamte System; das zweite zeigt einen einfacheren Ablauf über die CLI.

### 6.1 DoA: der Weg vom ReSpeaker bis zum LED-Frame

DoA eignet sich als erstes durchgängiges Beispiel, weil es alle Verantwortungsgrenzen sichtbar macht:

```mermaid
flowchart LR
    A["ReSpeaker"] --> B["DoA-Integration"]
    B --> C["Overlay-Channel"]
    C --> D["Engine"]
    D --> E["DoA-LEFX"]
    E --> F["LED-Frame"]
```

Der Ablauf Schritt für Schritt:

1. **ReSpeaker:** Die Hardware liefert die Werte, die das System verarbeiten soll.
2. **DoA-Integration:** Die Integration übernimmt die Hardwarewerte und bringt sie in das System ein. Hardwarezugriffe und anwendungsspezifische Zuordnung gehören in die Integration, nicht in das Paket.
3. **Overlay-Channel:** Über den Overlay-Channel werden die Werte an die Engine übergeben. Der Channel ist der Weg, auf dem die laufende Anzeige mit aktuellen Werten versorgt wird.
4. **Engine:** Die Engine stellt die Werte der Definition bereit. Sie verwaltet Lebenszyklus, Layer und Komposition, mischt sich aber nicht in die fachliche Bedeutung der Werte ein.
5. **DoA-LEFX:** Das Paket kennt die fachliche Bedeutung – etwa, was `doa_direction` bedeutet – und rendert daraus die Frames. Darstellung und Parametersemantik liegen ausschließlich hier.
6. **LED-Frame:** Das gerenderte Ergebnis wird als Frame an die Hardwareausgabe übergeben und auf dem LED-Ring sichtbar.

Genau an diesem Beispiel wird die saubere Verantwortungsgrenze deutlich: Die Integration liefert Werte, die Engine organisiert den Betrieb, und nur das Paket weiß, was die Werte fachlich bedeuten.

### 6.2 Ein einfacheres Beispiel: Event über die CLI

Das zweite Beispiel zeigt, wie ein einmaliges Signal über die CLI ausgelöst wird und wieder endet:

```mermaid
flowchart LR
    A["CLI: emit event short_pulse"] --> B["Validierung"]
    B --> C["Event-Queue"]
    C --> D["LEFX rendert Frames"]
    D --> E["Engine beendet das Event nach seiner Dauer"]
```

Der Ablauf Schritt für Schritt:

1. **CLI: `emit event short_pulse`** – Das Steuerungskommando wird über die Schnittstelle eingegeben.
2. **Validierung** – Die CLI/API validiert das Kommando. Nur geprüfte Kommandos wirken auf das System.
3. **Event-Queue** – Das validierte Event wird in die Event-Queue eingereiht und dort der Reihe nach abgearbeitet.
4. **LEFX rendert Frames** – Das zuständige LEFX-Paket rendert die Frames des Events.
5. **Engine beendet das Event nach seiner Dauer** – Nach Ablauf der festgelegten Dauer beendet die Engine das Event; es ist endlich und hinterlässt keine eigene Laufzeit.

## 7. Artefakte in einem Satz

Am Kapitelende die Artefakte des Systems in je einem Satz:

| Artefakt | Bedeutung in einem Satz |
|---|---|
| `.lefx` | Genau eine vollständige visuelle Definition. |
| `.lefxset` | Sammlung mehrerer LEFX-Artefakte. |
| Preset | Konfiguration einer Definition, kein eigener Effekttyp. |

Ein `.lefx`-Artefakt enthält also genau eine Definition, ein `.lefxset` bündelt mehrere solche Artefakte, und ein Preset legt lediglich fest, mit welcher Konfiguration eine Definition verwendet wird.

## 8. Nächste Einstiege

Je nach Interesse führen die folgenden Wege weiter:

- **Systembegriffe verstehen** → Kapitel 2: Begriffe und Systemobjekte – die Objektkette und ihre verbindlichen Definitionen.
- **Typen und Lebenszyklen vergleichen** → Kapitel 4: Typen und Lebenszyklen – die vier Lebenszyklusformen im Detail.
- **CLI/API verwenden** → Kapitel 9: Bedienung über CLI und API – Steuerungskommandos und ihre Wirkung.
- **Eigenen Effekt entwickeln** → Bereich Effektentwicklung (`effect-development`) – Templates, Tutorials und Snippets.
- **Paket bauen** → Kapitel 10: Validierung und Build – der Weg von der Quelle zum geprüften Paket.

---

## Entscheidungen zu Kapitel 1

Die folgenden vier Festlegungen sind für dieses Kapitel verbindlich und inhaltlich freigegeben:

1. **Direkter Einstieg ins heutige Modell.** Das Kapitel beginnt direkt mit dem heutigen Modell des Systems. Die frühere Hartkodierung wird nur als kurze Motivation erwähnt, nicht als Entwicklungsgeschichte erzählt.

2. **„Effektsystem“ als allgemeiner Oberbegriff.** „Effektsystem“ wird weiterhin als allgemeiner Oberbegriff verwendet. Innerhalb der Erklärung wird konsequent von State, Overlay, Event, Definition, Paket und Instanz gesprochen.

3. **ReSpeaker als Hauptanwendungsfall, hardwareunabhängige Architektur.** Der ReSpeaker bleibt deutlich als konkreter Hauptanwendungsfall sichtbar, obwohl LEFX V2 technisch nicht an diese Hardware gebunden ist. Die Architektur ist allgemein gehalten; der ReSpeaker ist der konkrete Anwendungsfall.

4. **Keine Threads und keine Controllerzugriffe in LEFX-Paketen.** Das Kapitel sagt bereits hier klar und ausdrücklich: LEFX-Pakete besitzen keinen eigenen Lifecycle-Thread und keine Controllerzugriffe. Controllerzugriffe werden klar ausgeschlossen; Threads und technische Einzelheiten werden erst in Kapitel 11 behandelt.
