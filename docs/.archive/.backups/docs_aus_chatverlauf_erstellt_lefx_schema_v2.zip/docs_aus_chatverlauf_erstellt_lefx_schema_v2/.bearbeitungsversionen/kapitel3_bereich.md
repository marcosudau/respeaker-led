### AGENT_017

Kapitel 2 ist mit deinen Änderungen im Fahrplan festgehalten. Hier kommen die Kapitel 3 bis 5 gemeinsam.

## Kapitel 3: Effekttypen

**Ziel:** Der Leser soll sicher entscheiden können, welcher Typ und welcher Lebenszyklus zu seiner Anzeige passt.

#-> Gliederung

1. Vergleichsmatrix aller Lebenszyklusformen
2. State
3. Kontrolliertes Push-Overlay
4. Kontrolliertes Pull-Overlay
5. Zeitgesteuertes Overlay
6. Event
7. Entscheidungshilfe
8. Ungültige Kombinationen

Die zentrale Tabelle zeigt:

- Zweck
- Lebensdauer
- Aktivierung
- Aktualisierbarkeit
- Beendigung
- Runtime-Eingaben
- Channel
- Queue
- Komposition

**Schwerpunkte:**

- State, Overlay und Event sind unveränderliche Typen, keine Presetvarianten.
- Push und Pull sind Datenbeschaffungsarten kontrollierter Overlays.
- Zeitgesteuerte Overlays sind nach der Aktivierung nicht aktualisierbar.
- Events sind endlich, priorisiert und nicht nachträglich veränderbar.
- Typvertrag und fachliche Verwendung werden getrennt: Die Regeln sind verbindlich, Beispiele wie DoA oder Fortschrittsanzeige sind Empfehlungen.

**Entscheidungen:**

- **3A:** Drei fachliche Typen, aber vier deutlich dargestellte Lebenszyklusformen?  
  Empfehlung: Ja.
- **3B:** Push und Pull als Untervarianten des kontrollierten Overlays erklären?  
  Empfehlung: Ja.
- **3C:** Fachliche Einsatzzwecke als Orientierung, nicht als zusätzliche Schemaeinschränkung behandeln?  
  Empfehlung: Ja.
- **3D:** Vorläufig neutrale Beispiele verwenden, solange der produktive Effektkatalog noch überarbeitet wird?  
  Empfehlung: Ja.

## Kapitel 4: Lifecycle und Layer

**Ziel:** Verständlich zeigen, wie laufende Instanzen angeordnet, ersetzt, aktualisiert und beendet werden.

#-> Layer-Stapel

Der aktuelle V2-Stand ist von oben nach unten:

```text
Event
Controlled Overlay
Timed Overlay
Primary State
Background State
```

Die technischen Enum-Namen stehen ergänzend dabei:

- `EVENT_LAYER`
- `ONGOING_OVERLAY_LAYER`
- `TEMP_OVERLAY_LAYER`
- `STATE_LAYER`
- `BACKGROUND_STATE_LAYER`

#-> Gliederung

1. Layer als interne Engine-Struktur
2. Prioritätsstapel
3. Background State und Primary State
4. Setzen, Ersetzen und Löschen eines States
5. Lifecycle eines kontrollierten Overlays
6. Lifecycle eines zeitgesteuerten Overlays
7. Event-Queue
8. Transparenz und Komposition
9. Rückkehr zum darunterliegenden Bild
10. Verantwortung der Engine

Für jede Lebenszyklusform sollte eine kleine Zeitachse entstehen. Besonders wichtig ist die Trennung zwischen:

- Lebensdauer einer Instanz
- zeitlicher Animation ihres Frames
- Aktualisierung ihrer Runtime-Eingaben

**Schwerpunkte:**

- Aufrufer wählen keine beliebigen Layer.
- Typ und Overlay-Modus bestimmen die interne Platzierung.
- `None` bedeutet bei transparenten Frames: darunterliegenden Wert erhalten.
- Die Engine beendet endliche Instanzen und verwaltet die Event-Queue.
- Ein Paket besitzt keinen parallelen Lifecycle.

**Wichtige Architekturentscheidung:**

Der aktuelle Stand setzt kontrollierte Overlays über zeitgesteuerte Overlays. Ich würde das beibehalten: Eine laufende Funktionsanzeige bleibt sichtbar; wirklich priorisierte Unterbrechungen gehören auf die Event-Ebene.

**Entscheidungen:**

- **4A:** Aktuelle Reihenfolge beibehalten, insbesondere Controlled über Timed Overlay?  
  Empfehlung: Ja.
- **4B:** Lesbare Namen zuerst und technische Enum-Namen ergänzend verwenden?  
  Empfehlung: Ja.
- **4C:** Öffentliche freie Layerauswahl ausdrücklich ausschließen?  
  Empfehlung: Ja.
- **4D:** Background und Primary als zwei unterschiedliche State-Plätze erklären?  
  Empfehlung: Ja.

## Kapitel 5: Schema V2

**Ziel:** Verbindliche technische Referenz für jede gültige Definition.

#-> Gliederung

1. Zweck des Schemas
2. Aufbau einer `EffectDefinition`
3. Identität und Metadaten
4. Typ und Overlay-Modus
5. Konfigurationsschema
6. Runtime-Input-Schema
7. Defaults
8. Capabilities
9. Layer-Regeln
10. Farbmodell und Komposition
11. Animation und Richtung
12. Input-Sampling
13. bedingte Pflichtfelder
14. übergreifende Invarianten
15. ungültige Kombinationen
16. Verweis auf vollständige Beispiele

Die Felder werden in einer Referenztabelle dargestellt:

| Feld | Status | Bedeutung |
|---|---|---|
| `id` | verpflichtend | global eindeutige Definition-ID |
| `overlay_mode` | bedingt | nur für Overlays |
| `runtime_input_schema` | bedingt | nur für kontrollierte Overlays |
| `input_sampling` | bedingt | nur bei Runtime-Eingaben |
| `tags` | optional | Suche und Katalogisierung |

Zusätzlich kommen separate Invariantenlisten für State, kontrolliertes Overlay, zeitgesteuertes Overlay und Event.

**Schwerpunkte:**

- Vollständige Referenz, aber keine riesigen JSON-Ausgaben.
- Kleine kanonische Ausschnitte statt drei vollständiger Definitionen.
- Vollständige Beispiele bleiben in `effect-development`.
- Unbekannte Felder und ungültige Kombinationen werden strikt abgewiesen.
- Die bestehende `planning/lefx_schema_v2.md` wird in diese aktuelle Referenz überführt.

**Entscheidungen:**

- **5A:** Deutscher Erklärungstext, technische Feld- und Enum-Namen unverändert Englisch?  
  Empfehlung: Ja.
- **5B:** Vollständige Feldreferenz, aber vollständige Effektquellen nur verlinken?  
  Empfehlung: Ja.
- **5C:** Regeln sichtbar als `Verpflichtend`, `Bedingt`, `Optional` oder `Empfehlung` kennzeichnen?  
  Empfehlung: Ja.
- **5D:** Die bisherige V2-Schemadatei aus `planning` in die neue Referenz überführen und am alten Ort nur einen Archivhinweis hinterlassen?  
  Empfehlung: Ja.


### USER__018 -> Dokumentation -  Parameter und Werte (Kap. 6), Runtime-Eingaben (Kap.  7), Pakete, IDs und Presets (Kap.  8) 

Ich hätte eine Anmerkung zu Nummer 3B. Und zwar würde ich Push und Pull gar nicht als Untervarianten von so einem Overlay nehmen. Einfach, weil ich finde, dass man die Overlays nicht nur danach unterscheiden kann. Sondern das ist halt ein Aspekt bei diesen, ne, das ist halt quasi, wie die Engine die Frames bezieht. Aber das ist ja jetzt nicht, sage ich mal, der wichtigste Teil eines Effekts. So, da gibt es ja noch ganz viele andere Aspekte. Deshalb ist das halt ein Bereich, in dem es zwei Typen gibt. Aber jetzt generell als Untertypen so hoch würde ich die Sache nicht einschätzen. Und noch eine Sache, die ich anmerken möchte. Ich würde einfach mal den Vorschlag machen wollen, wie wäre es, wenn wir Kapitel 4 vor Kapitel 3 ziehen? Weil ich glaube, das ist wichtiger, dass man zuerst dieses Prinzip mit den Layern verstanden hat, die sich übereinanderziehen und weil sich darauf ja begründet, diese unterschiedlichen Effekttypen. Das ist ja der Knackpunkt an dem System, sage ich mal mehr oder weniger. Und dann kann man auch die verschiedenen Layer, das kann man ruhig dann auch ein bisschen ausführlicher erklären. Und auch gut mit einem Schaubild darstellen, wie die so übereinander sind oder sich übereinanderlegen oder schieben. So, weil die können ja auch transparent sein. Das kann man auch sehr gut an einem Schaubild darstellen. Aber ich würde dir in allen anderen Punkten wieder zustimmen und deinen Vorschlägen folgen.


