# Kapitel 4: Typen und Lebenszyklen

> **Hinweis:** Dieses Dokument enthält Kapitel 4 der technischen Dokumentation zum LED-Controller (LEFX Schema V2). Kapitel 1, 2, 3, 6, 7, 8, 9, 10, 11 und 12 sind laut Dokumentationsfahrplan inhaltlich freigegeben.

| Metadaten | |
|---|---|
| Dokument | Kapitel 4: Typen und Lebenszyklen |
| Produkt | LED-Controller |
| Schema | LEFX Schema V2 |
| Umfang | Typen, Lebenszyklusformen, Bezugsmodi, Entscheidungshilfe, unzulässige Kombinationen |

**Ziel:** Der Leser soll sicher entscheiden können, welcher Typ und welcher Lebenszyklus zur jeweiligen Anzeige passt.

**Inhalt**

1. Vergleichsmatrix aller Lebenszyklusformen
2. State
3. Kontrolliertes Overlay (Push/Pull als Bezugsmodi)
4. Zeitgesteuertes Overlay
5. Event
6. Entscheidungshilfe
7. Ungültige Kombinationen

**Kernaussagen**

- Es gibt drei fachliche Typen: State, Overlay und Event. Sie sind unveränderliche Typen, keine Presetvarianten.
- Das Overlay tritt in zwei Lebenszyklusformen auf: kontrolliert (`controlled`) und zeitgesteuert (`timed`). Insgesamt werden vier Lebenszyklusformen unterschieden.
- Push und Pull sind keine Untervarianten des Overlays, sondern **Bezugsmodi für Runtime-Eingaben** — sie legen fest, wie die Engine Frames bezieht. `overlay_mode` hat ausschließlich die Werte `controlled` und `timed`.
- Der Typvertrag (die Regeln) ist verbindlich; fachliche Einsatzzwecke sind Orientierung. Solange der produktive Effektkatalog überarbeitet wird, werden vorläufig neutrale Beispiele verwendet.

---

## 1. Vergleichsmatrix aller Lebenszyklusformen

### 1.1 Lebenszyklus-Matrix (verbindlich)

| Typ | Modus | Laufzeit | Runtime-Eingaben |
|---|---|---|---|
| State | immer kontrolliert | unbestimmt | nein |
| Overlay | `controlled` | unbestimmt | ja |
| Overlay | `timed` | endlich | nein |
| Event | fest vorgegeben | endlich | nein |

Erläuterung der Zeilen:

- **State:** Läuft immer kontrolliert und unbestimmt lange. Runtime-Eingaben nimmt der State nicht an; Push/Pull kommen für ihn nicht in Betracht.
- **Overlay (`controlled`)** — kontrolliertes Overlay: Läuft unbestimmt lange und empfängt Runtime-Eingaben. Für den Bezug dieser Eingaben stehen die Bezugsmodi Push und Pull bereit.
- **Overlay (`timed`)** — zeitgesteuertes Overlay: Läuft endlich. Runtime-Eingaben sind nicht vorgesehen.
- **Event:** Ist fest vorgegeben, läuft endlich und ist priorisiert. Runtime-Eingaben sind nicht vorgesehen.

### 1.2 Merkmale der zentralen Vergleichstabelle

Die zentrale Vergleichstabelle führt die Lebenszyklusformen entlang der folgenden Merkmale:

**Zweck · Lebensdauer · Aktivierung · Aktualisierbarkeit · Beendigung · Runtime-Eingaben · Channel · Queue · Komposition**

### 1.3 Vergleichsmatrix

Die nachstehende Matrix stellt die vier Lebenszyklusformen gegenüber. Sie verwendet die in der Faktenquelle festgelegten Ausprägungen; Merkmale ohne Festlegung sind mit „–" gekennzeichnet.

| Merkmal | State | Overlay `controlled` | Overlay `timed` | Event |
|---|---|---|---|---|
| Lebensdauer | unbestimmt | unbestimmt | endlich | endlich |
| Aktualisierbarkeit | – | – | nach der Aktivierung nicht aktualisierbar | nicht nachträglich veränderbar |
| Runtime-Eingaben | nein | ja (Push/Pull) | nein | nein |
| Zweck, Aktivierung, Beendigung, Channel, Queue, Komposition | – | – | – | – |

> Zu „–": Diese Merkmale sind Bestandteil der zentralen Vergleichstabelle. Ihre produktiven Ausprägungen sind nicht Gegenstand von Kapitel 4; sie werden in der Schema-Spezifikation (LEFX Schema V2) geführt.

### 1.4 Lebenszyklusformen im Überblick

Das folgende Diagramm fasst die vier Lebenszyklusformen mit Modus, Laufzeit und Runtime-Eingaben zusammen:

```mermaid
flowchart LR
    subgraph State["State"]
        direction TB
        S1["State<br/>(immer kontrolliert)"] --> S2["Laufzeit: unbestimmt"]
        S2 --> S3["Runtime-Eingaben: nein"]
    end
    subgraph OverlayControlled["Kontrolliertes Overlay"]
        direction TB
        C1["Overlay<br/>overlay_mode: controlled"] --> C2["Laufzeit: unbestimmt"]
        C2 --> C3["Runtime-Eingaben: ja (Push/Pull)"]
    end
    subgraph OverlayTimed["Zeitgesteuertes Overlay"]
        direction TB
        T1["Overlay<br/>overlay_mode: timed"] --> T2["Laufzeit: endlich"]
        T2 --> T3["Runtime-Eingaben: nein"]
    end
    subgraph Event["Event"]
        direction TB
        E1["Event<br/>(fest vorgegeben)"] --> E2["Laufzeit: endlich"]
        E2 --> E3["Runtime-Eingaben: nein"]
    end
```

---

## 2. State

**Merkmale**

- Unveränderlicher Typ, keine Presetvariante.
- Modus: immer kontrolliert.
- Laufzeit: unbestimmt.
- Runtime-Eingaben: nein.

**Beschreibung**

Der State ist eine Anzeigeform mit unbestimmter Laufzeit, die immer kontrolliert läuft. Er nimmt keine Runtime-Eingaben an; die Bezugsmodi Push und Pull sind für den State nicht vorgesehen. Da sein Modus immer kontrolliert ist, trägt der State keinen `overlay_mode`-Wert.

**Schematischer Ausschnitt**

```json
{
  "type": "state"
}
```

> Der Ausschnitt dient der Veranschaulichung der Typ-/Modus-Zuordnung. Vollständige Felddefinitionen stellt die Schema-Spezifikation (LEFX Schema V2) bereit.

---

## 3. Kontrolliertes Overlay (Push/Pull als Bezugsmodi)

**Merkmale**

- Unveränderlicher Typ, keine Presetvariante.
- Modus: `controlled` (kontrolliertes Overlay).
- Laufzeit: unbestimmt.
- Runtime-Eingaben: ja.

**Push und Pull als Bezugsmodi**

Push und Pull sind **keine Untervarianten des Overlays** und keine Werte von `overlay_mode`. Sie sind **Bezugsmodi für Runtime-Eingaben**: Sie legen fest, wie die Engine Frames bezieht.

- **Push:** Die Frames werden der Engine zugestellt.
- **Pull:** Die Engine fordert die Frames an.

Die konkrete Ausgestaltung der Bezugsschnittstellen ist nicht Gegenstand dieses Kapitels; hier ist die Einordnung entscheidend: Push und Pull beschreiben den Bezug von Runtime-Eingaben, nicht die Lebenszyklusform.

Daraus folgt für die Gliederung: Es gibt genau einen Abschnitt „Kontrolliertes Overlay"; Push und Pull werden nicht als eigene Punkte geführt.

**Schematischer Ausschnitt**

```json
{
  "type": "overlay",
  "overlay_mode": "controlled"
}
```

**Bezugsmodi im Zusammenhang**

```mermaid
flowchart LR
    R["Runtime-Eingaben"] --> B{"Bezugsmodus:<br/>Wie bezieht die Engine Frames?"}
    B -->|"Push"| P["Frames werden der Engine zugestellt"]
    B -->|"Pull"| U["Die Engine fordert Frames an"]
    P --> O["Kontrolliertes Overlay<br/>(overlay_mode: controlled)"]
    U --> O
    O --> A["Anzeige"]
```

---

## 4. Zeitgesteuertes Overlay

**Merkmale**

- Unveränderlicher Typ, keine Presetvariante.
- Modus: `timed` (zeitgesteuertes Overlay).
- Laufzeit: endlich.
- Runtime-Eingaben: nein.

**Beschreibung**

Das zeitgesteuerte Overlay läuft mit endlicher Laufzeit. Nach der Aktivierung ist es **nicht aktualisierbar**; der Ablauf ist durch die Zeitsteuerung festgelegt. Runtime-Eingaben und damit die Bezugsmodi Push/Pull sind nicht vorgesehen.

**Schematischer Ausschnitt**

```json
{
  "type": "overlay",
  "overlay_mode": "timed"
}
```

---

## 5. Event

**Merkmale**

- Unveränderlicher Typ, keine Presetvariante.
- Modus: fest vorgegeben.
- Laufzeit: endlich.
- Runtime-Eingaben: nein.

**Beschreibung**

Events sind **endlich, priorisiert und nicht nachträglich veränderbar**. Sie sind fest vorgegeben und nehmen keine Runtime-Eingaben an; die Bezugsmodi Push/Pull sind für Events nicht vorgesehen.

**Schematischer Ausschnitt**

```json
{
  "type": "event"
}
```

---

## 6. Entscheidungshilfe

Die Entscheidungshilfe führt anhand von Schema-Merkmalen (Runtime-Eingaben, Laufzeit, Festlegung und Priorisierung) vom Anzeigewunsch zum passenden Typ:

```mermaid
flowchart TD
    A["Welcher Typ passt zur Anzeige?"] --> B{"Werden Runtime-Eingaben benötigt?"}
    B -->|"Ja"| C["Kontrolliertes Overlay<br/>overlay_mode: controlled<br/>Bezugsmodi: Push/Pull"]
    B -->|"Nein"| D{"Ist die Laufzeit unbestimmt?"}
    D -->|"Ja"| E["State<br/>(immer kontrolliert)"]
    D -->|"Nein"| F{"Ist der Inhalt fest vorgegeben und priorisiert?"}
    F -->|"Ja"| G["Event<br/>(endlich, priorisiert)"]
    F -->|"Nein"| H["Zeitgesteuertes Overlay<br/>overlay_mode: timed"]
```

**Leitfragen in Textform**

1. Werden Runtime-Eingaben benötigt? → **Kontrolliertes Overlay** (`controlled`), Bezug der Eingaben über Push/Pull.
2. Keine Runtime-Eingaben und unbestimmte Laufzeit? → **State** (immer kontrolliert).
3. Keine Runtime-Eingaben, endliche Laufzeit, Inhalt fest vorgegeben und priorisiert? → **Event**.
4. Keine Runtime-Eingaben, endliche Laufzeit, sonstiger zeitgesteuerter Ablauf? → **Zeitgesteuertes Overlay** (`timed`).

**Normative und informative Anteile**

Der Typvertrag — die Regeln zu Modus, Laufzeit und Runtime-Eingaben — ist **verbindlich**. Fachliche Einsatzzwecke sind **Orientierung**, keine zusätzliche Schemaeinschränkung; Beispiele wie DoA oder Fortschrittsanzeige sind Empfehlungen. Solange der produktive Effektkatalog noch überarbeitet wird, werden vorläufig neutrale Beispiele verwendet.

---

## 7. Ungültige Kombinationen

Die folgenden Kombinationen sind unzulässig. Grundlage ist jeweils die Lebenszyklus-Matrix (Abschnitt 1.1) beziehungsweise die Korrektur zur Einordnung von Push/Pull (Abschnitt 3).

| Unzulässige Kombination | Grund | Bewertung |
|---|---|---|
| State mit Runtime-Eingaben (Push/Pull) | State nimmt keine Runtime-Eingaben an | unzulässig |
| Zeitgesteuertes Overlay mit Runtime-Eingaben (Push/Pull) | `timed`: Runtime-Eingaben nicht vorgesehen | unzulässig |
| Zeitgesteuertes Overlay nach der Aktivierung aktualisieren | nach der Aktivierung nicht aktualisierbar | unzulässig |
| Event nachträglich verändern | nicht nachträglich veränderbar | unzulässig |
| Event mit Runtime-Eingaben (Push/Pull) | Event nimmt keine Runtime-Eingaben an | unzulässig |
| Push oder Pull als Wert von `overlay_mode` | `overlay_mode` hat nur die Werte `controlled` und `timed`; Push/Pull sind Bezugsmodi, keine Moduswerte | unzulässig |
| `overlay_mode` bei State oder Event | State ist immer kontrolliert, Event ist fest vorgegeben; `overlay_mode` ist nur für Overlays vorgesehen | unzulässig |
| State, Overlay oder Event als Presetvariante | unveränderliche Typen, keine Presetvarianten | unzulässig |

**Regeln im Überblick**

- Runtime-Eingaben gibt es ausschließlich beim kontrollierten Overlay; der Bezug erfolgt über die Modi Push oder Pull.
- Ein zeitgesteuertes Overlay ist nach der Aktivierung unveränderlich.
- Ein Event ist endlich, priorisiert und nach der Festlegung unveränderlich.
- Push und Pull erscheinen nirgends als `overlay_mode`-Werte und nirgends als Overlay-Untertypen.

---

## Entscheidungen zu Kapitel 4

Die folgenden Festlegungen sind verbindlich:

1. **Drei fachliche Typen, vier Lebenszyklusformen.** Es gibt genau drei fachliche Typen — State, Overlay, Event. Das Overlay tritt in zwei Lebenszyklusformen auf (kontrolliert, zeitgesteuert); die Dokumentation stellt daher vier Lebenszyklusformen deutlich dar.
2. **Fachliche Einsatzzwecke als Orientierung.** Einsatzzwecke sind Orientierung, keine zusätzliche Schemaeinschränkung. Der Typvertrag (die Regeln) ist verbindlich; Beispiele wie DoA oder Fortschrittsanzeige sind Empfehlungen.
3. **Vorläufig neutrale Beispiele.** Solange der produktive Effektkatalog noch überarbeitet wird, werden vorläufig neutrale Beispiele verwendet.

> Eine frühere Entwurfsfassung sah Push und Pull als Untervarianten des kontrollierten Overlays vor. Diese Einordnung ist überholt: Push und Pull sind Bezugsmodi für Runtime-Eingaben und werden im gesamten Kapitel entsprechend behandelt (siehe Abschnitt 3).
