## Kapitel 10: Validierung und Build

**Ziel:** Den Weg von einer bearbeitbaren Quelle zu einem geprüften Distributionspaket erklären.

### Gliederung

1. Qualitätsgrenze des Builds
2. Quellenvalidierung
3. Import- und Strukturprüfung
4. Schema- und Vertragsprüfung
5. Smoke-Render
6. LEFX-Build
7. Paketverifikation
8. LEFXSET aus vorgebauten LEFX-Paketen
9. Standard-Build
10. Cache und Cleanup
11. typische Fehler

```text
Quelle
→ validieren
→ importieren
→ Vertrag prüfen
→ Probe-Frame rendern
→ LEFX bauen
→ LEFX verifizieren
→ optional in LEFXSET aufnehmen
```

**Schwerpunkte:**

- `build/` enthält ausschließlich reproduzierbare Ergebnisse.
- Autoritative Quellen liegen niemals unter `build/`.
- Ein LEFXSET wird bevorzugt aus bereits geprüften LEFX-Paketen gebaut.
- Standard- und Fremdpakete verwenden dieselben grundlegenden Prüfschritte.
- Smoke-Render ergänzt Tests, ersetzt sie aber nicht.
- Zwischen-Caches werden nach erfolgreichem Build entfernt.
- Fertige Ausgaben und temporäre Zwischenstände werden klar unterschieden.

**Entscheidungen:**

- **10A:** Eine kompakte verbindliche Build-Checkliste zusätzlich zum erklärenden Text? Empfehlung: Ja.
- **10B:** Befehle nur einmal vollständig im Entwicklerbereich dokumentieren und hier den Ablauf erklären? Empfehlung: Ja.
- **10C:** Fehler nach Quelle, Schema, Import, Render und Paketstruktur gruppieren? Empfehlung: Ja.

