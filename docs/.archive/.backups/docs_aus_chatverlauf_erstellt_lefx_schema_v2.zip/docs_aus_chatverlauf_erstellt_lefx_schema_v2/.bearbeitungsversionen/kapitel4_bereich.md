# Faktenquelle Kapitel 4: Typen und Lebenszyklen (Einzel-Durchlauf)
# Extrahiert aus kapitel3_bereich.md (AGENT_017, alter Entwurf "Kapitel 3: Effekttypen") + USER__018-Korrektur

## Kapitel 3: Effekttypen

**Ziel:** Der Leser soll sicher entscheiden können, welcher Typ und welcher Lebenszyklus zu seiner Anzeige passt.

#-> Gliederung

1. Vergleichsmatrix aller Lebenszyklusformen
2. State
3. Kontrolliertes Push-Overlay
4. Kontrolliertes Pull-Overlay
5. Zeitgesteuertes Overlay
6. Event
7. Entscheidungshilfe
8. Ungültige Kombinationen

Die zentrale Tabelle zeigt:

- Zweck
- Lebensdauer
- Aktivierung
- Aktualisierbarkeit
- Beendigung
- Runtime-Eingaben
- Channel
- Queue
- Komposition

**Schwerpunkte:**

- State, Overlay und Event sind unveränderliche Typen, keine Presetvarianten.
- Push und Pull sind Datenbeschaffungsarten kontrollierter Overlays.
- Zeitgesteuerte Overlays sind nach der Aktivierung nicht aktualisierbar.
- Events sind endlich, priorisiert und nicht nachträglich veränderbar.
- Typvertrag und fachliche Verwendung werden getrennt: Die Regeln sind verbindlich, Beispiele wie DoA oder Fortschrittsanzeige sind Empfehlungen.

**Entscheidungen:**

- **3A:** Drei fachliche Typen, aber vier deutlich dargestellte Lebenszyklusformen?  
  Empfehlung: Ja.
- **3B:** Push und Pull als Untervarianten des kontrollierten Overlays erklären?  
  Empfehlung: Ja.
- **3C:** Fachliche Einsatzzwecke als Orientierung, nicht als zusätzliche Schemaeinschränkung behandeln?  
  Empfehlung: Ja.
- **3D:** Vorläufig neutrale Beispiele verwenden, solange der produktive Effektkatalog noch überarbeitet wird?  
  Empfehlung: Ja.


### USER__018 (Korrektur, verbindlich)
Push und Pull sind KEINE Untervarianten des Overlays, sondern Bezugsmodi für Runtime-Eingaben (wie die Engine Frames bezieht).
Daraus folgt: Ein Gliederungspunkt 'Kontrolliertes Overlay (Push/Pull als Bezugsmodi)', kein eigener Punkt je Modus.
