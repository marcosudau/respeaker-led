# Kapitel 9: Bedienung über CLI und API

> **Hinweis:** Dieses Dokument enthält Kapitel 9 der technischen Dokumentation zum LED-Controller (LEFX Schema V2). Kapitel 1, 2, 3, 6, 7 und 8 sind laut Dokumentationsfahrplan inhaltlich freigegeben.

**Ziel:** Ein einheitliches Bedienmodell erklären, ohne CLI und HTTP als zwei verschiedene Systeme erscheinen zu lassen.

Dieses Kapitel beschreibt die Bedienung des LED-Controllers (LEFX Schema V2) über die Kommandozeile (CLI) und über die HTTP-API. Beide Zugangswege beruhen auf demselben Satz an Steuerungskommandos. Wer ein Steuerungskommando beherrscht, kennt damit beide Zugangswege; Unterschiede bestehen nur in der Übertragung und in der Darstellung der Antworten.

## 9.1 Steuerungskommando als gemeinsames Modell

Ein **Steuerungskommando** ist die kleinste vollständige Bedienanweisung an den LED-Controller und das gemeinsame Modell für CLI und HTTP: Die Kommandozeile nimmt Steuerungskommandos als Eingabe entgegen, die HTTP-API führt dieselben Steuerungskommandos aus. Fachlich sind beide Zugangswege gleichwertig — sie unterscheiden sich nicht im Bedienmodell, sondern nur im Transport und im Antwortformat.

Die kanonischen Kommandos:

```text
set state
clear state
set overlay
update overlay
clear overlay
emit event
list
show
```

Für dieses Kapitel gelten folgende Grundsätze:

- Dokumentiert werden nur vollständige kanonische Formen.
- Tolerierte Kurzformen bleiben bewusst undokumentierte Eingabehilfe.
- Listen liefern standardmäßig kompakte IDs; `--details` beziehungsweise `?details=true` liefert vollständige Metadaten.
- `--json` verändert das CLI-Ausgabeformat, nicht den fachlichen Inhalt.
- API-Antworten bleiben immer JSON.
- Ungültige Eingaben verändern keine Runtime.
- Fuzzy-Treffer werden nur vorgeschlagen, niemals automatisch ausgeführt.

### Fachbegriffe

| Begriff | Verwendung in Kapitel 9 |
|---|---|
| Steuerungskommando | Gemeinsames Bedienmodell für CLI und HTTP; jede Bedienanweisung beginnt mit einem Verb |
| laufende Instanz | Ziel der Steuerungskommandos; ungültige Eingaben verändern sie nicht |
| State | Objekt der Kommandos `set state` und `clear state` |
| Overlay | Objekt der Kommandos `set overlay`, `update overlay` und `clear overlay` |
| Event | Objekt des Kommandos `emit event` |

### Kommandoübersicht

| Steuerungskommando | Wirkung |
|---|---|
| `set state` | State idempotent einschalten |
| `clear state` | State löschen |
| `set overlay` | Overlay einschalten |
| `update overlay` | Bestehendes Overlay ändern |
| `clear overlay` | Overlay entfernen |
| `emit event` | Event auslösen |
| `list` | Kompakte IDs auflisten |
| `show` | Detailabfrage |

## 9.2 Verb-zuerst-Grammatik

Alle Steuerungskommandos folgen einer Verb-zuerst-Grammatik: Das Verb steht am Anfang und bestimmt die Art der Bedienung, das Objekt bestimmt den Gegenstand. Das Vokabular der Verben ist fest: `set`, `update`, `clear`, `emit`, `list`, `show`.

- `set`, `update`, `clear` und `emit` benötigen ein Objekt: `state`, `overlay` beziehungsweise `event`.
- `list` und `show` stehen ohne Objekt; sie sind eigenständige Abfragekommandos.

Optionen wie `--toggle`, `--details` und `--json` ergänzen die kanonische Form. Sie steuern die Ausführung beziehungsweise die Darstellung, nicht die Grundstruktur des Kommandos.

```mermaid
flowchart LR
    SK["Steuerungskommando"] --> V["Verb zuerst"]
    V -->|"set"| O1["state"]
    V -->|"clear"| O1
    V -->|"set"| O2["overlay"]
    V -->|"update"| O2
    V -->|"clear"| O2
    V -->|"emit"| O3["event"]
    V -->|"list"| A1["ohne Objekt:<br/>kompakte IDs"]
    V -->|"show"| A2["ohne Objekt:<br/>Detailabfrage"]
    O1 --> OPT["Optionen<br/>--toggle, --details, --json"]
    O2 --> OPT
    O3 --> OPT
    A1 --> OPT
    A2 --> OPT
    OPT --> RT["Wirkung auf die laufende Instanz"]
```

Beispiel:

```
$ set state
```

Das Verb `set` bestimmt die Bedienung (idempotent einschalten), das Objekt `state` bestimmt den Gegenstand.

## 9.3 State-Kommandos

Die State-Kommandos bedienen den State:

| Kommando | Wirkung |
|---|---|
| `set state` | State idempotent einschalten |
| `clear state` | State löschen |

CLI:

```
$ set state
```

Das Kommando schaltet den State idempotent ein (Abschnitt 9.6). Dieselbe Operation ist über die HTTP-API ausführbar; die Zuordnung erfolgt in Abschnitt 9.8.

CLI:

```
$ clear state
```

Das Kommando löscht den zuvor gesetzten State. Auch diese Operation ist über die HTTP-API identisch ausführbar.

## 9.4 Overlay-Kommandos

Die Overlay-Kommandos bedienen das Overlay:

| Kommando | Wirkung |
|---|---|
| `set overlay` | Overlay einschalten |
| `update overlay` | Bestehendes Overlay ändern |
| `clear overlay` | Overlay entfernen |

CLI:

```
$ set overlay
$ update overlay
$ clear overlay
```

Jede dieser Operationen ist über die HTTP-API identisch ausführbar (Abschnitt 9.8).

## 9.5 Event-Kommandos

Das Event-Kommando löst ein Event aus:

| Kommando | Wirkung |
|---|---|
| `emit event` | Event auslösen |

CLI:

```
$ emit event
```

Auch diese Operation ist über die HTTP-API identisch ausführbar (Abschnitt 9.8).

## 9.6 Aktivierungsmodus

Steuerungskommandos wirken auf die laufende Instanz. Der Aktivierungsmodus legt fest, wie ein Kommando den Zielzustand verändert:

- **Idempotente Aktivierung:** Ein bloßes `set` bedeutet idempotent „einschalten“. Die wiederholte Ausführung desselben Kommandos führt zum selben Ergebnis; ein bereits aktiver Zielzustand bleibt unverändert aktiv.
- **Explizites Umschalten:** Ein Umschalten (Toggle) erfolgt ausschließlich explizit mit `--toggle` und niemals durch ein bloßes `set`. Dadurch ist die Bedienung wiederholungs- und API-sicherer: Eine versehentliche Wiederholung eines Kommandos kann kein unerwartetes Umschalten auslösen.
- **Keine Aktivierung bei ungültigen Eingaben:** Ungültige Eingaben verändern keine Runtime; die laufende Instanz bleibt unverändert (Abschnitt 9.9).

| Aktivierungsmodus | Kommando | Verhalten |
|---|---|---|
| Idempotent einschalten | `set state`, `set overlay` | Aktiviert den Zielzustand; Wiederholung ist folgenlos |
| Explizit umschalten | `set state --toggle`, `set overlay --toggle` | Schaltet ausschließlich auf expliziten Wunsch um |
| Löschen | `clear state` | Löscht den State |
| Ändern | `update overlay` | Ändert das bestehende Overlay |
| Entfernen | `clear overlay` | Entfernt das Overlay |
| Kein Eingriff | ungültige Eingaben | Verändern keine Runtime; nur Vorschläge |

## 9.7 Listen und Detailabfragen

Die eigenständigen Kommandos `list` und `show` decken Listen und Detailabfragen ab. Listen liefern standardmäßig kompakte IDs:

```
$ list
id-1
id-2
```

Vollständige Metadaten liefert `--details` beziehungsweise — über die HTTP-API — `?details=true`:

```
$ list --details
```

`--json` verändert dabei nur das Ausgabeformat der CLI, nicht den fachlichen Inhalt: Die kompakten IDs bleiben dieselben, lediglich die Darstellung wechselt nach JSON:

```
$ list --json
["id-1", "id-2"]
```

API-Antworten bleiben immer JSON; die Option `--json` hat dort keine Entsprechung (Abschnitt 9.8). Das Kommando `show` dient der Detailabfrage.

## 9.8 HTTP-Entsprechungen

Jedem Steuerungskommando der CLI entspricht eine identische HTTP-Operation. CLI und HTTP sind zwei Darstellungen desselben Bedienmodells: Die Kommandozeile nimmt die kanonische Form als Eingabe entgegen, die HTTP-API führt dieselbe Operation aus. Kommandovokabular und fachlicher Inhalt sind identisch.

| CLI | HTTP-API (identische Operation) |
|---|---|
| `set state` | `set state` |
| `clear state` | `clear state` |
| `set overlay` | `set overlay` |
| `update overlay` | `update overlay` |
| `clear overlay` | `clear overlay` |
| `emit event` | `emit event` |
| `list` | `list` |
| `show` | `show` |

Die benannten Entsprechungen für Optionen und Darstellung:

| CLI-Option | HTTP-Parameter | Bedeutung |
|---|---|---|
| `--details` | `?details=true` | Liefert vollständige Metadaten |
| `--json` | — | Nur CLI: verändert das Ausgabeformat, nicht den fachlichen Inhalt; API-Antworten sind immer JSON |

```mermaid
flowchart LR
    subgraph CLI["CLI"]
        C1["Eingabe eines Steuerungskommandos<br/>z. B. set state"]
        C2["Optionen --details, --json<br/>(Darstellung und Metadaten)"]
    end
    subgraph API["HTTP-API"]
        H1["Identische HTTP-Operation<br/>z. B. set state"]
        H2["Parameter ?details=true<br/>Antworten immer JSON"]
    end
    C1 --> M["Steuerungskommando<br/>(gemeinsames Modell)"]
    H1 --> M
    M --> R["laufende Instanz"]
    R --> C3["CLI-Ausgabe<br/>--json steuert das Format"]
    R --> H3["API-Antwort<br/>immer JSON"]
```

## 9.9 Validierungsfehler und Vorschläge

Ungültige Eingaben verändern keine Runtime: Eine fehlerhafte Eingabe wird abgewiesen, ohne dass die laufende Instanz beeinflusst wird. Die CLI beziehungsweise die API meldet den Fehler und unterbreitet Vorschläge — mehr nicht.

Fuzzy-Treffer werden nur vorgeschlagen, niemals automatisch ausgeführt. Eine Eingabe, die keinem kanonischen Kommando entspricht, aber nahe daran liegt, führt zu einem Vorschlag der kanonischen Form; ausgeführt wird erst, wenn die kanonische Form eingegeben wird.

Undokumentierte eindeutige Kurzformen werden weiterhin akzeptiert: Sie sind eine bewusste Eingabehilfe, bleiben aber undokumentiert. Nach der Annahme meldet die CLI die kanonische Form, damit die Bedienung nachvollziehbar bleibt.

| Eingabe | Verhalten |
|---|---|
| Vollständige kanonische Form | Wird ausgeführt |
| Eindeutige Kurzform (undokumentiert) | Wird akzeptiert; die kanonische Form wird gemeldet |
| Fuzzy-Treffer | Wird nur vorgeschlagen, niemals automatisch ausgeführt |
| Ungültige Eingabe | Wird abgewiesen; verändert keine Runtime |

## Entscheidungen zu Kapitel 9

Die folgenden Festlegungen gelten für Kapitel 9:

1. **Vokabular:** Das aktuelle Vokabular `set`, `update`, `clear`, `emit`, `list`, `show` wird beibehalten.
2. **Idempotente Aktivierung:** Ein bloßes `set` bedeutet idempotent „einschalten“. Toggle erfolgt nur explizit mit `--toggle`; das ist wiederholungs- und API-sicherer.
3. **Kurzformen:** Undokumentierte eindeutige Kurzformen werden weiterhin akzeptiert; nach der Annahme meldet die CLI die kanonische Form.
4. **Beispieldarstellung:** Beispiele werden zuerst als CLI gezeigt und verweisen jeweils auf die identische HTTP-Operation.
