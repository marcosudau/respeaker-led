# Kapitel 3: Layer und Komposition

> **Einordnung im Dokumentationsfahrplan:** Kapitel 1 und 2 sind laut Dokumentationsfahrplan inhaltlich freigegeben. Dieses Dokument enthält Kapitel 3 der technischen Dokumentation zum LED-Controller (LEFX Schema V2).

**Ziel des Kapitels:** Verständlich zeigen, wie laufende Instanzen angeordnet, ersetzt, aktualisiert und beendet werden. Das Kapitel steht bewusst vor dem Kapitel zu den Typen (Kapitel 4), weil die übereinanderliegenden Layer die Grundlage für das Typenverständnis bilden (Nutzerentscheidung USER__018).

**Grundsatz:** State, kontrolliertes Overlay, zeitgesteuertes Overlay und Event sind unveränderliche Typen, keine Presetvarianten. Für jede Lebenszyklusform gilt die Trennung zwischen drei Aspekten: der Lebensdauer einer Instanz, der zeitlichen Animation ihres Frames und der Aktualisierung ihrer Runtime-Eingaben.

## Inhalt des Kapitels

1. Layer als interne Engine-Struktur
2. Prioritätsstapel
3. Background State und Primary State
4. Setzen, Ersetzen und Löschen eines States
5. Lifecycle eines kontrollierten Overlays
6. Lifecycle eines zeitgesteuerten Overlays
7. Event-Queue
8. Transparenz und Komposition
9. Rückkehr zum darunterliegenden Bild
10. Verantwortung der Engine

## Übersicht der Lebenszyklen

Die folgende Tabelle ordnet die vier Lebenszyklusformen den Ebenen des Layer-Stapels zu und fasst Lebensdauer, Aktualisierbarkeit und Beendigung zusammen. Die Details folgen in den Abschnitten 3 bis 7.

| Lebenszyklusform | Ebene (lesbar) | Enum-Name | Lebensdauer | Aktualisierbarkeit | Beendigung |
|---|---|---|---|---|---|
| Background State | Background State | `BACKGROUND_STATE_LAYER` | durch Steuerungskommandos | über Steuerungskommandos | Löschen oder Ersetzen |
| Primary State | Primary State | `STATE_LAYER` | durch Steuerungskommandos | über Steuerungskommandos | Löschen oder Ersetzen |
| Zeitgesteuertes Overlay | Timed Overlay | `TEMP_OVERLAY_LAYER` | endlich | nach der Aktivierung nicht aktualisierbar | durch die Engine |
| Kontrolliertes Overlay | Controlled Overlay | `ONGOING_OVERLAY_LAYER` | läuft, solange gewünscht | über Steuerungskommandos (Runtime-Eingaben) | durch Steuerungskommando |
| Event | Event | `EVENT_LAYER` | endlich | nicht nachträglich veränderbar | durch die Engine |

---

## 1. Layer als interne Engine-Struktur

Die Engine führt jede laufende Instanz auf einer festen Ebene, einem Layer. Die Layer sind eine **interne Struktur der Engine**: Sie sind kein öffentlicher Parameter des Systems und werden von Aufrufern nicht direkt angesprochen. Es gibt keine öffentliche, freie Layerauswahl.

Die Platzierung einer Instanz ist deshalb nicht frei wählbar. **Der Typ der Instanz und – bei Overlays – der Overlay-Modus bestimmen die interne Platzierung.** Ein Aufrufer sendet ein Steuerungskommando; die Engine entscheidet anhand von Typ und Overlay-Modus, auf welcher Ebene die Instanz abgelegt wird. Ein State landet auf einem der beiden State-Plätze, ein Overlay je nach Overlay-Modus auf der Ebene der kontrollierten oder der zeitgesteuerten Overlays, ein Event auf der Event-Ebene.

Die Layer tragen **lesbare Namen, die zuerst verwendet werden**; die technischen Enum-Namen stehen ergänzend dazu. Die folgende Tabelle zeigt die Zuordnung vollständig, von oben nach unten.

| Lesbarer Name | Technischer Enum-Name | Position im Stapel |
|---|---|---|
| Event | `EVENT_LAYER` | oberste Ebene |
| Controlled Overlay | `ONGOING_OVERLAY_LAYER` | zweite Ebene |
| Timed Overlay | `TEMP_OVERLAY_LAYER` | dritte Ebene |
| Primary State | `STATE_LAYER` | vierte Ebene |
| Background State | `BACKGROUND_STATE_LAYER` | unterste Ebene |

## 2. Prioritätsstapel

Die fünf Layer bilden einen **Prioritätsstapel**. Die Reihenfolge von oben nach unten ist verbindlich festgelegt:

> Event → Controlled Overlay → Timed Overlay → Primary State → Background State

Jede Ebene überlagert die Ebenen unter ihr: Was auf einer höheren Ebene liegt, hat Vorrang vor dem, was darunter liegt. Die oberste Ebene (Event) besitzt damit den höchsten Vorrang, die unterste Ebene (Background State) den geringsten. Die Priorität ist eine Folge der Stapelreihenfolge; ein separater Prioritätsparameter existiert nicht.

_Abbildung 1: Layer-Stapel von oben nach unten_

```mermaid
graph TB
    subgraph STAPEL["Layer-Stapel (von oben nach unten)"]
        direction TB
        E["Event<br/>EVENT_LAYER"]
        C["Controlled Overlay<br/>ONGOING_OVERLAY_LAYER"]
        T["Timed Overlay<br/>TEMP_OVERLAY_LAYER"]
        P["Primary State<br/>STATE_LAYER"]
        B["Background State<br/>BACKGROUND_STATE_LAYER"]
        E --> C --> T --> P --> B
    end
```

Die Reihenfolge zwischen den beiden Overlay-Ebenen ist eine bewusste Architekturentscheidung: Ein **kontrolliertes Overlay liegt über einem zeitgesteuerten Overlay**. Eine laufende Funktionsanzeige bleibt dadurch sichtbar, auch wenn darunter zeitgesteuerte Overlays erscheinen und wieder enden. Wirklich priorisierte Unterbrechungen gehören nicht in die Overlay-Ebenen, sondern auf die Event-Ebene; nur dort überlagern sie alle anderen Ebenen.

## 3. Background State und Primary State

**Background State und Primary State sind zwei unterschiedliche State-Plätze.** Sie sind nicht zwei Varianten desselben Platzes, sondern zwei getrennte Ebenen des Stapels mit eigenen Namen und eigenen Enum-Werten.

Der **Background State** (`BACKGROUND_STATE_LAYER`) bildet die unterste Ebene des Stapels und damit die Basis des sichtbaren Bildes. Der **Primary State** (`STATE_LAYER`) liegt darüber; er ist der aktive State-Platz, der den Background State überlagert. Beide Plätze werden über Steuerungskommandos gesetzt, ersetzt und gelöscht (siehe Abschnitt 4).

| Aspekt | Background State | Primary State |
|---|---|---|
| Ebene | unterste Ebene des Stapels | vierte Ebene, über dem Background State |
| Rolle | Basis des Bildes | aktiver State-Platz über der Basis |
| Enum-Name | `BACKGROUND_STATE_LAYER` | `STATE_LAYER` |
| Steuerung | Setzen, Ersetzen, Löschen | Setzen, Ersetzen, Löschen |

## 4. Setzen, Ersetzen und Löschen eines States

States werden ausschließlich über **Steuerungskommandos** verwaltet. Es gibt drei Grundoperationen:

- **Setzen:** Ein Steuerungskommando legt eine neue laufende Instanz auf einem der beiden State-Plätze an. Der Platz wird mit einem State belegt.
- **Ersetzen:** Ein Steuerungskommando tauscht die laufende Instanz eines State-Platzes gegen eine neue aus. Der Platz bleibt dabei durchgängig belegt; es entsteht keine Lücke, in der der darunterliegende Wert sichtbar würde.
- **Löschen:** Ein Steuerungskommando entfernt die laufende Instanz von einem State-Platz. Der Platz ist danach leer; das darunterliegende Bild tritt wieder hervor (siehe Abschnitt 9).

Die drei Operationen gelten für beide State-Plätze gleichermaßen. Wird der Primary State gelöscht, wird der Background State sichtbar; wird der Background State gelöscht, bleibt darunter keine weitere Ebene, da er die Basis des Stapels ist.

## 5. Lifecycle eines kontrollierten Overlays

Ein kontrolliertes Overlay ist eine laufende Instanz auf der Ebene `ONGOING_OVERLAY_LAYER` (Controlled Overlay), oberhalb der zeitgesteuerten Overlays. Es läuft, **solange es gewünscht ist**: Eine laufende Funktionsanzeige bleibt sichtbar, auch wenn darunterliegende Ebenen wechseln. Die Beendigung erfolgt über ein Steuerungskommando des Aufrufers.

Für ein kontrolliertes Overlay sind drei Aspekte getrennt zu betrachten:

- **Lebensdauer der Instanz:** Sie beginnt mit der Aktivierung und endet mit der Beendigung durch den Aufrufer.
- **Zeitliche Animation des Frames:** Der Frame eines kontrollierten Overlays kann sich über die Zeit animieren, unabhängig von der Lebensdauer der Instanz.
- **Aktualisierung der Runtime-Eingaben:** Die Runtime-Eingaben eines kontrollierten Overlays können über Steuerungskommandos aktualisiert werden. Darin unterscheidet es sich vom zeitgesteuerten Overlay.

_Abbildung 2: Zeitachse eines kontrollierten Overlays_

```mermaid
graph LR
    subgraph INSTANZ["Lebensdauer der Instanz"]
        direction LR
        i1["Aktivierung<br/>(Steuerungskommando)"] --> i2["Instanz läuft"] --> i3["Beendigung<br/>(Steuerungskommando)"]
    end
    subgraph FRAME["zeitliche Animation des Frames"]
        direction LR
        f1["Frames werden erzeugt"] --> f2["Animation über die Zeit"]
    end
    subgraph INPUT["Runtime-Eingaben"]
        direction LR
        r1["Initiale Eingaben"] --> r2["Aktualisierung<br/>durch Steuerungskommandos"]
    end
```

Wie die Engine die Frames eines kontrollierten Overlays bezieht (die Bezugsmodi Push und Pull), wird in Kapitel 7 (Runtime-Eingaben) behandelt.

## 6. Lifecycle eines zeitgesteuerten Overlays

Ein zeitgesteuertes Overlay ist eine laufende Instanz auf der Ebene `TEMP_OVERLAY_LAYER` (Timed Overlay), unterhalb der kontrollierten Overlays und oberhalb des Primary State. Es ist eine **endliche Instanz**: Nach Ablauf seiner Zeit **beendet die Engine die Instanz selbst**; der Aufrufer muss dafür kein weiteres Steuerungskommando senden.

Ein zeitgesteuertes Overlay ist **nach der Aktivierung nicht aktualisierbar**. Die Trennung der drei Aspekte fällt damit anders aus als beim kontrollierten Overlay:

- **Lebensdauer der Instanz:** Sie beginnt mit der Aktivierung und endet automatisch durch die Engine.
- **Zeitliche Animation des Frames:** Der Frame animiert sich über die Zeit; die Animation ist Teil der zeitgesteuerten Darstellung.
- **Aktualisierung der Runtime-Eingaben:** Nach der Aktivierung sind die Runtime-Eingaben fest; eine spätere Aktualisierung ist nicht möglich.

_Abbildung 3: Zeitachse eines zeitgesteuerten Overlays_

```mermaid
graph LR
    subgraph INSTANZ2["Lebensdauer der Instanz"]
        direction LR
        j1["Aktivierung"] --> j2["Instanz läuft (endlich)"] --> j3["Beendigung durch die Engine"]
    end
    subgraph FRAME2["zeitliche Animation des Frames"]
        direction LR
        g1["Frames werden erzeugt"] --> g2["Animation über die Zeit"]
    end
    subgraph INPUT2["Runtime-Eingaben"]
        direction LR
        h1["Initiale Eingaben"] --> h2["keine Aktualisierung nach der Aktivierung"]
    end
```

## 7. Event-Queue

Events sind **endlich, priorisiert und nicht nachträglich veränderbar**. Sie werden auf der obersten Ebene (`EVENT_LAYER`) angezeigt und überlagern damit alle anderen Ebenen; nur hier sind wirklich priorisierte Unterbrechungen möglich.

Die **Engine verwaltet die Event-Queue**. Events werden der Queue übergeben, dort geordnet und priorisiert verarbeitet. Da ein Event endlich und nicht nachträglich veränderbar ist, durchläuft es seinen Lebenszyklus unverändert: Es erscheint auf der Event-Ebene, läuft und wird von der Engine beendet. Danach wird das darunterliegende Bild wieder sichtbar.

_Abbildung 4: Event-Queue_

```mermaid
graph LR
    E1["Event 1"] --> Q["Event-Queue<br/>(verwaltet von der Engine)"]
    E2["Event 2"] --> Q
    E3["Event 3"] --> Q
    Q --> V["priorisierte Verarbeitung"]
    V --> A["Anzeige auf der Event-Ebene<br/>(EVENT_LAYER)"]
```

## 8. Transparenz und Komposition

Frames einzelner Ebenen können **transparent** sein. Für einen transparenten Frame gilt: **`None` bedeutet, den darunterliegenden Wert zu erhalten.** Eine Ebene mit `None` trägt also keinen eigenen Wert zur Komposition bei; der Wert der darunterliegenden Ebene bleibt unverändert erhalten und wird sichtbar.

Die Engine setzt die Werte der Ebenen zur Komposition zusammen. Dabei gilt von oben nach unten: Der **oberste vorhandene Wert** bestimmt das sichtbare Bild; jede Ebene mit `None` reicht den Wert der darunterliegenden Ebene durch. Erst wenn alle oberen Ebenen transparent sind, ist der Background State sichtbar.

_Abbildung 5: Komposition mit transparenten Frames (`None` = darunterliegenden Wert erhalten)_

```mermaid
graph TB
    subgraph SCHICHTEN["Layer mit Frame-Werten"]
        direction TB
        L1["Event-Ebene: None (transparent)"]
        L2["Controlled Overlay: None (transparent)"]
        L3["Timed Overlay: Wert sichtbar"]
        L4["Primary State: Wert (darunterliegend)"]
        L5["Background State: Wert (Basis)"]
    end
    subgraph ERGEBNIS["Komposition"]
        R["Sichtbares Bild: Wert des Timed Overlays<br/>None-Passagen geben den darunterliegenden Wert weiter"]
    end
    L1 --> R
    L2 --> R
    L3 --> R
    L4 --> R
    L5 --> R
```

Transparenz und Komposition gelten für alle Ebenen gleichermaßen. Die `None`-Regel ist dabei die Grundlage für die Rückkehr zum darunterliegenden Bild (Abschnitt 9): Wo eine Ebene keinen Wert beiträgt, erscheint automatisch der Wert der Ebene darunter.

## 9. Rückkehr zum darunterliegenden Bild

Sobald eine Ebene keine laufende Instanz mehr trägt oder ihr Frame transparent ist, wird das **darunterliegende Bild wieder sichtbar**. Der Layer-Stapel garantiert damit, dass nach dem Ende einer Instanz nie ein leerer Bildschirm entsteht, sondern der Wert der nächsttieferen Ebene hervortritt:

- Endet ein zeitgesteuertes Overlay, wird der darunterliegende Primary State sichtbar.
- Endet ein Event, wird die darunterliegende Ebene (in der Regel ein Overlay oder ein State) sichtbar.
- Wird der Primary State gelöscht, tritt der Background State hervor.

Die Anordnung der Ebenen sorgt dafür, dass dieser Wechsel geordnet abläuft: Eine laufende Funktionsanzeige (kontrolliertes Overlay) bleibt währenddessen sichtbar, weil sie über den wechselnden Ebenen liegt. Die Rückkehr zum darunterliegenden Bild ist damit kein Sonderfall, sondern die direkte Folge von Stapelreihenfolge und Transparenzregel.

## 10. Verantwortung der Engine

Die Engine trägt die alleinige Verantwortung für Anordnung, Komposition und Beendigung der laufenden Instanzen. Im Einzelnen:

- **Platzierung:** Die Engine bestimmt anhand von Typ und Overlay-Modus, auf welcher Ebene eine Instanz abgelegt wird. Aufrufer wählen keine Layer (Abschnitt 1).
- **Beendigung endlicher Instanzen:** Die Engine beendet endliche Instanzen selbst, also zeitgesteuerte Overlays und Events (Abschnitte 6 und 7).
- **Verwaltung der Event-Queue:** Die Engine nimmt Events entgegen, ordnet und verarbeitet sie priorisiert (Abschnitt 7).
- **Komposition:** Die Engine setzt die Werte der Ebenen zusammen; transparente Frames mit `None` erhalten den darunterliegenden Wert (Abschnitt 8).
- **Rückkehr zum darunterliegenden Bild:** Nach dem Ende einer Instanz oder bei Transparenz stellt die Engine den Wert der darunterliegenden Ebene wieder her (Abschnitt 9).

Ein **Paket besitzt keinen parallelen Lifecycle.** Die Lebenszyklen gelten ausschließlich den laufenden Instanzen auf den Layern; ein Paket als Sammlung von Definitionen wird nicht parallel zu diesen Instanzen aktiviert, aktualisiert oder beendet.

## Entscheidungen zu Kapitel 3

Die folgenden Festlegungen sind verbindlich; sie sind keine offenen Fragen:

1. **Reihenfolge beibehalten:** Das kontrollierte Overlay liegt über dem zeitgesteuerten Overlay. Wirklich priorisierte Unterbrechungen gehören auf die Event-Ebene.
2. **Keine öffentliche freie Layerauswahl:** Aufrufer wählen keine beliebigen Layer; Typ und Overlay-Modus bestimmen die interne Platzierung.
3. **Layer als interne Engine-Struktur:** Die Layer werden als interne Struktur der Engine erklärt, mit Schaubildern der übereinanderliegenden, auch transparenten Layer.
4. **Lesbare Namen zuerst:** Die lesbaren Namen (Event, Controlled Overlay, Timed Overlay, Primary State, Background State) werden zuerst verwendet; die technischen Enum-Namen stehen ergänzend dazu.
5. **Zwei State-Plätze:** Background State und Primary State sind zwei unterschiedliche State-Plätze, keine Varianten desselben Platzes.
