### USER__015 -> Beginn Allgemeine Dokumentation (Themenzuschnitt + Gliederung) - Finalisierung

Ja, das gefällt mir gut, lass uns das so festhalten.... Dann können wir auch grundsätzlich im Dokumentationsordner mal richtig Ordnung schaffen.Das sind so viele Sachen, die man eigentlich nicht als Teil der Doku werten kann, höchstens als Archiv.Wollen wir da jetzt einmal durchgehen und du schreibst mir immer, wo du die Schwerpunkte legen würdest oder welche Aspekte  du nach vorne stellen würdest und Ich sage meine Meinung dazu Und ob ich etwas ergän oder anders formulieren würde.


### AGENT_015

Ja, genau so gehen wir vor. Den verbindlichen Fahrplan habe ich bereits gespeichert: [effect_system_documentation_roadmap.md](C:/Users/marco/source/experiments/led_controller_respeaker_effects_schema_v2_2026-07-29/docs/planning/effect_system_documentation_roadmap.md).

Es wurde noch nichts verschoben oder entfernt.

**Erste Ordnung**
Nach der Bestandsaufnahme würde ich die vorhandenen Dateien grundsätzlich so behandeln:

- **Aktuelle Hauptdokumentation:** `index.md`, `getting_started.md`, `api_guide.md`, `troubleshooting.md`
- **In die neue Effektsystem-Doku einarbeiten:** `effects.md`, `presets.md`, `current_approach.md`, `planning/lefx_schema_v2.md`
- **Aktuelle Entwicklerdokumentation:** `dev/*`, `effect-development/*`
- **Aktive Planung:** der neue Dokumentationsfahrplan und tatsächlich noch offene Konzepte
- **Archivkandidaten:** alte Umbaupläne, Konzeptreihen, Sanierungsberichte und `history_and_legacy`
- **Nach Abschluss archivieren:** `prompt_einstiegshilfe.md`
- **V3-Ideen verschieben:** Die Lifecycle-Ideensammlung sollte später aus der aktuellen Entwicklerdokumentation nach `planning/v3/` wandern.
- **Offensichtliche Zwischenartefakte:** leere Konzeptdateien und zahlreiche aufeinanderfolgende „finale“ Konzeptstände gehören nicht in die normale Navigation.

Die alten Dateien bleiben erhalten, werden aber später unter `docs/archive/` klar als historisch markiert.

## Kapitel 1: Überblick und Grundidee

**Ziel:** Nach diesem Kapitel soll jemand das System grundsätzlich verstanden haben, ohne bereits Schemafelder, Commands oder Layerdetails kennen zu müssen.

#-> Vorgeschlagene Gliederung

#--> 1. Was ist das Effektsystem?

Kurze Beschreibung:

- Steuerung eines LED-Rings
- unterschiedliche visuelle Aufgaben
- Trennung zwischen Controller und visueller Fachlogik
- Erweiterbarkeit durch eigenständige Pakete

Noch keine technische Detailerklärung.

#--> 2. Warum wurde die Logik getrennt?

Hier würde ich die Motivation knapp erklären:

- Ursprünglich waren Effekte im Controller hartkodiert.
- Dadurch kannte der Controller konkrete Effekte und ihre Bedeutung.
- Änderungen an Effekten erforderten Änderungen am Hauptprogramm.
- V2 verschiebt Darstellung, Parametersemantik und Presets in autonome Pakete.
- Die Engine kennt nur noch allgemeine Typ- und Lifecycle-Verträge.

**Schwerpunkt:** Nicht lange die Entwicklungsgeschichte erzählen. Ein kurzer Vorher-Nachher-Vergleich reicht.

| Früher | V2 |
|---|---|
| Controller kennt konkrete Effekte | Controller kennt nur Typverträge |
| Effektlogik im Hauptcode | Effektlogik im LEFX-Paket |
| Gemeinsame Sonderlogik | Autarke Paketlogik |
| Bedeutung durch Layer oder Preset veränderbar | Typ und Lebenszyklus unveränderlich |

#--> 3. Das mentale Grundmodell

Hier sollten wir die wichtigsten Objekte erstmals einführen:

```text
LEFX-Quelle → LEFX-Paket → geladene Definition → laufende Instanz
```

Dazu:

- Eine Quelle ist das bearbeitbare Verzeichnis.
- Eine LEFX-Datei ist das gebaute Artefakt.
- Eine Definition beschreibt genau einen State, ein Overlay oder ein Event.
- Eine Instanz ist die aktuell laufende Ausführung.
- Ein Preset ist nur eine vorbereitete Konfiguration.

Die verbindlichen Detaildefinitionen kommen erst in Kapitel 2.

#--> 4. Drei Typen, vier Lebenszyklusformen

Ich würde es genau so formulieren:

- Drei fachliche Typen: State, Overlay, Event
- Overlays besitzen zwei klar getrennte Modi:
  - kontrolliert
  - zeitgesteuert

Damit vermeiden wir sowohl „vier Effekttypen“ als auch das Verstecken der fundamentalen Overlay-Unterschiede.

Eine sehr kurze Entscheidungshilfe reicht:

```text
Dauerhafter Grundzustand?       → State
Laufend aktualisierte Anzeige?  → kontrolliertes Overlay
Zeitlich begrenzte Einblendung? → zeitgesteuertes Overlay
Einmaliges priorisiertes Signal? → Event
```

#--> 5. Verantwortungsgrenzen

Das ist einer der wichtigsten Teile des ersten Kapitels:

| Bestandteil | Verantwortung |
|---|---|
| LEFX-Paket | Darstellung, Parameter, Presets und Effektlogik |
| Engine | Lebenszyklus, Layer, Komposition und Hardwareausgabe |
| Integration | Hardwarewerte und anwendungsspezifische Daten |
| CLI/API | validierte Steuerung des Systems |

**Kernaussage:** Der Controller soll wissen, wie ein Overlay grundsätzlich funktioniert, aber nicht, was `doa_direction` fachlich bedeutet.

#--> 6. Ein vollständiger Datenfluss

DoA eignet sich hier als erstes durchgängiges Beispiel:

```mermaid
flowchart LR
    A["ReSpeaker"] --> B["DoA-Integration"]
    B --> C["Overlay-Channel"]
    C --> D["Engine"]
    D --> E["DoA-LEFX"]
    E --> F["LED-Frame"]
```

Dazu ein zweites, einfacheres Beispiel:

```text
CLI: emit event short_pulse
→ Validierung
→ Event-Queue
→ LEFX rendert Frames
→ Engine beendet das Event nach seiner Dauer
```

#--> 7. Artefakte in einem Satz

Am Kapitelende:

- `.lefx`: genau eine vollständige visuelle Definition
- `.lefxset`: Sammlung mehrerer LEFX-Artefakte
- Preset: Konfiguration einer Definition, kein eigener Effekttyp

#--> 8. Nächste Einstiege

Kurze Navigation:

- Systembegriffe verstehen
- Typen und Lebenszyklen vergleichen
- CLI/API verwenden
- eigenen Effekt entwickeln
- Paket bauen

## Meine Schwerpunktsetzung

Für Kapitel 1 würde ich besonders nach vorne stellen:

1. **Autonomie der Effektpakete**
2. **Controller kennt Verträge, keine konkrete Effektbedeutung**
3. **Drei Typen, aber zwei Overlay-Modi**
4. **Definition, Paket und laufende Instanz sind unterschiedliche Dinge**
5. **DoA als Beispiel für die saubere Verantwortungsgrenze**

Schemafelder, vollständige Layerregeln, Heartbeatdetails, ID-Auflösung und Buildbefehle würde ich bewusst noch nicht ausführlich behandeln.

## Entscheidungen zu Kapitel 1

1. Soll das Kapitel direkt mit dem heutigen Modell beginnen und die frühere Hartkodierung nur als kurze Motivation erwähnen?  
   **Meine Empfehlung:** Ja.

2. Sollen wir „Effektsystem“ weiterhin als allgemeinen Oberbegriff verwenden, innerhalb der Erklärung aber konsequent State, Overlay, Event, Definition, Paket und Instanz sagen?  
   **Meine Empfehlung:** Ja.

3. Soll der ReSpeaker deutlich als konkreter Hauptanwendungsfall sichtbar bleiben, obwohl LEFX V2 technisch nicht an diese Hardware gebunden ist?  
   **Meine Empfehlung:** Ja, konkreter Anwendungsfall mit allgemein gehaltener Architektur.

4. Sollen wir bereits in Kapitel 1 klar und ausdrücklich sagen, dass LEFX-Pakete keinen eigenen Lifecycle-Thread und keine Controllerzugriffe besitzen?  
   **Meine Empfehlung:** Controllerzugriffe klar ausschließen; Threads und technische Einzelheiten erst in Kapitel 11 behandeln.


### USER__016 -> Dokumentation - Kapitel 2: Begriffe und Systemobjekte

Ja, da sprichst du mir auf jeden Fall aus der Seele und deswegen stimme ich deinen Vorschlägen zu Kapitel 1 allen 4 zu.


### AGENT_016


Kapitel 1 ist im [Dokumentationsfahrplan](C:/Users/marco/source/experiments/led_controller_respeaker_effects_schema_v2_2026-07-29/docs/planning/effect_system_documentation_roadmap.md) als inhaltlich freigegeben festgehalten.

