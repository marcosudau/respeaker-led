## Kapitel 11: Architekturgrenzen

**Ziel:** Verbindlich festlegen, welche Logik in Paket, Engine, Integration und Schnittstelle gehört.

### Gliederung

1. Verantwortungsmatrix
2. Autarkie eines LEFX-Pakets
3. Aufgaben der Engine
4. Aufgaben von Integrationen
5. Aufgaben von CLI und API
6. erlaubte Abhängigkeiten
7. lokale Hilfsmodule und Assets
8. Threads, I/O und Laufzeitgrenzen
9. verbotene Kopplungen
10. gültige und ungültige Beispiele

**Paket besitzt:**

- visuelle Bedeutung
- Renderlogik
- Parametersemantik
- Runtime-Input-Schema
- optionale Presets
- lokale Hilfsmodule und Assets

**Engine besitzt:**

- Typverträge
- Lebenszyklen
- Layer und Komposition
- Input-Health
- Queue
- Hardwareausgabe

**Integration besitzt:**

- ReSpeaker- und andere Hardwarezugriffe
- externe Datenquellen
- anwendungsspezifische Zuordnung
- Channel-Aktualisierungen

**Schwerpunkte:**

- Kein Controller-Code entscheidet anhand einer konkreten Definition-ID.
- Keine generische `common.py` zwischen Paketen.
- Paketlokale Hilfsmodule sind erlaubt.
- Keine Imports anderer LEFX-Pakete.
- Kein blockierendes I/O in `render()`.
- Keine unverwalteten Hintergrundthreads.
- `sample_inputs()` ist der kontrollierte Pull-Einstieg, kein zweiter Controller.
- Allgemeine Validierung bleibt generisch; konkrete Effektbedeutung bleibt im Paket.

**Entscheidungen:**

- **11A:** Unverwaltete Paket-Threads und blockierendes `render()` verbindlich ausschließen? Empfehlung: Ja.
- **11B:** Paketlokale Hilfsmodule erlauben, gemeinsam genutzte Effektlogik aber ausschließen? Empfehlung: Ja.
- **11C:** Hardwarezugriffe grundsätzlich über Integrationen führen; Pull nur für begrenzte paketlokale Datenquellen verwenden? Empfehlung: Ja.
- **11D:** Zu jeder Architekturregel mindestens ein korrektes und ein falsches Gegenbeispiel zeigen? Empfehlung: Ja.


