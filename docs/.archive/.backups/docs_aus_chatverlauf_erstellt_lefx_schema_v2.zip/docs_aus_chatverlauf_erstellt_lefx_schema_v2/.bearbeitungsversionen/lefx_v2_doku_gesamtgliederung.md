# LEFX Schema V2 – Dokumentation: Gesamtgliederung

**Inhaltsübersicht** über die freigegebene Dokumentationsstruktur des Effektsystems.
Diese Übersicht fasst alle zwölf Kapitel mit sämtlichen Gliederungspunkten und den jeweils getroffenen Entscheidungen zusammen – als Inhaltsübersicht, nicht als Dialog.

---

## Überblick: Gesamtstruktur der Dokumentation

```text
docs/
├── index.md
├── getting_started.md
├── api_guide.md
├── cli_guide.md
├── troubleshooting.md
├── effects.md
│
├── effect-system/          → die 12 Kapitel (01–12)
├── effect-development/     → Templates, Tutorials, Snippets
├── examples/               → effects/
├── dev/                    → index, architecture, build, public_entry_points
├── planning/               → nur tatsächlich offene Planungen (z. B. v3/)
└── archive/                → historische Dokumente, strikt getrennt
```

**Grundsätze:**

- Aktuelle Dokumentation, aktive Planung und historisches Archiv sind strikt getrennt.
- Kapitel 3 (Layer und Komposition) steht bewusst vor Kapitel 4 (Typen und Lebenszyklen).
- Push und Pull sind Bezugsmodi für Runtime-Eingaben, keine Overlay-Untertypen.
- Freie Parametrisierung steht vor optionalen Presets.
- Alle alten Dokumentationsdateien werden vollständig archiviert (auch leere, doppelte oder abgelöste Zwischenstände).

---

## Kapitel 1: Überblick und Grundidee

**Ziel:** Das System grundsätzlich verstehen, ohne bereits Schemafelder, Commands oder Layerdetails zu kennen.

### Gliederung

1. Was ist das Effektsystem?
2. Warum wurde die Logik getrennt?
3. Das mentale Grundmodell
4. Drei Typen, vier Lebenszyklusformen
5. Verantwortungsgrenzen
6. Ein vollständiger Datenfluss
7. Artefakte in einem Satz
8. Nächste Einstiege

### Schwerpunkte

- Autonomie der Effektpakete
- Controller kennt Verträge, keine konkrete Effektbedeutung
- Drei Typen, aber zwei Overlay-Modi
- Definition, Paket und laufende Instanz sind unterschiedliche Dinge
- DoA als Beispiel für die saubere Verantwortungsgrenze

### Entscheidungen

1. Kapitel beginnt direkt mit dem heutigen Modell; frühere Hartkodierung nur als kurze Motivation.
2. „Effektsystem“ bleibt allgemeiner Oberbegriff; in der Erklärung konsequent State, Overlay, Event, Definition, Paket und Instanz verwenden.
3. ReSpeaker bleibt als konkreter Hauptanwendungsfall sichtbar, die Architektur ist aber nicht an diese Hardware gebunden.
4. LEFX-Pakete besitzen keinen eigenen Lifecycle-Thread und keine Controllerzugriffe; technische Einzelheiten erst in Kapitel 11.

---

## Kapitel 2: Begriffe und Systemobjekte

**Ziel:** Eindeutig unterscheiden können, ob von einer bearbeitbaren Quelle, einem gebauten Paket, einer Definition, einer Konfiguration oder einer laufenden Instanz die Rede ist.

### Gliederung

1. Warum feste Begriffe notwendig sind
2. Die Objektkette (Quelle → Paket → Definition → Instanz)
3. LEFX-Quelle
4. LEFX-Paket
5. Definition
6. Preset
7. Konfiguration und Runtime-Eingaben
8. Steuerungskommando
9. Laufende Instanz
10. Overlay-Channel
11. Layer
12. LEFXSET
13. IDs und Namensräume
14. Sprachregel „Effekt“
15. Veraltete Begriffe

### Schwerpunkte

- Container, Beschreibung und Ausführung strikt unterscheiden
- Presets deutlich kleiner halten als Definitionen
- Konfiguration und Runtime-Eingaben früh trennen
- Channel als Runtime-Adresse, nicht als Effekt-ID erklären
- Den alleinstehenden Begriff „Effekt“ aus technischen Aussagen verdrängen
- Alte Begriffe sichtbar als historisch markieren

### Entscheidungen

1. **LEFX-Paket** als Standardbegriff; „Artefakt“ nur im Build-Kontext.
2. **Definition** als Kurzform verwenden, nachdem „Effektdefinition“ einmal erklärt wurde.
3. Deutsche Begriffe als Norm: **laufende Instanz**, **Steuerungskommando**; technische Namen (`EffectInvocation`, `Request`) nur in der technischen Referenz.
4. Das einzelne Wort **Effekt** in technischen Aussagen vermeiden.
5. Tabelle der veralteten V1-Begriffe als **historische Übersetzung** aufnehmen – im Archivbereich, nicht in der aktuellen Dokumentation.
6. Sprachregel: „Effektsystem“ als Oberbegriff, „Effektentwicklung“ als Tätigkeitsbegriff, „Effektpaket“ nur wenn eindeutig ein LEFX-Paket gemeint ist.

---

## Kapitel 3: Layer und Komposition

**Ziel:** Verständlich zeigen, wie laufende Instanzen angeordnet, ersetzt, aktualisiert und beendet werden. *(Auf Marcos Wunsch vor Kapitel 4 gezogen: Layerprinzip als Grundlage für das Typenverständnis.)*

### Gliederung

1. Layer als interne Engine-Struktur
2. Prioritätsstapel
3. Background State und Primary State
4. Setzen, Ersetzen und Löschen eines States
5. Lifecycle eines kontrollierten Overlays
6. Lifecycle eines zeitgesteuerten Overlays
7. Event-Queue
8. Transparenz und Komposition
9. Rückkehr zum darunterliegenden Bild
10. Verantwortung der Engine

### Layer-Stapel (von oben nach unten)

```text
Event                  (EVENT_LAYER)
Controlled Overlay     (ONGOING_OVERLAY_LAYER)
Timed Overlay          (TEMP_OVERLAY_LAYER)
Primary State          (STATE_LAYER)
Background State       (BACKGROUND_STATE_LAYER)
```

### Schwerpunkte

- Aufrufer wählen keine beliebigen Layer
- Typ und Overlay-Modus bestimmen die interne Platzierung
- `None` bei transparenten Frames: darunterliegenden Wert erhalten
- Die Engine beendet endliche Instanzen und verwaltet die Event-Queue
- Ein Paket besitzt keinen parallelen Lifecycle
- Lesbare Namen zuerst, technische Enum-Namen ergänzend
- Background und Primary als zwei unterschiedliche State-Plätze

### Entscheidungen

1. Reihenfolge beibehalten: **Controlled Overlay über Timed Overlay**; wirklich priorisierte Unterbrechungen gehören auf die Event-Ebene.
2. Öffentliche freie Layerauswahl ausdrücklich ausgeschlossen.
3. Layer als interne Engine-Struktur; Erklärung mit Schaubild der übereinanderliegenden (auch transparenten) Layer.

---

## Kapitel 4: Typen und Lebenszyklen

**Ziel:** Sicher entscheiden können, welcher Typ und welcher Lebenszyklus zur jeweiligen Anzeige passt.

### Gliederung

1. Vergleichsmatrix aller Lebenszyklusformen
2. State
3. Kontrolliertes Overlay (Push/Pull als Bezugsmodi)
4. Zeitgesteuertes Overlay
5. Event
6. Entscheidungshilfe
7. Ungültige Kombinationen

### Schwerpunkte

- State, Overlay und Event sind unveränderliche Typen, keine Presetvarianten
- Push und Pull sind **Bezugsmodi für Runtime-Eingaben**, keine Overlay-Untertypen
- Zeitgesteuerte Overlays sind nach der Aktivierung nicht aktualisierbar
- Events sind endlich, priorisiert und nicht nachträglich veränderbar
- Typvertrag und fachliche Verwendung werden getrennt: Regeln sind verbindlich, Beispiele (DoA, Fortschritt) sind Empfehlungen

### Lebenszyklus-Matrix

| Typ | Modus | Laufzeit | Runtime-Eingaben |
|---|---|---|---|
| State | immer kontrolliert | unbestimmt | nein |
| Overlay | `controlled` | unbestimmt | ja |
| Overlay | `timed` | endlich | nein |
| Event | fest vorgegeben | endlich | nein |

### Entscheidungen

1. Drei fachliche Typen, aber vier deutlich dargestellte Lebenszyklusformen.
2. Fachliche Einsatzzwecke als Orientierung, nicht als zusätzliche Schemaeinschränkung.
3. Vorläufig neutrale Beispiele verwenden, solange der produktive Effektkatalog noch überarbeitet wird.

---

## Kapitel 5: Schema V2

**Ziel:** Verbindliche technische Referenz für jede gültige Definition.

### Gliederung

1. Zweck des Schemas
2. Aufbau einer `EffectDefinition`
3. Identität und Metadaten
4. Typ und Overlay-Modus
5. Konfigurationsschema
6. Runtime-Input-Schema
7. Defaults
8. Capabilities
9. Layer-Regeln
10. Farbmodell und Komposition
11. Animation und Richtung
12. Input-Sampling
13. Bedingte Pflichtfelder
14. Übergreifende Invarianten
15. Ungültige Kombinationen
16. Verweis auf vollständige Beispiele

### Schwerpunkte

- Vollständige Referenz, aber keine riesigen JSON-Ausgaben
- Kleine kanonische Ausschnitte statt vollständiger Definitionen
- Vollständige Beispiele bleiben in `effect-development`
- Unbekannte Felder und ungültige Kombinationen werden strikt abgewiesen
- Die bisherige `planning/lefx_schema_v2.md` wird in diese Referenz überführt

### Entscheidungen

1. Deutscher Erklärungstext, technische Feld- und Enum-Namen unverändert Englisch.
2. Vollständige Feldreferenz, vollständige Effektquellen nur verlinken.
3. Regeln sichtbar als `Verpflichtend`, `Bedingt`, `Optional` oder `Empfehlung` kennzeichnen.
4. Bisherige V2-Schemadatei aus `planning` in die neue Referenz überführen; am alten Ort nur ein Archivhinweis.

---

## Kapitel 6: Parameter und Werte

**Ziel:** Erklären, welche Werte Definitionen anbieten, wie Eingaben benutzerfreundlich angenommen und intern strikt vereinheitlicht werden.

### Gliederung

1. Aufgabe eines Parameters
2. Konfigurationsauflösung
3. Verpflichtende und optionale Werte
4. Standardparameter
5. Farbmodelle
6. Komfortnotationen und Aliase
7. Kanonische interne Werte
8. Grenzen und Validierungsfehler

### Konfigurationsauflösung

```text
Definition-Defaults → Preset → explizite Werte des Steuerungskommandos
→ Validierung und Kanonisierung
```

### Schwerpunkte

- `speed` ist ein Multiplikator der Grundgeschwindigkeit, keine FPS-Angabe
- Tolerante Eingabegrenze (z. B. `blau`, `blue`, `#0000FF`, `0x0000FF`) vs. strenges internes Datenmodell
- Aliase gelten nur an der Systemgrenze
- Mehrdeutige und unbekannte Werte werden abgewiesen
- Zufallsfarben bleiben durch `random_seed` reproduzierbar
- Renderer erfinden keine eigenen Eingabeparser

### Entscheidungen

1. Standardparameter nur bei passendem Merkmal verpflichtend (z. B. `brightness`, `speed`, `reverse`, `direction_deg`, `progress`, `duration_ms`/`total_ms`).
2. Alle unterstützten Farbmodelle (`none`, `mono`, `dual`, `palette`, `gradient`, `random_range`) mit jeweils einem kleinen Beispiel darstellen.
3. Farbalias-Tabelle als eigene Referenztabelle statt langer Liste im Fließtext.
4. Klar trennen zwischen toleranter Eingabegrenze und strengem internen Datenmodell.

---

## Kapitel 7: Runtime-Eingaben

**Ziel:** Den vollständigen Datenweg kontrollierter Overlays erklären, ohne Push und Pull zu Untertypen aufzuwerten.

### Gliederung

1. Konfiguration gegenüber Runtime-Eingabe
2. Warum nur kontrollierte Overlays veränderliche Eingaben besitzen
3. Overlay-Channel
4. Push als Bezugsmodus
5. Pull als Bezugsmodus
6. Sampling-Intervall
7. Heartbeat und Karenzzeit
8. Input-Health
9. Fehlende Werte und `None`
10. DoA-Datenfluss
11. Verantwortungsgrenze zur Integration

### Schwerpunkte

- Push und Pull betreffen nur die Herkunft der Runtime-Eingaben
- `render()` erzeugt unabhängig davon den Frame
- Ein leeres Push-Update ist ein Lebenszeichen und behält vorhandene Werte
- Während der Karenzzeit bleibt der letzte gültige Wert bestehen; danach erhält der Renderer `None`
- Die Definition entscheidet, wie fehlende Daten dargestellt werden
- USB- und Hardwarelogik bleibt in der Integration
- Beispiele: DoA als durchgängiges Push-Beispiel, neutrales Sensorszenario als Pull-Beispiel, zusätzlich alltägliche Beispiele wie Countdown oder Lautstärkeregelung

### Entscheidungen

1. Allgemein von **Bezugsmodus für Runtime-Eingaben** sprechen; `InputMode.PUSH/PULL` nur technisch ergänzen.
2. Standard-Heartbeat `1000 ms × 3` erklären, als durch die Definition anpassbare Policy darstellen.
3. Die Engine bewertet Empfangsgesundheit, nicht die fachliche Qualität eines Messwertes.

---

## Kapitel 8: Pakete, IDs und Presets

**Ziel:** Erklären, wie Definitionen verpackt, identifiziert, vorkonfiguriert und zu Sets zusammengestellt werden.

### Gliederung

1. Quelle gegenüber gebautem Paket
2. Anatomie eines LEFX-Pakets
3. Source-ID
4. Package-ID
5. Definition-ID
6. Qualifizierte ID
7. Preset-ID
8. Globale Namensräume
9. Preset-Auflösung
10. LEFXSET
11. Thematische Paketsets
12. Versionen und Kompatibilität

### Schwerpunkte

- Ein LEFX-Paket enthält genau eine Definition
- Definition- und Preset-IDs teilen einen global eindeutigen öffentlichen Namensraum
- Die kurze ID ist die normale Benutzerform; qualifizierte IDs für Quellenangaben und Diagnose
- **Freie eigene Werte stehen im Vordergrund**; Presets sind nur Empfehlungen und werden unauffällig behandelt
- Ein LEFXSET fügt kein Verhalten hinzu; thematische Sets sind kuratierte Distributionen
- Buildbefehle folgen erst in Kapitel 10

### Entscheidungen

1. Kurze IDs als kanonische Benutzerform beibehalten.
2. Definition- und Preset-IDs global eindeutig halten.
3. Qualifizierte IDs hauptsächlich für Diagnose und explizite Quellenauswahl.
4. Thematische LEFXSETs als kuratierte Auslieferungseinheiten, nicht als neue fachliche Typen.
5. Endgültige Namen und Inhalte der produktiven Sets erst bei der Effektüberarbeitung festlegen.

---

## Kapitel 9: Bedienung über CLI und API

**Ziel:** Ein einheitliches Bedienmodell erklären, ohne CLI und HTTP als zwei verschiedene Systeme erscheinen zu lassen.

### Gliederung

1. Steuerungskommando als gemeinsames Modell
2. Verb-zuerst-Grammatik
3. State-Kommandos
4. Overlay-Kommandos
5. Event-Kommandos
6. Aktivierungsmodus
7. Listen und Detailabfragen
8. HTTP-Entsprechungen
9. Validierungsfehler und Vorschläge

### Kanonische Kommandos

```text
set state      clear state
set overlay    update overlay    clear overlay
emit event
list           show
```

### Schwerpunkte

- Dokumentiert werden nur vollständige kanonische Formen
- Tolerierte Kurzformen bleiben bewusst undokumentierte Eingabehilfe
- Listen liefern standardmäßig kompakte IDs; `--details` bzw. `?details=true` vollständige Metadaten
- `--json` verändert das CLI-Ausgabeformat, nicht den fachlichen Inhalt
- API-Antworten bleiben immer JSON
- Ungültige Eingaben verändern keine Runtime
- Fuzzy-Treffer werden nur vorgeschlagen, niemals automatisch ausgeführt

### Entscheidungen

1. Vokabular `set`, `update`, `clear`, `emit`, `list`, `show` beibehalten.
2. Ein bloßes `set` bedeutet idempotent „einschalten“; Toggle nur explizit mit `--toggle` (wiederholungs- und API-sicherer).
3. Undokumentierte eindeutige Kurzformen weiterhin akzeptieren, nach Annahme aber die kanonische Form melden.
4. Beispiele zuerst als CLI zeigen und jeweils auf die identische HTTP-Operation verweisen.

---

## Kapitel 10: Validierung und Build

**Ziel:** Den Weg von einer bearbeitbaren Quelle zu einem geprüften Distributionspaket erklären.

### Gliederung

1. Qualitätsgrenze des Builds
2. Quellenvalidierung
3. Import- und Strukturprüfung
4. Schema- und Vertragsprüfung
5. Smoke-Render
6. LEFX-Build
7. Paketverifikation
8. LEFXSET aus vorgebauten LEFX-Paketen
9. Standard-Build
10. Cache und Cleanup
11. Typische Fehler

### Build-Pipeline

```text
Quelle → validieren → importieren → Vertrag prüfen → Probe-Frame rendern
→ LEFX bauen → LEFX verifizieren → optional in LEFXSET aufnehmen
```

### Schwerpunkte

- `build/` enthält ausschließlich reproduzierbare Ergebnisse; autoritative Quellen liegen niemals darunter
- Ein LEFXSET wird bevorzugt aus bereits geprüften LEFX-Paketen gebaut
- Standard- und Fremdpakete verwenden dieselben grundlegenden Prüfschritte
- Smoke-Render ergänzt Tests, ersetzt sie aber nicht
- Zwischen-Caches werden nach erfolgreichem Build entfernt
- Fertige Ausgaben und temporäre Zwischenstände werden klar unterschieden

### Entscheidungen

1. Eine kompakte verbindliche Build-Checkliste zusätzlich zum erklärenden Text.
2. Befehle nur einmal vollständig im Entwicklerbereich dokumentieren; hier den Ablauf erklären.
3. Fehler nach Quelle, Schema, Import, Render und Paketstruktur gruppieren.

---

## Kapitel 11: Architekturgrenzen

**Ziel:** Verbindlich festlegen, welche Logik in Paket, Engine, Integration und Schnittstelle gehört.

### Gliederung

1. Verantwortungsmatrix
2. Autarkie eines LEFX-Pakets
3. Aufgaben der Engine
4. Aufgaben von Integrationen
5. Aufgaben von CLI und API
6. Erlaubte Abhängigkeiten
7. Lokale Hilfsmodule und Assets
8. Threads, I/O und Laufzeitgrenzen
9. Verbotene Kopplungen
10. Gültige und ungültige Beispiele

### Verantwortungsmatrix

| Bestandteil | Besitzt |
|---|---|
| Paket | visuelle Bedeutung, Renderlogik, Parametersemantik, Runtime-Input-Schema, optionale Presets, lokale Hilfsmodule und Assets |
| Engine | Typverträge, Lebenszyklen, Layer und Komposition, Input-Health, Queue, Hardwareausgabe |
| Integration | ReSpeaker- und andere Hardwarezugriffe, externe Datenquellen, anwendungsspezifische Zuordnung, Channel-Aktualisierungen |
| CLI/API | validierte Steuerung des Systems |

### Schwerpunkte

- Kein Controller-Code entscheidet anhand einer konkreten Definition-ID
- Keine generische `common.py` zwischen Paketen; paketlokale Hilfsmodule sind erlaubt
- Keine Imports anderer LEFX-Pakete
- Kein blockierendes I/O in `render()`; keine unverwalteten Hintergrundthreads
- `sample_inputs()` ist der kontrollierte Pull-Einstieg, kein zweiter Controller
- Allgemeine Validierung bleibt generisch; konkrete Effektbedeutung bleibt im Paket

### Entscheidungen

1. Unverwaltete Paket-Threads und blockierendes `render()` verbindlich ausschließen.
2. Paketlokale Hilfsmodule erlauben, gemeinsam genutzte Effektlogik ausschließen.
3. Hardwarezugriffe grundsätzlich über Integrationen führen; Pull nur für begrenzte paketlokale Datenquellen.
4. Zu jeder Architekturregel mindestens ein korrektes und ein falsches Gegenbeispiel zeigen.

---

## Kapitel 12: Status und Ausblick

**Ziel:** Klar trennen zwischen umgesetzt, verifiziert, noch offen und nur als Zukunftsidee vorgemerkt.

### Gliederung

1. Status von LEFX V2
2. Umgesetzte Kernfunktionen
3. Verifizierte Bereiche
4. Bewusst offene Arbeiten
5. Stand der DoA-Integration
6. Überarbeitung des produktiven Effektkatalogs
7. Kompatibilitätsgrenzen
8. Mögliche V3-Themen
9. Verweis auf das historische Archiv

### Statusmatrix

| Status | Bedeutung |
|---|---|
| Implementiert | Bestandteil des aktuellen Systems |
| Verifiziert | durch automatisierte oder praktische Prüfung bestätigt |
| Offen | gehört grundsätzlich noch zur aktuellen Ausbaustufe |
| V3-Idee | nicht beschlossen und nicht Teil von V2 |

### Schwerpunkte

- Schema, Runtime, CLI/API, Build und Paketvalidierung von V2 sind umgesetzt
- ReSpeaker-Firmware mit entkoppelten DoA-Werten installiert; produktive Live-USB-Integration noch offen
- Mitgelieferte Definitionen werden noch qualitativ überarbeitet und thematisch gruppiert
- LEFX-V1-Pakete werden nicht automatisch geraten oder still konvertiert
- Lifecycle-Hooks bleiben eine V3-Idee
- Ausführliche Entwicklungsgeschichte gehört ausschließlich ins Archiv
- **Keine** ständig veraltende Aufgabenliste und **keine** feste Testanzahl

### Entscheidungen

1. Kapitel 12 wie beschrieben, ohne volatile Aufgabenliste.
2. Zielstruktur von `docs` übernehmen.
3. **Alle** alten Dokumentationsdateien vollständig archivieren – auch leere, doppelte oder abgelöste Zwischenstände bleiben erhalten und werden gekennzeichnet; eine Migrationstabelle dokumentiert alten Pfad, Archivpfad, Rolle und Nachfolgedokument.
4. Nur für wirklich relevante alte Einstiegspfade Verweisdateien behalten; keinen neuen Bestand aus zahllosen Weiterleitungsdateien anlegen.

---

## Anhang A: Zielstruktur von `docs`

```text
docs/
├── index.md
├── getting_started.md
├── api_guide.md
├── troubleshooting.md
├── effects.md
│
├── effect-system/
│   ├── README.md
│   └── 01 bis 12
│
├── effect-development/
│   ├── templates/
│   ├── tutorials/
│   └── snippets/
│
├── examples/
│   └── effects/
│
├── dev/
│   ├── index.md
│   ├── architecture.md
│   ├── build.md
│   └── public_entry_points.md
│
├── planning/
│   ├── index.md
│   └── v3/
│
└── archive/
    ├── README.md
    ├── project-history/
    ├── effect-concepts/
    ├── sanitation-reports/
    └── prompts/
```

**Einordnung des Bestands:**

- `effects.md` bleibt ein kurzer Verteiler
- `current_approach.md` → in aktuelle Architekturkapitel einarbeiten
- `presets.md` → geht in Kapitel 8 auf
- `lefx_schema_v2.md` → geht in Kapitel 5 auf
- `reports/*` → `archive/sanitation-reports/`
- `history_and_legacy/*` → `archive/project-history/`
- Alte Effektkonzepte + Reihe `konzept_effekt_dateien` → `archive/effect-concepts/`
- Abgearbeitete Prompts → `archive/prompts/`
- V3-Lifecycle-Idee → `planning/v3/`
- Unter `planning` bleiben nur tatsächlich offene Planungen
- Jeder Archivbereich erhält eine README mit dem Hinweis: historisch, nicht normativ

---

## Anhang B: Bereinigungs- und Migrationsverfahren

1. Neue Ist-Dokumentation vollständig schreiben.
2. Für jede alte Datei festhalten, welche Aussagen übernommen wurden.
3. Zielpfad jeder Bestandsdatei in einer Migrationstabelle dokumentieren.
4. Alle internen Links auf die neue Struktur umstellen.
5. Historische Dateien ins Archiv verschieben (vollständig, nichts löschen).
6. Exakte Duplikate und leere Zwischenartefakte separat auflisten und kennzeichnen.
7. Markdown-Links und referenzierte Pfade automatisiert prüfen.
8. Archiv und aktuelle Doku deutlich gegeneinander kennzeichnen.
9. Die Dokumentationsmigration im gemeinsamen V2-Commit mitführen.

---

*Stand: alle zwölf Kapitel inhaltlich freigegeben. Quellenhinweis: abgeleitet aus dem freigegebenen Dokumentationsfahrplan (effect_system_documentation_roadmap.md) und der Chat-Historie.*
