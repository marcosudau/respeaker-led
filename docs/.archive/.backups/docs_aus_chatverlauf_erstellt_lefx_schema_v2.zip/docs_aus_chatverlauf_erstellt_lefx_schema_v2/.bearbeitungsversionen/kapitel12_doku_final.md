# Kapitel 12: Status und Ausblick

> **Hinweis:** Dieses Dokument enthält Kapitel 12 der technischen Dokumentation zum LED-Controller (LEFX Schema V2). Kapitel 1, 2, 3, 6, 7, 8, 9, 10 und 11 sind laut Dokumentationsfahrplan inhaltlich freigegeben.

**Ziel:** Dieses Kapitel trennt klar zwischen umgesetzten, verifizierten, noch offenen Arbeiten und solchen, die nur als Zukunftsidee vorgemerkt sind. Es beschreibt dauerhafte Fähigkeiten und bekannte Grenzen von LEFX V2. Eine ständig veraltende Aufgabenliste wird bewusst nicht geführt, ebenso wenig eine feste Testanzahl.

## 1. Status von LEFX V2

Der Status jedes Bereichs wird über die zentrale Statusmatrix bestimmt. Sie gilt für das gesamte Kapitel und wird in den Abschnitten 2 bis 9 angewendet.

### Statusmatrix

| Status | Bedeutung |
|---|---|
| Implementiert | Bestandteil des aktuellen Systems |
| Verifiziert | durch automatisierte oder praktische Prüfung bestätigt |
| Offen | gehört grundsätzlich noch zur aktuellen Ausbaustufe |
| V3-Idee | nicht beschlossen und nicht Teil von V2 |

### Status-Zuordnung der Bereiche

```mermaid
flowchart LR
    subgraph IMP[Implementiert – Bestandteil des aktuellen Systems]
        A1[Schema]
        A2[Runtime]
        A3[CLI/API]
        A4[Build]
        A5[Paketvalidierung]
        A6[ReSpeaker-Firmware mit entkoppelten DoA-Werten]
    end

    subgraph OFF[Offen – gehört zur aktuellen Ausbaustufe]
        B1[Produktive Live-USB-Integration]
        B2[Qualitative Überarbeitung und thematische Gruppierung der mitgelieferten Definitionen]
    end

    subgraph V3[V3-Idee – nicht beschlossen, nicht Teil von V2]
        C1[Lifecycle-Hooks]
    end

    KRI[Kriterium Verifiziert: durch automatisierte oder praktische Prüfung bestätigt]
    KRI -.-> IMP
```

Abbildung 1 zeigt die Zuordnung der Bereiche von LEFX V2 zu den Statuswerten der Statusmatrix. Der Status „Verifiziert" wird nach dem Kriterium der Statusmatrix nur dort vergeben, wo eine automatisierte oder praktische Prüfung vorliegt (Abschnitt 3).

## 2. Umgesetzte Kernfunktionen

Die Kernbereiche Schema, Runtime, CLI/API, Build und Paketvalidierung von V2 sind umgesetzt. Sie sind damit Bestandteil des aktuellen Systems.

| Bereich | Status |
|---|---|
| Schema | Implementiert |
| Runtime | Implementiert |
| CLI/API | Implementiert |
| Build | Implementiert |
| Paketvalidierung | Implementiert |

Der Status „Implementiert" bedeutet, dass der jeweilige Bereich Bestandteil des aktuellen Systems ist (vgl. Statusmatrix). Der Umsetzungsstand dieser fünf Kernbereiche ist damit festgestellt; die Paketvalidierung ist zugleich das automatisierte Prüfverfahren für Pakete im Rahmen von V2.

## 3. Verifizierte Bereiche

Als „Verifiziert" gilt ein Bereich nur dann, wenn eine automatisierte oder praktische Prüfung ihn bestätigt hat (vgl. Statusmatrix). Der Verifiziert-Status wird daher ausschließlich für Bereiche geführt, für die eine solche Prüfung vorliegt.

Für die umgesetzten Kernbereiche Schema, Runtime, CLI/API, Build und Paketvalidierung ist der Umsetzungsstand festgestellt; die Paketvalidierung stellt als Bestandteil von V2 ein automatisiertes Prüfverfahren für Pakete dar. Ausdrücklich nicht verifiziert ist die produktive Live-USB-Integration — sie ist noch offen und wird in den Abschnitten 4 und 5 geführt. Für die Dokumentation selbst sieht das Bereinigungs- und Migrationsverfahren eine automatisierte Prüfung von Markdown-Links und referenzierten Pfaden vor (Anhang B, Schritt 7).

## 4. Bewusst offene Arbeiten

Zwei Arbeiten gehören grundsätzlich noch zur aktuellen Ausbaustufe und sind bewusst offen:

- Die produktive Live-USB-Integration ist noch getrennt fertigzustellen (vgl. Abschnitt 5).
- Die mitgelieferten Definitionen werden noch qualitativ überarbeitet und thematisch gruppiert (vgl. Abschnitt 6).

Dieser Abschnitt führt bewusst keine ständig veraltende Aufgabenliste und keine feste Testanzahl. Er beschreibt dauerhafte Fähigkeiten und bekannte Grenzen: Der Status „Offen" kennzeichnet Arbeiten, die zur aktuellen Ausbaustufe gehören, aber noch nicht abgeschlossen sind.

## 5. Stand der DoA-Integration

Die ReSpeaker-Firmware mit entkoppelten DoA-Werten ist installiert und damit Bestandteil des aktuellen Systems. Davon getrennt zu betrachten ist die produktive Live-USB-Integration: Sie ist noch offen und muss getrennt fertiggestellt werden. Der Stand der DoA-Integration ist damit zweigeteilt — die Firmware mit den entkoppelten DoA-Werten ist umgesetzt, die produktive Anbindung über Live-USB ist offen.

## 6. Überarbeitung des produktiven Effektkatalogs

Die Überarbeitung des produktiven Effektkatalogs betrifft die mitgelieferten Definitionen: Sie werden noch qualitativ überarbeitet und thematisch gruppiert. Der Arbeitsstand ist offen und gehört zur aktuellen Ausbaustufe (vgl. Abschnitt 4). Der produktive Effektkatalog ist damit kein abgeschlossener Bestand, sondern Gegenstand einer laufenden, bewusst offen geführten Überarbeitung.

## 7. Kompatibilitätsgrenzen

LEFX-V1-Pakete werden nicht automatisch geraten oder still konvertiert. Es existiert keine automatische Übernahme von V1-Bestand in V2; eine Konvertierung erfolgt nicht ungefragt und nicht auf Basis von Annahmen. Diese Grenze ist bewusst gesetzt und gilt für den gesamten Bestand von V1-Paketen.

Auch dokumentarisch wird die Grenze zwischen Beständen deutlich gezogen: Inhalte des Archivs sind historisch und nicht normativ; sie sind von der aktuellen Dokumentation klar getrennt (Abschnitt 9 sowie Anhang A und B).

## 8. Mögliche V3-Themen

V3-Themen sind nicht beschlossen und nicht Teil von V2; der Status „V3-Idee" kennzeichnet reine Zukunftsideen (vgl. Statusmatrix). Als V3-Idee vorgemerkt sind insbesondere Lifecycle-Hooks. Die V3-Lifecycle-Idee wird außerhalb des aktuellen Dokuments unter `planning/v3/` geführt (vgl. Anhang A). V3-Themen stellen keine Zusage dar — sie sind vorgemerkt, aber nicht entschieden.

## 9. Verweis auf das historische Archiv

Die ausführliche Entwicklungsgeschichte gehört ausschließlich ins Archiv. Das Archiv ist in Bereiche gegliedert — `project-history`, `effect-concepts`, `sanitation-reports` und `prompts` — und jeder Archivbereich erhält eine README mit dem Hinweis, dass die Inhalte historisch und nicht normativ sind.

Die Zuordnung der alten Bestände zu ihren Zielorten ist in Anhang A dokumentiert; das Verschiebeverfahren in Anhang B. Verweisdateien werden nur für wirklich relevante alte Einstiegspfade angelegt, für die reale externe oder interne Links wahrscheinlich weiterbestehen; es entsteht kein neuer Bestand aus zahllosen Weiterleitungsdateien.

## Entscheidungen zu Kapitel 12

Die folgenden vier Entscheidungen sind verbindlich festgehalten. Die Nutzerentscheidung USER__021 bestätigt alle Punkte und präzisiert 12C dahingehend, dass nichts gelöscht wird: Alle alten Dateien werden vollständig archiviert, „aber halt in einem Archiv".

| Kennung | Festlegung |
|---|---|
| 12A | Kapitel 12 wie beschrieben, ohne volatile Aufgabenliste. |
| 12B | Zielstruktur von `docs` übernehmen. |
| 12C | **Alle** alten Dokumentationsdateien vollständig archivieren — auch leere, doppelte oder abgelöste Zwischenstände bleiben erhalten und werden gekennzeichnet; eine Migrationstabelle dokumentiert alten Pfad, Archivpfad, Rolle und Nachfolgedokument. (USER__021: „alte Dateien eigentlich alle archivieren, aber halt in einem Archiv") |
| 12D | Nur für wirklich relevante alte Einstiegspfade Verweisdateien behalten; keinen neuen Bestand aus zahllosen Weiterleitungsdateien anlegen. |

## Anhang A: Zielstruktur von `docs`

Die Zielstruktur des Dokumentationsverzeichnisses ist verbindlich:

```text
docs/
├── index.md
├── getting_started.md
├── api_guide.md
├── troubleshooting.md
├── effects.md
│
├── effect-system/
│   ├── README.md
│   └── 01 bis 12
│
├── effect-development/
│   ├── templates/
│   ├── tutorials/
│   └── snippets/
│
├── examples/
│   └── effects/
│
├── dev/
│   ├── index.md
│   ├── architecture.md
│   ├── build.md
│   └── public_entry_points.md
│
├── planning/
│   ├── index.md
│   └── v3/
│
└── archive/
    ├── README.md
    ├── project-history/
    ├── effect-concepts/
    ├── sanitation-reports/
    └── prompts/
```

### Einordnung des Bestands

Die Einordnung der vorhandenen Bestände folgt diesen Festlegungen:

- `effects.md` bleibt ein kurzer Verteiler.
- `current_approach.md` wird in aktuelle Architekturkapitel eingearbeitet.
- `presets.md` geht in Kapitel 8 auf.
- `lefx_schema_v2.md` geht in Kapitel 5 auf.
- `reports/*` wandert unter `archive/sanitation-reports/`.
- `history_and_legacy/*` wandert unter `archive/project-history/`.
- Alte Effektkonzepte und die Reihe `konzept_effekt_dateien` wandern unter `archive/effect-concepts/`.
- Abgearbeitete Prompts wandern unter `archive/prompts/`.
- Die V3-Lifecycle-Idee wandert aus `effect-development` nach `planning/v3/`.
- Unter `planning` bleiben danach nur tatsächlich offene Planungen.

Jeder Archivbereich erhält eine README mit dem Hinweis, dass die Inhalte historisch und nicht normativ sind.

### Migrationstabelle (Zuordnung Alter Bestand → Zielort)

Die Migrationstabelle dokumentiert für jeden Bestand den alten Pfad, den Zielort, die Rolle und das Nachfolgedokument. Sie wird bei der Migration je Datei fortgeschrieben (Anhang B, Schritte 2 und 3).

| Alter Pfad / Bestand | Zielpfad | Rolle | Nachfolgedokument |
|---|---|---|---|
| `docs/effects.md` | `docs/effects.md` (verbleibt) | kurzer Verteiler | `effects.md` (unverändert) |
| `current_approach.md` | Inhalt: aktuelle Architekturkapitel; Datei: `archive/project-history/` | abgelöster Zwischenstand | aktuelle Architekturkapitel |
| `presets.md` | Inhalt: Kapitel 8; Datei: `archive/project-history/` | abgelöster Zwischenstand | Kapitel 8 |
| `lefx_schema_v2.md` | Inhalt: Kapitel 5; Datei: `archive/project-history/` | abgelöster Zwischenstand | Kapitel 5 |
| `reports/*` | `archive/sanitation-reports/` | Sanierungsberichte | — (historisch, kein Nachfolgedokument) |
| `history_and_legacy/*` | `archive/project-history/` | Entwicklungsgeschichte | — (historisch, kein Nachfolgedokument) |
| alte Effektkonzepte, Reihe `konzept_effekt_dateien` | `archive/effect-concepts/` | Effektkonzepte | — (historisch, kein Nachfolgedokument) |
| abgearbeitete Prompts | `archive/prompts/` | abgearbeitete Prompts | — (historisch, kein Nachfolgedokument) |
| V3-Lifecycle-Idee | `planning/v3/` | offene Planung (V3-Idee) | `planning/v3/` |

Erläuterung: Dateien, deren Inhalte in aktuelle Kapitel eingehen (Architekturkapitel, Kapitel 5, Kapitel 8), wandern als Datei dennoch vollständig ins Archiv; das Nachfolgedokument verweist auf den Ort, an dem die übernommenen Aussagen weiterleben. Leere und exakte Duplikate werden separat gelistet und gekennzeichnet und bleiben ebenfalls vollständig erhalten (Anhang B, Schritte 5 und 6); ihre Archivpfade werden in der Migrationstabelle je Datei fortgeschrieben.

## Anhang B: Bereinigungs- und Migrationsverfahren

Das Verfahren gilt in der durch USER__021 bestätigten Fassung: **Es wird nichts gelöscht.** Die ursprünglich vorgesehene Freigabe zum Entfernen leerer oder vollständig redundanter Dateien entfällt — diese Dateien werden stattdessen vollständig archiviert und gekennzeichnet. Das Verfahren umfasst neun Schritte:

1. Neue Ist-Dokumentation vollständig schreiben.
2. Für jede alte Datei festhalten, welche Aussagen übernommen wurden.
3. Zielpfad jeder Bestandsdatei in einer Migrationstabelle dokumentieren.
4. Alle internen Links auf die neue Struktur umstellen.
5. Historische Dateien ins Archiv verschieben (vollständig, nichts löschen).
6. Exakte Duplikate und leere Zwischenartefakte separat auflisten und kennzeichnen.
7. Markdown-Links und referenzierte Pfade automatisiert prüfen.
8. Archiv und aktuelle Doku deutlich gegeneinander kennzeichnen.
9. Die Dokumentationsmigration im gemeinsamen V2-Commit mitführen.

```mermaid
flowchart TD
    START[Alte Dokumentationsdateien: vollständige Bestandsaufnahme] --> TAB[Migrationstabelle: alter Pfad, Archivpfad, Rolle, Nachfolgedokument]
    TAB --> MOVE[Verschiebung ins Archiv: vollständig, nichts wird gelöscht]
    MOVE --> P1[archive/project-history]
    MOVE --> P2[archive/effect-concepts]
    MOVE --> P3[archive/sanitation-reports]
    MOVE --> P4[archive/prompts]

    TAB --> INC{Inhalt für die aktuelle Doku relevant?}
    INC -->|Ja| NEW[In neue Kapitel eingearbeitet: Architekturkapitel, Kapitel 5, Kapitel 8]
    INC -->|Nein| OLD[Verbleibt ausschließlich im Archiv]

    TAB --> DUP{Exaktes Duplikat oder leeres Zwischenartefakt?}
    DUP -->|Ja| MARK[Separat auflisten und kennzeichnen: bleibt erhalten]
    MARK --> MOVE

    TAB --> V3I{V3-Lifecycle-Idee?}
    V3I -->|Ja| PL[planning/v3: offene Planung]

    TAB --> RED{Wirklich relevanter alter Einstiegspfad?}
    RED -->|Ja| LINK[Einzelne Verweisdatei auf die neue Struktur]
    RED -->|Nein| NOLINK[Keine weitere Verweisdatei]

    P1 --> RM[Archiv-README je Bereich: historisch, nicht normativ]
    P2 --> RM
    P3 --> RM
    P4 --> RM
```

Abbildung 2 zeigt den Migrationsfluss von den alten Dateien zu den Zielorten. Jede alte Datei wird über die Migrationstabelle erfasst und vollständig ins Archiv verschoben; Inhalte, die weiter relevant sind, werden parallel in die neue Dokumentation eingearbeitet. Verweisdateien entstehen nur für wirklich relevante alte Einstiegspfade, für die reale externe oder interne Links wahrscheinlich weiterbestehen — es entsteht kein neuer Bestand aus zahllosen Weiterleitungsdateien.
