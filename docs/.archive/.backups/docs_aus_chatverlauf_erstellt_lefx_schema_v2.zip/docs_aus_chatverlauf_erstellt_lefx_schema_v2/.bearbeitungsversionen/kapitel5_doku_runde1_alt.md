# LEFX – Dokumentation Kapitel 5 (Schema V2)

> **Hinweis zum Dokumentationsstand:** Kapitel 1 und 2 sind laut Dokumentationsfahrplan inhaltlich freigegeben. Dieses Dokument enthält Kapitel 5 (Schema V2).

**Hinweis zu Push/Pull (Nutzerentscheidung USER__018):** Push und Pull sind keine Untervarianten des kontrollierten Overlays, sondern **Bezugsmodi für Runtime-Eingaben**: Sie beschreiben einen Aspekt davon, wie die Engine Frames bezieht. Das kontrollierte Overlay bleibt ein Typ mit zwei Bezugsmodi.

**Faktenbasis:** Alle Aussagen dieses Dokuments stammen ausschließlich aus `kapitel3_bereich.md` (Abschnitte AGENT_017 und USER__018). Es wurden keine externen Fakten ergänzt.

---
# Kapitel 5: Schema V2

**Ziel:** Verbindliche technische Referenz für jede gültige Definition.

## Gliederung

1. Zweck des Schemas
2. Aufbau einer `EffectDefinition`
3. Identität und Metadaten
4. Typ und Overlay-Modus
5. Konfigurationsschema
6. Runtime-Input-Schema
7. Defaults
8. Capabilities
9. Layer-Regeln
10. Farbmodell und Komposition
11. Animation und Richtung
12. Input-Sampling
13. Bedingte Pflichtfelder
14. Übergreifende Invarianten
15. Ungültige Kombinationen
16. Verweis auf vollständige Beispiele

## 5.1 Zweck des Schemas

Das Schema ist die verbindliche technische Referenz für jede gültige Definition. Es legt fest, welche Felder eine Definition haben darf und muss, welche Kombinationen zulässig sind und welche Regeln für jeden Typ gelten. Unbekannte Felder und ungültige Kombinationen werden strikt abgewiesen. Die bisherige Schemadatei `planning/lefx_schema_v2.md` wird in diese Referenz überführt; am alten Ort verbleibt nur ein Archivhinweis.

## 5.2 Aufbau einer `EffectDefinition`

Eine `EffectDefinition` gliedert sich in die Abschnitte Identität und Metadaten, Typ und Overlay-Modus, Konfigurationsschema, Runtime-Input-Schema, Defaults und Capabilities.

```mermaid
flowchart TB
    D["EffectDefinition"]
    D --> I["Identität und Metadaten<br/>id · tags"]
    D --> T["Typ und Overlay-Modus<br/>overlay_mode"]
    D --> K["Konfigurationsschema"]
    D --> R["Runtime-Input-Schema<br/>input_sampling"]
    D --> F["Defaults"]
    D --> C["Capabilities"]
```

*Schaubild 5.1: Aufbau einer `EffectDefinition`.*

Diese Referenz zeigt kleine kanonische Ausschnitte statt vollständiger Definitionen; vollständige Beispiele bleiben in `effect-development` (siehe Abschnitt 5.16).

## 5.3 Identität und Metadaten

Die Referenztabelle des Schemas (Feld, Status, Bedeutung):

| Feld | Status | Bedeutung |
|---|---|---|
| `id` | verpflichtend | global eindeutige Definition-ID |
| `overlay_mode` | bedingt | nur für Overlays |
| `runtime_input_schema` | bedingt | nur für kontrollierte Overlays |
| `input_sampling` | bedingt | nur bei Runtime-Eingaben |
| `tags` | optional | Suche und Katalogisierung |

Die Identität einer Definition wird über die global eindeutige `id` hergestellt **[Verpflichtend]**. `tags` dienen der Suche und Katalogisierung **[Optional]**.

## 5.4 Typ und Overlay-Modus

Das Schema kennt die fachlichen Typen State, Overlay und Event. `overlay_mode` ist ein bedingtes Feld **[Bedingt]**: Es ist nur für Overlays zulässig und nimmt die Modi `controlled` (kontrolliertes Overlay) und `timed` (zeitgesteuertes Overlay) auf. Push und Pull sind keine Werte des Overlay-Modus: Sie sind Bezugsmodi für Runtime-Eingaben (siehe Abschnitt 5.6).

## 5.5 Konfigurationsschema

Das Konfigurationsschema beschreibt die typspezifischen Einstellungen einer Definition. Die konkreten Felder sind typabhängig; diese Referenz führt sie vollständig, zeigt aber nur kanonische Ausschnitte als Beispiele.

## 5.6 Runtime-Input-Schema

Das Runtime-Input-Schema ist ein bedingtes Feld **[Bedingt]**: Es ist nur für kontrollierte Overlays zulässig. Es beschreibt die Runtime-Eingaben einer laufenden Instanz. Die Bezugsmodi Push und Pull legen fest, wie die Engine die Frames bezieht: Push schiebt die Werte von der Quelle zur Engine, Pull zieht sie von der Quelle.

## 5.7 Defaults

Der Abschnitt Defaults hält die Standardwerte, die gelten, wenn eine Definition eine Angabe nicht explizit setzt. Die konkreten Defaults werden in der vollständigen Feldreferenz geführt.

## 5.8 Capabilities

Der Abschnitt Capabilities führt die Fähigkeiten auf, die eine Definition für ihre Laufzeit beansprucht. Die konkreten Angaben werden in der vollständigen Feldreferenz geführt.

## 5.9 Layer-Regeln

Die Platzierung einer laufenden Instanz bestimmen der Typ und – bei Overlays – der Overlay-Modus. Aufrufer wählen keine beliebigen Layer; die Zuordnung ist Teil des Schemas.

| Typ / Overlay-Modus | Platzierung im Stapel |
|---|---|
| State | `STATE_LAYER` oder `BACKGROUND_STATE_LAYER` |
| Overlay, Modus `controlled` | `ONGOING_OVERLAY_LAYER` |
| Overlay, Modus `timed` | `TEMP_OVERLAY_LAYER` |
| Event | `EVENT_LAYER` |

```mermaid
flowchart LR
    ST["State"] --> P["STATE_LAYER oder BACKGROUND_STATE_LAYER"]
    CO["Overlay, Modus controlled"] --> O["ONGOING_OVERLAY_LAYER"]
    TO["Overlay, Modus timed"] --> T["TEMP_OVERLAY_LAYER"]
    EV["Event"] --> EL["EVENT_LAYER"]
```

*Schaubild 5.2: Typ und Overlay-Modus bestimmen die Layer-Platzierung.*

## 5.10 Farbmodell und Komposition

Die Komposition der übereinanderliegenden Ebenen folgt den Regeln aus Kapitel 3: Ebenen können transparent sein; `None` bedeutet bei transparenten Frames, den darunterliegenden Wert zu erhalten. Das Farbmodell legt fest, wie die Farbwerte der Frames aufgebaut sind und wie sie beim Übereinanderlegen komponiert werden.

## 5.11 Animation und Richtung

Die Animation betrifft die zeitliche Entwicklung der Frames einer laufenden Instanz. Sie ist getrennt zu sehen von der Lebensdauer der Instanz und von der Aktualisierung der Runtime-Eingaben (Kapitel 3, Abschnitt 3.5). Die konkreten Animations- und Richtungsangaben werden in der vollständigen Feldreferenz geführt.

## 5.12 Input-Sampling

`input_sampling` ist ein bedingtes Feld **[Bedingt]**: Es ist nur bei Runtime-Eingaben zulässig. Es regelt die Abtastung der Runtime-Eingaben; die Bezugsmodi Push und Pull beschreiben, wie die Engine die Frames von der Eingabequelle bezieht (Abschnitt 5.6).

## 5.13 Bedingte Pflichtfelder

Bedingte Pflichtfelder sind nur unter einer bestimmten Bedingung zulässig beziehungsweise erforderlich:

| Feld | Bedingung |
|---|---|
| `overlay_mode` | nur für Overlays |
| `runtime_input_schema` | nur für kontrollierte Overlays |
| `input_sampling` | nur bei Runtime-Eingaben |

Außerhalb ihrer Bedingung sind die Felder unzulässig; die Definition wird dann strikt abgewiesen.

## 5.14 Übergreifende Invarianten

Die folgenden Invarianten gelten für jede Definition:

- **[Verpflichtend]** Unbekannte Felder werden strikt abgewiesen.
- **[Verpflichtend]** Ungültige Kombinationen werden strikt abgewiesen.
- **[Verpflichtend]** State, Overlay und Event sind unveränderliche Typen, keine Presetvarianten.
- **[Verpflichtend]** Aufrufer wählen keine beliebigen Layer; Typ und Overlay-Modus bestimmen die Platzierung.
- **[Verpflichtend]** Ein Paket besitzt keinen parallelen Lifecycle.
- **[Empfehlung]** Fachliche Einsatzzwecke sind Orientierung, keine Schemaeinschränkung.

## 5.15 Ungültige Kombinationen

Für jeden Typ gelten separate Invariantenlisten, aus denen sich die ungültigen Kombinationen ergeben.

**State**

- Gültig: immer kontrolliert, Laufzeit unbestimmt, keine Runtime-Eingaben, Platz auf `STATE_LAYER` oder `BACKGROUND_STATE_LAYER`.
- Ungültig: ein `overlay_mode` (nur für Overlays), ein Runtime-Input-Schema, endliche Laufzeit.

**Kontrolliertes Overlay**

- Gültig: Modus `controlled`, Laufzeit unbestimmt, Runtime-Eingaben mit den Bezugsmodi Push/Pull, Platz auf `ONGOING_OVERLAY_LAYER`.
- Ungültig: Modus `timed` (widerspricht der Matrix), `input_sampling` ohne Runtime-Eingaben, Bezugsmodi außerhalb des kontrollierten Overlays.

**Zeitgesteuertes Overlay**

- Gültig: Modus `timed`, Laufzeit endlich, keine Runtime-Eingaben, Platz auf `TEMP_OVERLAY_LAYER`.
- Ungültig: Runtime-Eingaben oder ein Runtime-Input-Schema, Aktualisierung nach der Aktivierung.

**Event**

- Gültig: fest vorgegeben, Laufzeit endlich, priorisiert, Platz auf `EVENT_LAYER`, Eingang über die Event-Queue.
- Ungültig: Runtime-Eingaben, nachträgliche Veränderung.

## 5.16 Verweis auf vollständige Beispiele

Diese Referenz enthält ausschließlich kleine kanonische Ausschnitte. Vollständige Beispiele bleiben in `effect-development` und werden von hier aus verlinkt. Die bisherige Schemadatei `planning/lefx_schema_v2.md` ist in diese Referenz überführt; am alten Ort verbleibt nur ein Archivhinweis.

## Entscheidungen zu Kapitel 5

1. **Sprache:** Deutscher Erklärungstext; technische Feld- und Enum-Namen bleiben unverändert Englisch.
2. **Umfang:** Vollständige Feldreferenz; vollständige Beispieldateien werden nur verlinkt (in `effect-development`); diese Referenz zeigt kleine kanonische Ausschnitte.
3. **Kennzeichnung:** Regeln sind sichtbar als `Verpflichtend`, `Bedingt`, `Optional` oder `Empfehlung` gekennzeichnet.
4. **Überführung:** Die bisherige V2-Schemadatei aus `planning` wird in diese Referenz überführt; am alten Ort verbleibt nur ein Archivhinweis.
