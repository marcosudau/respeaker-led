# Validierungsprotokoll Kapitel 3–5 – Runde 1

**Datum:** 2026-08-02
**Geprüfte Datei:** `kapitel3_doku_runde1.md` (536 Zeilen, ca. 27 KB, 3 Kapitel)
**Faktenquelle:** `kapitel3_bereich.md` (176 Zeilen, Z. 2426–2601 der Chat-Historie, AGENT_017 + USER__018)
**Gliederungsvorgabe:** `lefx_v2_doku_gesamtgliederung.md`, Kapitel 3 (10 Punkte), Kapitel 4 (7 Punkte), Kapitel 5 (16 Punkte)

---

## 1. Fakten-Check (streng)

Jede Aussage wurde gegen die Faktenquelle geprüft. Besonderheit dieses Blocks: Der Nutzer hat in USER__018 die **Kapitel-Reihenfolge getauscht** (Layer-Kapitel wird Kapitel 3) und **Push/Pull zu Bezugsmodi** gemacht. Beides wurde als Umsetzungsvorgabe übergeben.

### Kapitel 3: Layer und Komposition

| Abschnitt | Prüfung | Ergebnis |
|---|---|---|
| Ziel + Gliederung | Zieltext (Z. 53), 10 Gliederungspunkte (Z. 77–86) | ✅ wörtlich |
| 3.1 Interne Engine-Struktur | Aufrufer wählen keine Layer + Typ/Modus bestimmen Platzierung (Z. 96–97), freie Layerauswahl ausgeschlossen (Entscheidung 4C, Z. 112), lesbare Namen zuerst (4B, Z. 110–111), Enum-Tabelle (Z. 59–73) | ✅ wörtlich |
| 3.2 Prioritätsstapel | Stapel von oben nach unten wörtlich (Z. 59–65), Controlled über Timed + priorisierte Unterbrechungen auf Event-Ebene (Z. 104), Transparenz-Hinweis (Z. 97) | ✅ wörtlich |
| 3.3 Background/Primary | Zwei unterschiedliche State-Plätze (Entscheidung 4D, Z. 114–115), Background = unterste Ebene (Stapel Z. 59–65) | ✅ wörtlich |
| 3.4 Setzen/Ersetzen/Löschen | Gliederungspunkt 4 (Z. 80); die drei Kommandos und ihre Wirkungen sind eine minimale Erläuterung dieser Überschrift → **ableitbare Präzisierung**, kein neuer Fakt | ✅ |
| 3.5 Kontrolliertes Overlay | Drei Zeitdimensionen (Z. 88–92), unbestimmte Lebensdauer + Runtime-Eingaben ja (Matrix Z. 26–33), Push/Pull-Verweis auf 4.3 (USER__018) | ✅ wörtlich |
| 3.6 Zeitgesteuertes Overlay | Endliche Lebensdauer (Matrix), nach Aktivierung nicht aktualisierbar (Z. 36) | ✅ wörtlich |
| 3.7 Event-Queue | Engine verwaltet Event-Queue + beendet endliche Instanzen (Z. 98–99), Events endlich/priorisiert/nicht veränderbar (Z. 37), oberste Ebene (Z. 104) | ✅ wörtlich |
| 3.8 Transparenz | `None` = darunterliegenden Wert erhalten (Z. 97), Schaubild transparente Layer (USER__018, Z. 174) | ✅ wörtlich |
| 3.9 Rückkehr | Gliederungspunkt 9 (Z. 85); Inhalt folgt direkt aus Kompositionsregel (Z. 97) | ✅ |
| 3.10 Verantwortung der Engine | Engine beendet endliche Instanzen + verwaltet Queue (Z. 98–99), Paket ohne parallelen Lifecycle (Z. 100) | ✅ wörtlich |
| Entscheidungen Kap. 3 | 4A (Z. 108–109), 4C (Z. 112), 4D (Z. 114–115) als Festlegungen; Schaubild-Anforderung aus USER__018 | ✅ wörtlich |

### Kapitel 4: Typen und Lebenszyklen

| Abschnitt | Prüfung | Ergebnis |
|---|---|---|
| 4.1 Vergleichsmatrix | Lebenszyklus-Matrix 4 Zeilen wörtlich (Z. 26–33); 9-Aspekte-Tabelle: Quelle nennt nur die Aspektnamen (Z. 22–30) — die Doku befüllt sie mit ausschließlich aus Matrix, Schwerpunkten und USER__018 ableitbaren Werten, markiert nicht festgelegte Zellen mit „—" und erklärt die Push/Pull-Einordnung in einem Hinweis → **vorbildlich vorsichtig, ableitbar** | ✅ |
| 4.2 State | Immer kontrolliert/unbestimmt/keine Eingaben (Matrix), unveränderlicher Typ (Z. 34), zwei State-Plätze (Kap. 3) | ✅ wörtlich |
| 4.3 Kontrolliertes Overlay | Modus `controlled` (Matrix), **Push/Pull als Bezugsmodi, keine Untervarianten** (USER__018, Z. 174) | ✅ wörtlich |
| 4.4 Zeitgesteuertes Overlay | Modus `timed`, endlich, keine Eingaben, nach Aktivierung fixiert (Matrix + Z. 36) | ✅ wörtlich |
| 4.5 Event | Fest vorgegeben/endlich/priorisiert/nicht veränderbar (Z. 37), Event-Queue + oberste Ebene (Kap. 3) | ✅ wörtlich |
| 4.6 Entscheidungshilfe | Gliederungspunkt 6 (Z. 27); das Flussdiagramm visualisiert ausschließlich die Matrix-Dimensionen (Runtime-Eingaben, Laufzeit, Priorisierung) → **ableitbare Darstellung**, keine neuen Fakten; Trennung Typvertrag vs. fachliche Verwendung (Z. 38), neutrale Beispiele (Entscheidung 3D, Z. 46–49) | ✅ |
| 4.7 Ungültige Kombinationen | Gliederungspunkt 7 (Z. 28); Inhalte aus Matrix + `overlay_mode` nur für Overlays (Z. 145) + Bezugsmodi-Regel (USER__018) abgeleitet, konsistent | ✅ |
| Entscheidungen Kap. 4 | Nr. 1 = Push/Pull-Bezugsmodi (USER__018, abweichend von 3B), Nr. 2 = 3A (Z. 42–43), Nr. 3 = 3C (Z. 44–45), Nr. 4 = 3D (Z. 46–49) | ✅ wörtlich |

### Kapitel 5: Schema V2

| Abschnitt | Prüfung | Ergebnis |
|---|---|---|
| 5.1 Zweck | Ziel (Z. 119), strikte Abweisung (Z. 156), Überführung `planning/lefx_schema_v2.md` (Z. 158) | ✅ wörtlich |
| 5.2 Aufbau | Gliederungspunkte 2–8 (Z. 125–131) als Abschnittsübersicht zusammengefasst | ✅ |
| 5.3 Referenztabelle | 5 Zeilen wörtlich (Z. 142–148); `id` global eindeutig, `tags` Suche/Katalogisierung | ✅ wörtlich |
| 5.4 Typ/Modus | `overlay_mode` bedingt, nur Overlays, `controlled`/`timed` (Z. 145 + Matrix); Push/Pull nicht in `overlay_mode` = USER__018-Umsetzung | ✅ |
| 5.5–5.8 | Gliederungspunkte (Z. 127–131); minimale Erläuterungen der Begriffe (Konfiguration, Runtime-Input, Defaults, Capabilities), keine neuen Fakten | ✅ |
| 5.9 Layer-Regeln | Typ + Overlay-Modus bestimmen Platzierung (Z. 96–97); Enum-Zuordnung aus Stapel (Z. 59–73) + 4D; State → `STATE_LAYER`/`BACKGROUND_STATE_LAYER` aus Stapel + 4D ableitbar | ✅ |
| 5.10–5.11 | Gliederungspunkte (Z. 132–133); Inhalte verweisen auf Kap.-3-Regeln bzw. die drei Zeitdimensionen (Z. 88–92) | ✅ |
| 5.12 Input-Sampling | `input_sampling` bedingt, nur bei Runtime-Eingaben (Z. 147) | ✅ wörtlich |
| 5.13 Bedingte Pflichtfelder | Aus Referenztabelle (Z. 142–148); „außerhalb der Bedingung unzulässig" folgt aus strikter Abweisung (Z. 156) | ✅ |
| 5.14 Invarianten | Unbekannte Felder/ungültige Kombinationen strikt abweisen (Z. 156), Typen unveränderlich (Z. 34), keine freie Layerwahl (Z. 96), Paket ohne Lifecycle (Z. 100), Einsatzzwecke Orientierung (Z. 38 + 3C) | ✅ wörtlich |
| 5.15 Ungültige Kombinationen | Separate Invariantenlisten je Typ (Z. 150); Gültig/Ungültig-Zuordnungen konsistent mit Matrix und Referenztabelle | ✅ |
| 5.16 Verweis | Beispiele in `effect-development` (Z. 154–155), Archivhinweis am alten Ort (Z. 158) | ✅ wörtlich |
| Entscheidungen Kap. 5 | 5A–5D (Z. 162–169) als Festlegungen | ✅ wörtlich |

### Nutzerentscheidungen USER__018 — Umsetzungsprüfung

| Vorgabe | Umsetzung | Ergebnis |
|---|---|---|
| Kapitel 4 (Layer) VOR Kapitel 3 (Typen) ziehen | **Kapitel 3 = Layer und Komposition** (steht zuerst), **Kapitel 4 = Typen und Lebenszyklen** (danach), Kapitel 5 danach; Reihenfolge im Kopfhinweis ausdrücklich begründet | ✅ exakt |
| Layer ausführlicher erklären + Schaubild mit transparenten Layern | Abschnitte 3.1–3.10, Schaubild 3.1 (Stapel) + 3.7 (Komposition mit transparentem Frame) | ✅ |
| Push/Pull nicht als Overlay-Untertypen, sondern Bezugsmodi für Runtime-Eingaben | Nirgends als Untertypen; 4.3 (Definition + Schaubild 4.1), Entscheidung Kap. 4 Nr. 1, 5.4/5.6/5.12 klargestellt (keine `overlay_mode`-Werte) | ✅ exakt |

### Ableitbare Präzisierungen (kein Rücksendegrund, quellenkonform)

1. **3.4 Kommandowirkungen:** Quelle nennt nur die Gliederungsüberschrift „Setzen, Ersetzen und Löschen eines States". Die Zuordnung (Setzen = platziert, Ersetzen = tauscht, Löschen = beendet) ist die minimale natürliche Erläuterung der Überschrift.
2. **4.1 9-Aspekte-Tabelle:** Quelle nennt nur die Aspektnamen. Alle Zelleninhalte sind aus Matrix, Schwerpunkten und USER__018 ableitbar; nicht festgelegte Zellen sind mit „—" und Hinweis markiert.
3. **4.6 Entscheidungsfluss:** Das Diagramm visualisiert nur die Matrix-Dimensionen, keine neuen Fakten.
4. **5.9 State-Platzierung:** `STATE_LAYER`/`BACKGROUND_STATE_LAYER` folgt aus dem Layer-Stapel und Entscheidung 4D.

### Ergebnis Fakten-Check

**BESTANDEN ✅** — keine unbelegten Aussagen, keine Erfindungen, keine Widersprüche zur Quelle. Die beiden Nutzerentscheidungen (Kapitel-Umsortierung, Push/Pull-Bezugsmodi) sind exakt und durchgängig umgesetzt, auch im Schema-Kapitel (Push/Pull erscheinen nirgends als `overlay_mode`-Werte).

---

## 2. Qualitäts-Check (Formales, Lesbarkeit)

| Kriterium | Befund |
|---|---|
| Gliederungstreue | Kapitel 3: exakt 10 Punkte, Kapitel 4: exakt 7 Punkte, Kapitel 5: exakt 16 Punkte; je Kapitel „Entscheidungen zu Kapitel N" am Ende |
| Mermaid-Diagramme | 12 gesamt (Kap. 3: 7, Kap. 4: 3, Kap. 5: 2) — ≥ 6 gefordert ✅; Layer-Stapel-Schaubild mit transparenten Layern vorhanden |
| Tabellen | 10 (Enum-Zuordnung, State-Kommandos, Zeitdimensionen, Lebenszyklus-Matrix, 9-Aspekte, Referenztabelle, Bedingte Pflichtfelder, Layer-Platzierung, …) |
| Begriffs-Einheitlichkeit | Durchgängig „laufende Instanz", „Steuerungskommando", „kontrolliertes Overlay", „zeitgesteuertes Overlay"; alleinstehendes „Effekt" nur in `EffectDefinition` (technischer Name) und „Effektkatalog" (Quellbegriff, belegt) |
| Stil | Kein Dialog, keine „Ich"-Formulierungen, verbindliche Festlegungen, professioneller Ton; Kennzeichnung `[Verpflichtend]`/`[Bedingt]`/`[Optional]`/`[Empfehlung]` in Kapitel 5 |
| Schwerpunkte erkennbar | ① Layer-Prinzip vor Typen (Reihenfolge + Begründung) ② Push/Pull als Bezugsmodi durchgängig ③ drei Zeitdimensionen je Lifecycle ④ transparente Komposition mit Schaubild ⑤ Typvertrag vs. fachliche Verwendung getrennt ⑥ neutrale Beispiele |
| Transparenz | „—"-Zellen in der 9-Aspekte-Tabelle mit Hinweis erklärt; Faktenbasis im Kopf dokumentiert |

### Ergebnis Qualitäts-Check

**BESTANDEN ✅**

---

## 3. Entscheidung

**Kapitel 3, 4 und 5 sind VALIDIERT ✅**

- Fakten-Check: bestanden (alle Abschnitte aller drei Kapitel, inkl. USER__018-Umsetzungsprüfung)
- Qualitäts-Check: bestanden
- 4 ableitbare Präzisierungen im Protokoll vermerkt, kein Rücksendegrund
- `kapitel3_doku_runde1.md` wird als finale Fassung übernommen (Kopie: `kapitel3_doku_final.md`)

*Keine Runde 2 erforderlich.*

---

## 4. Nachtrag (2026-08-02): Aufteilung der Final-Dateien

Auf Wunsch von Marco wurden die drei Kapitel aus der gemeinsamen Runde-1-Datei in **getrennte Final-Dateien** aufgeteilt (Inhalt unverändert, nur je ein passender Kopf mit Dokumentationsstand ergänzt):

| Kapitel | Final-Datei | Herkunft (Zeilen in Sammeldatei) |
|---|---|---|
| 3 | `kapitel3_doku_final.md` | Z. 11–233 |
| 4 | `kapitel4_doku_final.md` | Z. 234–365 |
| 5 | `kapitel5_doku_final.md` | Z. 366–535 |

`kapitel3_doku_runde1_sammel.md` bleibt unverändert als vollständige Runde-1-Sammeldatei erhalten (Prüfgegenstand des Fakten-Checks). Zusätzlich wurden die Runde-1-Dateien einzeln angelegt (`kapitel3_doku_runde1.md`, `kapitel4_doku_runde1.md`, `kapitel5_doku_runde1.md`); die Kapitel-Inhalte sind per `diff` gegen die Final-Dateien als identisch verifiziert.
