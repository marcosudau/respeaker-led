# Kapitel 11: Architekturgrenzen

**Hinweis:** Dieses Dokument enthält Kapitel 11 der technischen Dokumentation zum LED-Controller (LEFX Schema V2). Kapitel 1, 2, 3, 6, 7, 8, 9 und 10 sind laut Dokumentationsfahrplan inhaltlich freigegeben.

**Ziel:** Verbindlich festlegen, welche Logik in Paket, Engine, Integration und Schnittstelle (CLI/API) gehört.

Das Kapitel definiert die Architekturgrenzen der LEFX-Schema-V2-Architektur. Es legt die Zuständigkeiten der vier Bestandteile Paket, Engine, Integration und CLI/API verbindlich fest, unterscheidet erlaubte von verbotenen Abhängigkeiten und belegt jede Regel mit mindestens einem korrekten und einem falschen Gegenbeispiel (Festlegung 11D).

---

## 1. Verantwortungsmatrix

Die Verantwortungsmatrix ordnet jedem Bestandteil verbindlich zu, was er besitzt. Sie ist die normative Grundlage aller Regeln dieses Kapitels.

| Bestandteil | Besitzt |
|---|---|
| Paket | visuelle Bedeutung, Renderlogik, Parametersemantik, Runtime-Input-Schema, optionale Presets, lokale Hilfsmodule und Assets |
| Engine | Typverträge, Lebenszyklen, Layer und Komposition, Input-Health, Queue, Hardwareausgabe |
| Integration | ReSpeaker- und andere Hardwarezugriffe, externe Datenquellen, anwendungsspezifische Zuordnung, Channel-Aktualisierungen |
| CLI/API | validierte Steuerung des Systems |

```mermaid
graph TD
    P["Paket (LEFX-Paket)"] --> P1["visuelle Bedeutung"]
    P --> P2["Renderlogik"]
    P --> P3["Parametersemantik"]
    P --> P4["Runtime-Input-Schema"]
    P --> P5["optionale Presets"]
    P --> P6["lokale Hilfsmodule und Assets"]
    E["Engine"] --> E1["Typverträge"]
    E --> E2["Lebenszyklen"]
    E --> E3["Layer und Komposition"]
    E --> E4["Input-Health"]
    E --> E5["Queue"]
    E --> E6["Hardwareausgabe"]
    I["Integration"] --> I1["ReSpeaker- und andere Hardwarezugriffe"]
    I --> I2["externe Datenquellen"]
    I --> I3["anwendungsspezifische Zuordnung"]
    I --> I4["Channel-Aktualisierungen"]
    C["CLI/API"] --> C1["validierte Steuerung des Systems"]
```

Aus der Matrix ergeben sich die zentralen Trennlinien:

- Das **Paket** bestimmt, *was* dargestellt wird und *wie* die Darstellung berechnet wird (Renderlogik) – aber nicht, *wann* gerendert wird und auf welcher Hardware die Ausgabe erfolgt.
- Die **Engine** bestimmt, wann ein LEFX-Paket lebt, in welcher Reihenfolge Layer komponiert werden und wie Ergebnisse über die Queue zur Hardwareausgabe gelangen.
- Die **Integration** vermittelt zwischen dem System und der Außenwelt (Hardwarezugriffe, externe Datenquellen) und übernimmt die anwendungsspezifische Zuordnung sowie Channel-Aktualisierungen.
- **CLI/API** validieren Eingaben und steuern das System; sie enthalten keine Renderlogik und keine Hardwarezugriffe.

---

## 2. Autarkie eines LEFX-Pakets

Ein LEFX-Paket ist autark: Es bringt alles mit, was es für seine visuelle Bedeutung, Renderlogik, Parametersemantik, sein Runtime-Input-Schema, optionale Presets sowie lokale Hilfsmodule und Assets benötigt. Es importiert keine anderen LEFX-Pakete und nutzt keine generische gemeinsame `common.py` zwischen Paketen.

**Regel 2.1 — Autarkie:** Ein LEFX-Paket enthält seine gesamte paketrelevante Logik selbst.

Korrekt:

```python
# paket_a/helpers.py – paketlokales Hilfsmodul
def gamma(k: int) -> float:
    return (k / 255.0) ** 2.2

# paket_a/render.py – importiert nur paketlokale Module
from .helpers import gamma
```

Falsch:

```python
# paket_a/render.py – verboten: Import eines anderen LEFX-Pakets
from paket_b.palette import build_palette  # verboten
```

**Regel 2.2 — Keine gemeinsam genutzte Effektlogik:** Paketlokale Hilfsmodule sind erlaubt; eine gemeinsam genutzte Effektlogik zwischen Paketen ist ausgeschlossen.

Korrekt: Jedes LEFX-Paket führt seine eigene Renderlogik und eigene paketlokale Hilfsmodule. Kleine lokale Duplikate sind der geteilten Effektlogik vorzuziehen.

Falsch:

```python
# common/effektlogik.py – verboten: gemeinsam genutzte Effektlogik
def blend(src, dst):
    ...
# paket_a und paket_b importieren beide daraus  # verboten
```

---

## 3. Aufgaben der Engine

Die Engine besitzt Typverträge, Lebenszyklen, Layer und Komposition, Input-Health, Queue und Hardwareausgabe.

**Regel 3.1 — Lebenszyklus:** Die Engine steuert, wann ein LEFX-Paket initialisiert, gerendert und beendet wird. Das Paket besitzt die Renderlogik, die Engine besitzt den Lebenszyklus.

Korrekt:

```python
# Engine: verwaltet Lebenszyklus und Komposition über Typverträge
class Engine:
    def start(self, paket: PaketVertrag) -> None:
        paket.initialisiere()          # Lebenszyklus durch die Engine
        self.layer.append(paket)
```

Falsch:

```python
# verboten: Paket verwaltet seinen eigenen Lebenszyklus von außen
paket.loop_forever_in_engine_context()  # verboten – Lebenszyklus gehört der Engine
```

**Regel 3.2 — Keine Definition-ID-Entscheidungen:** Kein Controller-Code entscheidet anhand einer konkreten Definition-ID.

Korrekt:

```python
# Engine: generische Behandlung über Typverträge, ohne konkrete Definition-ID
def render_layer(self, paket: PaketVertrag) -> None:
    self.queue.push(paket.render())  # generisch
```

Falsch:

```python
# verboten: Entscheidung anhand einer konkreten Definition-ID
if definition_id == "led_fx_welle_42":   # verboten
    self.special_handling()
```

**Regel 3.3 — Generische Validierung:** Die allgemeine Validierung bleibt generisch; die konkrete Effektbedeutung bleibt im Paket.

Korrekt:

```python
# Engine: schema-basierte, generische Prüfung (Input-Health)
def validate_input(self, schema: InputSchema, wert: object) -> bool:
    return schema.pruefen(wert)
```

Falsch:

```python
# verboten: Engine interpretiert die konkrete Parameterbedeutung
if parameter_name == "geschwindigkeit":   # verboten
    if wert > 5:
        reject()
```

---

## 4. Aufgaben von Integrationen

Integrationen besitzen ReSpeaker- und andere Hardwarezugriffe, externe Datenquellen, anwendungsspezifische Zuordnung und Channel-Aktualisierungen.

**Regel 4.1 — Hardwarezugriffe über Integrationen:** Hardwarezugriffe werden grundsätzlich über Integrationen geführt.

Korrekt:

```python
# Integration ReSpeaker: einziger Zugriffspunkt auf das Gerät
class ReSpeakerIntegration:
    def hole_frequenz(self) -> float:
        return self.device.read()   # Hardwarezugriff hier
```

Falsch:

```python
# verboten: Paket greift direkt auf Hardware zu
class Paket:
    def render(self, params):
        freq = usb_device.read()    # verboten – Hardwarezugriff im Paket
```

**Regel 4.2 — `sample_inputs()` als kontrollierter Pull-Einstieg:** `sample_inputs()` ist der kontrollierte Pull-Einstieg und kein zweiter Controller. Pull ist nur für begrenzte paketlokale Datenquellen zulässig; Hardwarezugriffe bleiben der Integration vorbehalten.

Korrekt:

```python
# Paket: begrenzte paketlokale Datenquelle als Pull
def sample_inputs(self) -> dict:
    return {"akku_stand": self.sensor_lesen()}
```

Falsch:

```python
# verboten: Paket betreibt über sample_inputs() einen zweiten Controller
def sample_inputs(self) -> dict:
    return self.eigener_controller.steuere_komplett()  # zweiter Controller – verboten
```

---

## 5. Aufgaben von CLI und API

CLI/API besitzen die validierte Steuerung des Systems.

**Regel 5.1 — Validierte Steuerung:** CLI/API validieren Eingaben und steuern das System. Sie enthalten keine Renderlogik, keine Hardwarezugriffe und keine anwendungsspezifische Zuordnung.

Korrekt:

```python
# CLI: validiert Parameter und delegiert an die Engine
def run(self, args) -> None:
    params = self.validiere(args)
    self.engine.start(params)   # Steuerung
```

Falsch:

```python
# verboten: CLI entscheidet anhand einer konkreten Definition-ID
if args.definition_id == "led_fx_42":   # verboten
    self.special_control()
```

---

## 6. Erlaubte Abhängigkeiten

Die folgende Tabelle legt erlaubte und verbotene Abhängigkeiten verbindlich fest.

| Von | Zu | Erlaubt? | Begründung |
|---|---|---|---|
| CLI/API | Engine | erlaubt | validierte Steuerung über Typverträge |
| CLI/API | Integration | erlaubt | validierte Steuerung der Integrationsdienste |
| Engine | LEFX-Paket | erlaubt | Lebenszyklus, Layer und Komposition über Typverträge |
| Engine | Hardwareausgabe | erlaubt | Queue und Hardwareausgabe gehören zur Engine |
| Integration | Hardware (ReSpeaker u. a.) | erlaubt | Hardwarezugriffe gehören zur Integration |
| Integration | externe Datenquellen | erlaubt | externe Datenquellen gehören zur Integration |
| LEFX-Paket | anderes LEFX-Paket | verboten | keine Imports anderer LEFX-Pakete |
| LEFX-Paket | gemeinsame `common.py` | verboten | keine generische `common.py` zwischen Paketen |
| LEFX-Paket | Hardware | verboten | Hardwarezugriffe nur über Integrationen |
| Engine | konkrete Definition-ID | verboten | keine Entscheidung anhand einer konkreten Definition-ID |

---

## 7. Lokale Hilfsmodule und Assets

**Regel 7.1 — Paketlokale Hilfsmodule sind erlaubt:** Ein LEFX-Paket darf eigene Hilfsmodule innerhalb des Pakets führen. Das Paket besitzt seine lokalen Hilfsmodule und Assets.

Korrekt (Struktur eines autarken LEFX-Pakets):

```
paket_a/
├── __init__.py
├── render.py
├── schema.py         # Runtime-Input-Schema
├── presets.py        # optionale Presets
├── helpers.py        # paketlokales Hilfsmodul
└── assets/
    └── tiefenkarte.dat
```

Falsch (gemeinsames Modul außerhalb des Pakets):

```
# verboten: generische common.py zwischen Paketen
shared/
└── common.py         # verboten
```

**Regel 7.2 — Gemeinsam genutzte Effektlogik ausgeschlossen:** Paketlokale Hilfsmodule sind erlaubt; eine gemeinsam genutzte Effektlogik zwischen Paketen ist ausgeschlossen.

Korrekt: Jedes LEFX-Paket hält seine Effektlogik in eigenen lokalen Modulen; die Engine bleibt generisch.

Falsch:

```python
# verboten: Paket b importiert Effektlogik aus Paket a
from paket_a.effektlogik import blend   # verboten
```

---

## 8. Threads, I/O und Laufzeitgrenzen

**Regel 8.1 — Kein blockierendes I/O in `render()`:** `render()` ist eine reine Berechnungsfunktion ohne blockierendes I/O.

Korrekt:

```python
def render(self, params: dict) -> Frame:
    return self.berechne_frame(params)   # reine Berechnung
```

Falsch:

```python
def render(self, params: dict) -> Frame:
    daten = open("/tmp/daten.bin").read()  # verboten: blockierendes I/O
    time.sleep(0.5)                        # verboten: blockierender Aufruf
    return self.berechne_frame(params)
```

**Regel 8.2 — Keine unverwalteten Hintergrundthreads:** Ein LEFX-Paket startet keine eigenen Threads; Threads und Laufzeitsteuerung sind Sache der Engine.

Korrekt: Das Paket liefert Logik; die Engine verwaltet Ausführung und Lebenszyklen.

Falsch:

```python
# verboten: Paket startet unverwalteten Hintergrundthread
class Paket:
    def __init__(self):
        threading.Thread(target=self.loop).start()   # verboten
```

**Regel 8.3 — `sample_inputs()` als kontrollierter Pull-Einstieg:** `sample_inputs()` ist der kontrollierte Pull-Einstieg des Pakets, kein zweiter Controller.

Korrekt: Die Engine ruft `sample_inputs()` zu definierten Zeitpunkten auf; das Paket liefert nur Daten.

Falsch: Das Paket ruft `sample_inputs()` selbst periodisch in einem eigenen Thread auf oder steuert daraus weitere Komponenten.

```mermaid
sequenceDiagram
    participant E as Engine
    participant P as LEFX-Paket
    participant I as Integration
    E->>P: sample_inputs() (kontrollierter Pull)
    P-->>E: paketlokale Eingabedaten
    E->>I: Anfrage (z. B. ReSpeaker-Daten)
    I-->>E: Daten aus Hardwarezugriff
    E->>P: render() (ohne blockierendes I/O)
    P-->>E: Frame
    E->>E: Queue, Layer und Komposition, Hardwareausgabe
```

---

## 9. Verbotene Kopplungen

Die folgenden Kopplungen sind verbindlich verboten:

1. Entscheidung von Controller-Code anhand einer konkreten Definition-ID.
2. Generische `common.py` zwischen Paketen.
3. Imports anderer LEFX-Pakete.
4. Blockierendes I/O in `render()`.
5. Unverwaltete Hintergrundthreads in Paketen.
6. `sample_inputs()` als zweiter Controller.
7. Konkrete Effektbedeutung in der allgemeinen Validierung der Engine.
8. Hardwarezugriffe außerhalb von Integrationen.

```mermaid
graph TD
    subgraph Erlaubt["Erlaubte Abhängigkeiten"]
        A["CLI/API"] -->|"validierte Steuerung"| B["Engine"]
        A -->|"validierte Steuerung"| C["Integration"]
        B -->|"Typverträge, Lebenszyklus"| D["LEFX-Paket"]
        B -->|"Queue, Hardwareausgabe"| HW["Hardware"]
        C -->|"Hardwarezugriffe"| HW
        C -->|"externe Datenquellen"| X["Externe Quellen"]
        D -->|"sample_inputs() – begrenzter Pull"| LQ["paketlokale Datenquelle"]
    end
    subgraph Verboten["Verbotene Kopplungen"]
        D -.->|"Import anderer LEFX-Pakete"| D2["anderes LEFX-Paket"]
        D -.->|"blockierendes I/O in render()"| IO["Dateisystem / Netzwerk"]
        D -.->|"unverwalteter Hintergrundthread"| T["Thread"]
        D -.->|"direkter Hardwarezugriff"| HW
        B -.->|"Entscheidung anhand konkreter Definition-ID"| ID["Definition-ID"]
    end
```

---

## 10. Gültige und ungültige Beispiele

Die folgende Tabelle zeigt je Regel ein korrektes (gültiges) und ein falsches (ungültiges) Gegenbeispiel.

| # | Regel | Gültig (korrekt) | Ungültig (falsch) |
|---|---|---|---|
| 1 | Autarkie eines LEFX-Pakets | Paket importiert nur eigene Module | `from paket_b import ...` |
| 2 | Keine gemeinsam genutzte Effektlogik | jedes Paket hält eigene Logik | `common.py` wird von zwei Paketen genutzt |
| 3 | Lebenszyklus in der Engine | Engine startet und beendet das Paket | Paket verwaltet seinen Lebenszyklus selbst |
| 4 | Keine Definition-ID-Entscheidung | generische Behandlung über Typverträge | `if definition_id == "led_fx_42": ...` |
| 5 | Validierung generisch | Engine prüft schema-basiert | Engine interpretiert Parameterbedeutung |
| 6 | Hardwarezugriffe über Integrationen | ReSpeaker-Zugriff in der Integration | USB-Read direkt im Paket |
| 7 | CLI/API steuern validiert | CLI validiert und delegiert an die Engine | CLI enthält Renderlogik |
| 8 | Kein blockierendes I/O in `render()` | reine Berechnung | `open(...)` / `sleep(...)` in `render()` |
| 9 | Keine unverwalteten Threads | Ausführung durch die Engine | `threading.Thread` im Paket |
| 10 | `sample_inputs()` kontrollierter Pull | Engine ruft Pull zu Zeitpunkten auf | Paket pollt selbst im eigenen Thread |

---

## Entscheidungen zu Kapitel 11

Die folgenden Festlegungen sind verbindlich und Bestandteil der Architektur.

**Festlegung 11A — Unverwaltete Paket-Threads und blockierendes `render()` verbindlich ausschließen.** Pakete dürfen keine unverwalteten Hintergrundthreads starten; `render()` darf kein blockierendes I/O enthalten. Laufzeitsteuerung und Threads liegen bei der Engine.

**Festlegung 11B — Paketlokale Hilfsmodule erlauben, gemeinsam genutzte Effektlogik ausschließen.** Pakete dürfen eigene lokale Hilfsmodule führen; eine generische `common.py` zwischen Paketen und eine gemeinsam genutzte Effektlogik sind verboten.

**Festlegung 11C — Hardwarezugriffe grundsätzlich über Integrationen führen.** Pull ist nur für begrenzte paketlokale Datenquellen erlaubt (`sample_inputs()` als kontrollierter Pull-Einstieg); direkte Hardwarezugriffe aus Paketen sind verboten.

**Festlegung 11D — Zu jeder Architekturregel mindestens ein korrektes und ein falsches Gegenbeispiel zeigen.** Diese Anforderung ist in Kapitel 11 mit den Gegenbeispielen in den Regeln und der Beispieltabelle umgesetzt und gilt für alle künftigen Architekturregeln.
