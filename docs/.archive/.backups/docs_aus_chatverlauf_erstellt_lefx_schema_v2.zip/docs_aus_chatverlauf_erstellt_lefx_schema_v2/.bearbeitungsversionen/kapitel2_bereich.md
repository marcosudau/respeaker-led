### AGENT_016


Kapitel 1 ist im [Dokumentationsfahrplan](C:/Users/marco/source/experiments/led_controller_respeaker_effects_schema_v2_2026-07-29/docs/planning/effect_system_documentation_roadmap.md) als inhaltlich freigegeben festgehalten.

## Kapitel 2: Begriffe und Systemobjekte

**Ziel:** Nach diesem Kapitel muss eindeutig sein, ob wir über eine bearbeitbare Quelle, ein gebautes Paket, eine Definition, eine Konfiguration oder eine laufende Instanz sprechen.

Das Kapitel soll noch keine vollständigen Schema- oder Lifecycle-Regeln erklären.

#-> 1. Warum feste Begriffe notwendig sind

Kurze Einleitung:

- Das Wort „Effekt“ wurde historisch für verschiedene Dinge verwendet.
- Daraus entstanden Missverständnisse zwischen Datei, Definition, Preset und laufender Ausführung.
- V2 verwendet deshalb präzise Begriffe.
- Derselbe Begriff muss in Dokumentation, Fehlermeldungen, CLI und API dieselbe Bedeutung besitzen.

#-> 2. Die Objektkette

Das sollte die zentrale Darstellung des Kapitels werden:

```mermaid
flowchart LR
    A["LEFX-Quelle"] -->|"Build"| B["LEFX-Paket"]
    B -->|"Laden"| C["Registrierte Definition"]
    C -->|"Steueranfrage + Konfiguration"| D["Laufende Instanz"]
    E["Preset"] --> C
    F["Runtime-Eingaben"] --> D
```

Wichtig dabei:

- Die Quelle ist bearbeitbar.
- Das Paket ist das gebaute, unveränderliche Artefakt.
- Die Definition beschreibt Möglichkeiten und Regeln.
- Die Instanz ist die konkrete laufende Ausführung.
- Presets konfigurieren eine Definition.
- Runtime-Eingaben verändern eine laufende kontrollierte Overlay-Instanz.

#-> 3. LEFX-Quelle

Verbindliche Definition:

> Eine LEFX-Quelle ist das bearbeitbare Verzeichnis, aus dem ein LEFX-Paket gebaut wird.

Sie enthält beispielsweise:

- `effect.yaml`
- `effect.py`
- `presets.yaml`
- lokale Module
- Assets

**Wichtig:** Die Quelle ist nicht das ausgelieferte Paket und keine laufende Instanz.

#-> 4. LEFX-Paket

Verbindliche Definition:

> Ein LEFX-Paket ist ein gebautes `.lefx`-Artefakt, das genau eine vollständige State-, Overlay- oder Event-Definition enthält.

Das Paket besitzt:

- Definition und Schema
- Renderlogik
- Metadaten
- optionale Presets
- lokale Assets und Module

Hier würde ich **LEFX-Paket** als normalen Begriff verwenden. „Artefakt“ kommt nur zum Einsatz, wenn wir ausdrücklich über ein Build-Ergebnis sprechen.

#-> 5. Definition

Verbindliche Definition:

> Eine Definition beschreibt einen State, ein Overlay oder ein Event, aber noch keine laufende Ausführung.

Sie enthält:

- Typ
- Metadaten
- Konfigurationsschema
- gegebenenfalls Runtime-Input-Schema
- Defaults
- Capabilities
- Layer- und Lifecycle-Vertrag
- visuelle Merkmale

Wichtige Abgrenzung:

- Die Definition enthält keinen aktiven Runtime-Zustand.
- Die Renderlogik gehört zum Paket.
- Eine Definition wird durch ein Preset nicht zu einem anderen Typ.

#-> 6. Preset

Verbindliche Definition:

> Ein Preset ist eine benannte, paketinterne Vorkonfiguration genau einer Definition.

Ein Preset darf:

- Farben auswählen
- Geschwindigkeit setzen
- Helligkeit konfigurieren
- andere deklarierte Konfigurationswerte vorbelegen

Ein Preset darf nicht:

- aus einem State ein Event machen
- den Overlay-Modus verändern
- andere Layer auswählen
- Runtime-Eingaben enthalten
- eine eigene Definition darstellen

**Kernaussage:** Ein Preset ist keine Unterart eines Effekts.

#-> 7. Konfiguration und Runtime-Eingaben

Diese Begriffe sollten direkt gegenübergestellt werden:

| Konfiguration | Runtime-Eingaben |
|---|---|
| wird beim Aktivieren aufgelöst | verändert sich während der Laufzeit |
| stammt aus Defaults, Preset und Overrides | stammt aus Push- oder Pull-Daten |
| bleibt für die Instanz stabil | darf kontrollierte Overlays aktualisieren |
| beispielsweise Farbe oder Geschwindigkeit | beispielsweise Richtung oder Fortschritt |

Das ist besonders für DoA wichtig:

```text
color = Konfiguration
direction_deg = Runtime-Eingabe
```

#-> 8. Steueranfrage

Verbindliche Definition:

> Eine Steueranfrage beschreibt eine gewünschte Operation, die vor jeder Runtime-Änderung vollständig validiert wird.

Beispiele:

- State setzen
- Overlay öffnen
- Overlay aktualisieren
- Event auslösen
- Instanz entfernen

Ich würde zuerst **Steueranfrage** schreiben und beim ersten Auftreten den technischen Begriff `Request` ergänzen.

#-> 9. Laufende Instanz

Verbindliche Definition:

> Eine laufende Instanz ist die konkrete Aktivierung einer Definition mit aufgelöster Konfiguration, Startzeit, Lebenszyklusdaten und gegebenenfalls Runtime-Eingaben.

Wichtig:

- Definition und Instanz sind getrennt.
- Eine Definition kann nacheinander mehrfach instanziiert werden.
- Events können als getrennte Instanzen in der Queue liegen.
- Kontrollierte Overlays werden über ihren Channel adressiert.

Den internen Klassennamen `EffectInvocation` würde ich in diesem allgemeinen Kapitel nicht nach vorne stellen. Er gehört in die technische Referenz.

#-> 10. Overlay-Channel

Verbindliche Definition:

> Ein Overlay-Channel ist der eindeutige Runtime-Name einer kontrollierten Overlay-Instanz.

Er dient zum:

- Aktualisieren
- Senden eines Lebenszeichens
- Schließen der Instanz

Ein Channel ist:

- keine Definition-ID
- keine Package-ID
- kein Layer
- kein Preset

#-> 11. Layer

Hier nur eine kurze Begriffsdefinition:

> Ein Layer ist eine von der Engine verwaltete interne Kompositionsstufe für LED-Frames.

Noch nicht erklären:

- vollständige Layerliste
- Prioritäten
- Queue-Verhalten
- Persistenz

Das folgt in Kapitel 4.

#-> 12. LEFXSET

Verbindliche Definition:

> Ein LEFXSET ist ein Distributionspaket, das mehrere bereits eigenständige LEFX-Pakete zusammenfasst.

Wichtig:

- Es fügt kein neues Verhalten hinzu.
- Es verändert keine Definition.
- Es ist kein großer Effekt mit mehreren Untereffekten.
- Seine Mitglieder bleiben getrennte Definitionen.

#-> 13. IDs und Namensräume

In Kapitel 2 nur die Arten einführen:

- Definition-ID
- Preset-ID
- Source-ID
- Package-ID
- qualifizierte ID
- Overlay-Channel

Die Auflösungsregeln und globale Eindeutigkeit folgen ausführlich in Kapitel 8.

#-> 14. Sprachregel „Effekt“

Mein Vorschlag:

- **Effektsystem** bleibt der Oberbegriff.
- **Effektentwicklung** darf als allgemeiner Tätigkeitsbegriff verwendet werden.
- **Effektpaket** ist akzeptabel, wenn eindeutig ein LEFX-Paket gemeint ist.
- Das einzelne Wort **Effekt** wird in technischen Aussagen vermieden.
- Stattdessen verwenden wir State, Overlay, Event, Definition, Paket, Preset oder Instanz.

Beispiel:

```text
Ungenau:
Der Effekt wird aktualisiert.

Präzise:
Die Runtime-Eingaben der kontrollierten Overlay-Instanz werden aktualisiert.
```

#-> 15. Veraltete Begriffe

Ich würde am Ende eine kleine Warnbox aufnehmen:

| Alter Begriff | V2-Entsprechung |
|---|---|
| generischer Effekt | konkrete State-, Overlay- oder Event-Definition |
| Effect-Preset als eigener Typ | Preset einer konkreten Definition |
| Embedded Command | CLI/API-Steueranfrage oder Integration |
| `MAIN_LAYER` | kein öffentliches V2-Konzept |
| Effekt wählt seinen Layer | Typvertrag bestimmt die interne Platzierung |

Das hilft besonders beim Lesen alter Planungsunterlagen.

## Schwerpunkte

1. Container, Beschreibung und Ausführung strikt unterscheiden.
2. Presets deutlich kleiner halten als Definitionen.
3. Konfiguration und Runtime-Eingaben früh trennen.
4. Den Channel als Runtime-Adresse und nicht als Effekt-ID erklären.
5. Den alleinstehenden Begriff „Effekt“ aus technischen Aussagen verdrängen.
6. Alte Begriffe sichtbar als historisch markieren.

## Entscheidungen zu Kapitel 2

1. **LEFX-Paket** als Standardbegriff und „Artefakt“ nur im Build-Kontext?  
   **Empfehlung:** Ja.

2. **Definition** als Kurzform verwenden, nachdem einmal „Effektdefinition“ erklärt wurde?  
   **Empfehlung:** Ja.

3. Den deutschen Begriff **laufende Instanz** verwenden und `EffectInvocation` nur in der technischen Referenz erwähnen?  
   **Empfehlung:** Ja.

4. **Steueranfrage** als normalen Begriff verwenden und `Request` nur ergänzend nennen?  
   **Empfehlung:** Ja.

5. Das einzelne Wort **Effekt** in technischen Aussagen möglichst vermeiden?  
   **Empfehlung:** Ja.

6. Eine Tabelle mit veralteten V1-Begriffen aufnehmen?  
   **Empfehlung:** Ja, aber klar als historische Übersetzung und nicht als Migrationsunterstützung.

### USER__017 -> Dokumentation - Kapitel 3-5: Effekttypen, Lifecycle/Layer und Schema V2
Ja, ich finde auch jetzt wieder deine Vorschläge sind alle genau ins Schwarze getroffen. Allerdings bei Nummer vier, aber das ist reine Geschmackssache, würde es mir besser gefallen, wenn wir statt Steueranfrage den Begriff SteuerungsKommando nehmen. Und bei Nummer sechs, dann sollten wir diese Tabelle in den Archivbereich beziehungsweise wo wir diese ganze Archivsammlung und alles haben, und nicht als Teil der aktuellen Doku behandeln. Könntest du bitte jetzt immer immer drei Punkte zusammen machen, damit wir das besser durchkriegen? Weil sonst müssen wir noch voll viele machen....



