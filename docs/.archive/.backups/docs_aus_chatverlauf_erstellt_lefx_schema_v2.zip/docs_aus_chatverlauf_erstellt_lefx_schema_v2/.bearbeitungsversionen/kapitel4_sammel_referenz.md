# Kapitel 4: Typen und Lebenszyklen

**Ziel:** Der Leser soll sicher entscheiden können, welcher Typ und welcher Lebenszyklus zu seiner Anzeige passt.

## Gliederung

1. Vergleichsmatrix aller Lebenszyklusformen
2. State
3. Kontrolliertes Overlay (Push/Pull als Bezugsmodi)
4. Zeitgesteuertes Overlay
5. Event
6. Entscheidungshilfe
7. Ungültige Kombinationen

## 4.1 Vergleichsmatrix aller Lebenszyklusformen

Es gibt drei fachliche Typen – State, Overlay und Event –, aber vier deutlich dargestellte Lebenszyklusformen, weil das Overlay in zwei Modi auftritt. Die Lebenszyklus-Matrix ist verbindlich:

| Typ | Modus | Laufzeit | Runtime-Eingaben |
|---|---|---|---|
| State | immer kontrolliert | unbestimmt | nein |
| Overlay | `controlled` | unbestimmt | ja |
| Overlay | `timed` | endlich | nein |
| Event | fest vorgegeben | endlich | nein |

Die zentrale Tabelle zeigt darüber hinaus die weiteren Aspekte der Lebenszyklusformen: Zweck, Lebensdauer, Aktivierung, Aktualisierbarkeit, Beendigung, Runtime-Eingaben, Channel, Queue und Komposition.

| Aspekt | State | Kontrolliertes Overlay | Zeitgesteuertes Overlay | Event |
|---|---|---|---|---|
| Zweck | Grunddarstellung über zwei State-Plätze | laufende Funktionsanzeige | zeitlich begrenzte Anzeige | priorisierte Unterbrechung |
| Lebensdauer | unbestimmt | unbestimmt | endlich | endlich |
| Aktivierung | Setzen per Steuerungskommando | Aktivierung | Aktivierung | Eingang über die Event-Queue |
| Aktualisierbarkeit | Ersetzen per Steuerungskommando | Runtime-Eingaben aktualisierbar | nach der Aktivierung nicht aktualisierbar | nicht nachträglich veränderbar |
| Beendigung | Löschen per Steuerungskommando | — | durch die Engine (endliche Laufzeit) | durch die Engine (endliche Laufzeit) |
| Runtime-Eingaben | nein | ja (Bezugsmodi Push und Pull) | nein | nein |
| Channel | — | Push/Pull (Bezug der Frames) | — | — |
| Queue | — | — | — | Event-Queue |
| Komposition | unterste Ebenen des Stapels | über dem zeitgesteuerten Overlay | unter dem kontrollierten Overlay | oberste Ebene (Event-Ebene) |

> **Hinweis:** Zellen mit „—“ sind im vorliegenden Schema-Stand nicht festgelegt; die verbindliche technische Referenz folgt in Kapitel 5. Die Einordnung von Push/Pull unter „Channel“ folgt der Nutzerentscheidung USER__018: Push und Pull beschreiben, wie die Engine die Frames bezieht.

## 4.2 State

Der State ist eine unveränderliche Lebenszyklusform, keine Presetvariante. Er ist immer kontrolliert, hat eine unbestimmte Laufzeit und erhält keine Runtime-Eingaben. Er wird über die Steuerungskommandos Setzen, Ersetzen und Löschen geführt und belegt einen der beiden State-Plätze (Background State oder Primary State). Neutrales Beispiel: eine dauerhafte Grunddarstellung ohne zeitliche Begrenzung und ohne laufende Eingaben.

## 4.3 Kontrolliertes Overlay (Push/Pull als Bezugsmodi)

Das kontrollierte Overlay ist ein Typ mit dem Modus `controlled`: unbestimmte Laufzeit und Runtime-Eingaben, die während der Laufzeit aktualisiert werden können. Es ist eine unveränderliche Lebenszyklusform, keine Presetvariante.

Push und Pull sind keine Untervarianten des kontrollierten Overlays und keine Overlay-Untertypen. Sie sind **Bezugsmodi für Runtime-Eingaben**: Sie beschreiben einen Aspekt davon, wie die Engine Frames bezieht. Das kontrollierte Overlay bleibt in beiden Fällen ein Typ mit zwei Bezugsmodi.

```mermaid
flowchart LR
    subgraph Q["Eingabequelle (Runtime-Eingaben)"]
        V["Werte der Eingabequelle"]
    end
    subgraph EN["Engine"]
        F["Frame-Erzeugung des kontrollierten Overlays"]
    end
    V -->|"Push: Die Quelle schiebt Werte zur Engine"| F
    F -->|"Pull: Die Engine zieht Werte von der Quelle"| V
```

*Schaubild 4.1: Die Bezugsmodi Push und Pull für Runtime-Eingaben.*

Neutrales Beispiel: eine laufende Anzeige, deren Inhalt sich aus Eingaben speist und während der Laufzeit aktualisiert werden kann.

## 4.4 Zeitgesteuertes Overlay

Das zeitgesteuerte Overlay ist ein Typ mit dem Modus `timed`: endliche Laufzeit und keine Runtime-Eingaben. Nach der Aktivierung ist es nicht aktualisierbar; die Engine beendet die Instanz am Ende der Laufzeit. Es ist eine unveränderliche Lebenszyklusform, keine Presetvariante. Neutrales Beispiel: ein kurzer Hinweis, der automatisch endet.

## 4.5 Event

Das Event ist eine unveränderliche Lebenszyklusform mit fester Vorgabe: endliche Laufzeit, keine Runtime-Eingaben, priorisiert und nicht nachträglich veränderbar. Events erreichen über die Event-Queue die oberste Ebene des Stapels und unterbrechen als priorisierte Unterbrechung alle darunterliegenden Ebenen. Neutrales Beispiel: eine sofortige, vorrangige Unterbrechungsmeldung mit fest vorgegebenem Inhalt.

## 4.6 Entscheidungshilfe

Die Entscheidung für eine Lebenszyklusform lässt sich an drei Fragen festmachen: Werden Runtime-Eingaben benötigt? Ist die Laufzeit endlich? Handelt es sich um eine priorisierte Unterbrechung mit fester Vorgabe?

```mermaid
flowchart TB
    A{"Werden Runtime-Eingaben benötigt?"}
    A -->|"ja"| B{"Ist die Laufzeit endlich?"}
    B -->|"ja"| X["Ungültige Kombination<br/>(siehe Abschnitt 4.7)"]
    B -->|"nein"| CO["Kontrolliertes Overlay<br/>Laufzeit unbestimmt, Bezugsmodi Push/Pull"]
    A -->|"nein"| C{"Ist die Laufzeit endlich?"}
    C -->|"nein"| ST["State<br/>Laufzeit unbestimmt, immer kontrolliert"]
    C -->|"ja"| D{"Priorisierte Unterbrechung mit fester Vorgabe?"}
    D -->|"ja"| EV["Event<br/>endlich, priorisiert, fest vorgegeben"]
    D -->|"nein"| TO["Zeitgesteuertes Overlay<br/>endlich, nach Aktivierung fixiert"]
```

*Schaubild 4.2: Entscheidungsfluss zur Wahl der Lebenszyklusform.*

Typvertrag und fachliche Verwendung werden getrennt behandelt: Die Regeln der Lebenszyklusformen sind verbindlich; fachliche Einsatzzwecke sind Orientierung und keine zusätzliche Schemaeinschränkung. Die in der Quelle genannten Beispiele (etwa eine DoA-Anzeige oder eine Fortschrittsanzeige) sind Empfehlungen. Solange der produktive Effektkatalog noch überarbeitet wird, verwendet dieses Dokument vorläufig neutrale Beispiele.

```mermaid
gantt
    title Lebenszyklusformen im Vergleich (Laufzeit)
    dateFormat X
    axisFormat %s
    section State
    Laufzeit unbestimmt: 0, 100
    section Kontrolliertes Overlay
    Laufzeit unbestimmt: 0, 100
    section Zeitgesteuertes Overlay
    Laufzeit endlich: 0, 30
    section Event
    Laufzeit endlich: 0, 8
```

*Schaubild 4.3: Vergleich der Laufzeiten aller vier Lebenszyklusformen.*

## 4.7 Ungültige Kombinationen

Aus der Lebenszyklus-Matrix und den Festlegungen der Typen ergeben sich folgende ungültige Kombinationen:

- **Zeitgesteuertes Overlay mit Runtime-Eingaben:** Die Matrix ordnet dem Modus `timed` keine Runtime-Eingaben zu.
- **Event mit Runtime-Eingaben:** Das Event ist fest vorgegeben und erhält keine Runtime-Eingaben.
- **State mit Overlay-Modus:** `overlay_mode` gilt nur für Overlays; der State ist immer kontrolliert.
- **Bezugsmodi außerhalb des kontrollierten Overlays:** Push und Pull sind Bezugsmodi für Runtime-Eingaben; ohne Runtime-Eingaben (State, zeitgesteuertes Overlay, Event) sind sie unzulässig.
- **Aktualisierung nach der Aktivierung:** Ein zeitgesteuertes Overlay ist nach der Aktivierung nicht aktualisierbar; ein Event ist nicht nachträglich veränderbar.

## Entscheidungen zu Kapitel 4

1. **Push und Pull als Bezugsmodi für Runtime-Eingaben:** Sie sind keine Untervarianten des kontrollierten Overlays (abweichend von der ursprünglichen Empfehlung 3B); das kontrollierte Overlay bleibt ein Typ mit zwei Bezugsmodi, die beschreiben, wie die Engine Frames bezieht.
2. **Drei fachliche Typen, vier Lebenszyklusformen:** State, Overlay und Event bleiben unveränderliche Typen, keine Presetvarianten; die vier Lebenszyklusformen werden deutlich dargestellt (State, kontrolliertes Overlay, zeitgesteuertes Overlay, Event).
3. **Fachliche Einsatzzwecke als Orientierung:** Sie sind keine zusätzliche Schemaeinschränkung; die Regeln des Typvertrags sind verbindlich.
4. **Vorläufig neutrale Beispiele:** Solange der produktive Effektkatalog überarbeitet wird, werden neutrale Beispiele verwendet; die fachlichen Beispiele aus der Quelle (DoA, Fortschrittsanzeige) bleiben Empfehlungen.

---

