# Kapitel 8: Pakete, IDs und Presets

> **Hinweis zum Dokumentationsfahrplan:** Die Kapitel 1–5 sind laut Dokumentationsfahrplan inhaltlich freigegeben; Kapitel 6 ist validiert. Das vorliegende Dokument enthält Kapitel 8 (Pakete, IDs und Presets).

**Ziel:** Erklären, wie Definitionen verpackt, identifiziert, vorkonfiguriert und zu Sets zusammengestellt werden.

## Einordnung und Begriffe

Dieses Kapitel behandelt vier zusammenhängende Fragen: Wie wird eine Definition in ein LEFX-Paket verpackt? Wie werden die beteiligten Objekte identifiziert? Wie lässt sich Konfiguration vorab bereitstellen? Und wie werden Pakete zu Sets zusammengestellt?

Dabei gilt eine klare Gewichtung: Die Hauptfunktion besteht darin, **eigene Werte frei zu setzen**. Vorkonfigurationen — im Folgenden als Presets bezeichnet — sind ausschließlich Empfehlungen und Vorschläge. Sie sind keine vorbereiteten Standardlösungen und werden in diesem Kapitel entsprechend unauffällig behandelt: Sie werden erst nach der Erläuterung der freien eigenen Werte eingeführt und durchgängig als Empfehlung bezeichnet.

**Begriffsverwendung.** In diesem Kapitel gelten einheitlich die folgenden Begriffe:

- **Definition** — der inhaltliche Kern eines LEFX-Pakets; sie trägt die Konfiguration und damit die frei setzbaren Werte.
- **laufende Instanz** — die aktiv betriebene Ausprägung einer Definition.
- **Steuerungskommando** — ein Kommando, das an eine laufende Instanz gerichtet wird; in der Benutzerform wird dafür die kurze ID verwendet.
- **LEFX-Paket** — die gebaute Verteilungseinheit, die genau eine Definition enthält.
- **qualifizierte ID** — die um eine Quellenangabe ergänzte Form einer ID; sie dient expliziten Quellenangaben und Diagnosen.
- **LEFXSET** — eine Zusammenstellung von LEFX-Paketen; sie fügt kein Verhalten hinzu.

## 1. Quelle gegenüber gebautem Paket

Jedes LEFX-Paket hat eine Quelle: den Ursprung, aus dem es entsteht. Die Quelle und das gebaute Paket sind zwei verschiedene Dinge und werden in diesem Kapitel konsequent unterschieden:

- Die **Quelle** ist der Ausgangspunkt. Sie ist das, worauf sich eine explizite Quellenangabe bezieht.
- Das **gebaute Paket** ist die Verteilungseinheit, die tatsächlich eingesetzt wird. Es ist das Ergebnis des Bauens aus der Quelle.

Die Unterscheidung ist für die Identifikation unmittelbar bedeutsam: Qualifizierte IDs tragen eine explizite Quellenangabe (siehe Abschnitt 6), und die Source-ID bezeichnet die Quelle selbst (siehe Abschnitt 3). Die konkreten Buildbefehle und der Ablauf des Bauens sind dagegen nicht Gegenstand dieses Kapitels — sie folgen erst in Kapitel 10.

## 2. Anatomie eines LEFX-Pakets

Ein LEFX-Paket hat einen festen Aufbau:

- **Ein LEFX-Paket enthält genau eine Definition.** Weder mehrere noch keine — genau eine.
- Die Definition ist damit der einzige inhaltliche Kern des Pakets; das Paket ist ihre Verteilungseinheit.
- Die Definition trägt die Konfiguration. Genau hier setzt die Hauptfunktion an: **Die Werte einer Definition sind frei setzbar.** Eigene Werte können ohne Umwege gesetzt werden; darin besteht der zentrale Gebrauch des Systems.
- Vorkonfiguration ist möglich, bleibt aber Zusatz: Sie tritt hinter die freie Setzbarkeit eigener Werte zurück (siehe Abschnitt 7).

```mermaid
flowchart TD
    P["LEFX-Paket<br/>(gebaute Verteilungseinheit)"]
    P -->|"enthält genau eine"| D["Definition"]
    D -->|"trägt"| K["Konfiguration"]
    K -->|"Hauptfunktion"| W["frei setzbare eigene Werte"]
```

## 3. Source-ID

Die Source-ID bezeichnet die Quelle, aus der ein LEFX-Paket entsteht:

- Sie ordnet ein Paket eindeutig seinem Ursprung zu.
- Sie ist der Bezugspunkt für explizite Quellenangaben: Eine qualifizierte ID nennt die Quelle ausdrücklich, und die Source-ID ist die Bezeichnung dieser Quelle.
- Form und Aufbau der Source-ID werden in diesem Kapitel nicht weiter festgelegt; festgelegt ist ihre Rolle als Identifikation der Quelle.

## 4. Package-ID

Die Package-ID bezeichnet das gebaute LEFX-Paket:

- Sie identifiziert das Paket als Verteilungseinheit — das Objekt, das tatsächlich verteilt und eingesetzt wird.
- Da ein LEFX-Paket genau eine Definition enthält, besteht zwischen Paket und Definition eine Eins-zu-eins-Beziehung: Die Package-ID benennt die Verteilungseinheit, die Definition-ID benennt ihren Inhalt.
- Form und Aufbau der Package-ID werden in diesem Kapitel nicht weiter festgelegt; festgelegt ist ihre Rolle als Identifikation der Verteilungseinheit.

## 5. Definition-ID

Die Definition-ID bezeichnet die Definition, die in einem LEFX-Paket enthalten ist:

- Sie ist die ID des Inhalts, während die Package-ID die Verteilungseinheit bezeichnet.
- **Die kurze ID ist die normale Benutzerform.** Im täglichen Umgang — etwa in Steuerungskommandos oder Konfigurationen, die an eine laufende Instanz gerichtet sind — wird die kurze ID verwendet.
- Die Definition trägt die frei setzbaren eigenen Werte (siehe Abschnitt 2); die Definition-ID ist die Benutzerform, unter der diese Definition angesprochen wird.

## 6. Qualifizierte ID

Die qualifizierte ID ist die ergänzte Form einer ID:

- **Qualifizierte IDs dienen expliziten Quellenangaben und Diagnosen.**
- Sie ergänzt die kurze ID um die Angabe der Quelle. Damit wird die Herkunft einer Definition oder eines Presets ausdrücklich benannt und von gleich lautenden kurzen IDs unterscheidbar.
- Verwendung finden qualifizierte IDs hauptsächlich dort, wo die Herkunft ausdrücklich festgehalten oder ausgewählt werden muss: bei Diagnosen und bei der expliziten Quellenauswahl. Im normalen Betrieb bleibt die kurze ID die Benutzerform.

## 7. Preset-ID

Erst an dieser Stelle werden Presets eingeführt — bewusst nach der Erläuterung der freien eigenen Werte in den Abschnitten 2 und 5. Presets stehen im Hintergrund:

- **Presets sind Empfehlungen und Vorschläge.** Sie sind keine vorbereiteten Standardlösungen und kein Ersatz für die freie Konfiguration.
- Die Hauptfunktion ist und bleibt das freie Setzen eigener Werte. Ein Preset kann diese Freiheit ergänzen, aber nicht ersetzen.
- **Ein Preset enthält ausschließlich Konfiguration.** Es besteht nur aus Konfiguration; nichts, was über Konfiguration hinausginge, ist Teil eines Presets.
- Die Preset-ID bezeichnet ein solches Preset. Preset-IDs teilen mit den Definition-IDs einen global eindeutigen öffentlichen Namensraum (siehe Abschnitt 8).

Mit der Preset-ID ist der Katalog der ID-Arten vollständig. Die folgende Übersicht fasst sie zusammen:

| ID-Art | Bezeichnet | Form | Verwendung |
|---|---|---|---|
| Source-ID | die Quelle, aus der ein Paket entsteht | in diesem Kapitel nicht weiter festgelegt | Zuordnung eines Pakets zu seinem Ursprung |
| Package-ID | das gebaute LEFX-Paket als Verteilungseinheit | in diesem Kapitel nicht weiter festgelegt | Identifikation der Verteilungseinheit |
| Definition-ID | die im Paket enthaltene Definition | kurze ID (kanonische Benutzerform) | normale Benutzerform |
| qualifizierte ID | Definition oder Preset mit ausdrücklicher Quellenangabe | kurze ID, ergänzt um die Quellenangabe | explizite Quellenangaben, Diagnose, explizite Quellenauswahl |
| Preset-ID | ein Preset (Empfehlung; ausschließlich Konfiguration) | kurze ID (kanonische Benutzerform) | Identifikation einer Empfehlung |

## 8. Globale Namensräume

Die ID-Arten sind nicht gleichberechtigt über den Namensraum verteilt; die Zuordnung ist festgelegt:

- **Definition- und Preset-IDs teilen einen global eindeutigen öffentlichen Namensraum.** Sie stehen also in demselben, weltweit eindeutigen und öffentlich zugänglichen Namensraum — nicht in getrennten Räumen.
- **Global eindeutig:** Jede Definition-ID und jede Preset-ID ist eindeutig; es gibt keine doppelten Bezeichnungen.
- **Öffentlich:** Der Namensraum ist öffentlich und nicht auf eine einzelne Quelle oder einen Hersteller beschränkt.
- **Kurze Form als Benutzerform:** Innerhalb dieses Namensraums ist die kurze ID die kanonische Benutzerform.
- **Qualifizierte Form als Ergänzung:** Die qualifizierte ID erweitert die kurze ID um die Quellenangabe; sie dient hauptsächlich der Diagnose und der expliziten Quellenauswahl.

```mermaid
flowchart LR
    subgraph NS["Global eindeutiger öffentlicher Namensraum"]
        DID["Definition-ID<br/>(kurze Form, kanonische Benutzerform)"]
        PID["Preset-ID<br/>(kurze Form, kanonische Benutzerform)"]
    end
    DID -->|"ergänzt um Quellenangabe"| QID["qualifizierte ID"]
    PID -->|"ergänzt um Quellenangabe"| QID
    QID -->|"Verwendung"| V["Diagnose, explizite Quellenangabe,<br/>explizite Quellenauswahl"]
```

Die Zuordnung im Überblick:

| ID-Form | Namensraum | Eindeutigkeit | Verwendung |
|---|---|---|---|
| kurze Definition-ID | global eindeutiger öffentlicher Namensraum, geteilt mit den Preset-IDs | global eindeutig | normale Benutzerform |
| kurze Preset-ID | global eindeutiger öffentlicher Namensraum, geteilt mit den Definition-IDs | global eindeutig | Identifikation einer Empfehlung |
| qualifizierte ID | ergänzt die kurze ID um eine Quellenangabe | eindeutig über Quelle und kurze ID | explizite Quellenangaben, Diagnose, explizite Quellenauswahl |

## 9. Preset-Auflösung

Die Preset-Auflösung ist der Weg, auf dem eine Empfehlung zur Anwendung kommt:

- Ausgangspunkt ist eine Definition mit ihren frei gesetzten eigenen Werten — das ist die Hauptfunktion und der Normalzustand.
- Ein Preset tritt als Empfehlung hinzu. Da ein Preset ausschließlich Konfiguration enthält, ist die Auflösung eine reine Konfigurationsangelegenheit: Die im Preset hinterlegte Konfiguration wird im Kontext der Ziel-Definition betrachtet.
- **Eigene Werte haben Vorrang.** Wo sich die Empfehlung mit frei gesetzten eigenen Werten überschneidet, entscheiden die eigenen Werte. Ein Preset ist eine Empfehlung, keine Vorgabe; es verdrängt keine frei gesetzten Werte.
- Das Ergebnis der Auflösung ist eine frei konfigurierte Definition, in der die Empfehlung nur insoweit wirkt, wie sie nicht im Widerspruch zu eigenen Werten steht.

```mermaid
flowchart TD
    A["Definition mit frei gesetzten eigenen Werten"]
    B["Preset als Empfehlung<br/>(enthält ausschließlich Konfiguration)"]
    A --> C["Preset-Auflösung:<br/>Empfehlung wird auf die Definition angewendet"]
    B --> C
    C --> D{"Überschneidung mit eigenen Werten?"}
    D -->|"ja"| E["eigene Werte haben Vorrang"]
    D -->|"nein"| F["Empfehlung kann übernommen werden"]
    E --> G["Ergebnis: frei konfigurierte Definition"]
    F --> G
```

## 10. LEFXSET

Ein LEFXSET ist eine Zusammenstellung von LEFX-Paketen:

- **Ein LEFXSET fügt kein Verhalten hinzu.** Es gruppiert ausschließlich; alles Verhalten stammt aus den enthaltenen Definitionen.
- Jedes im Set enthaltene LEFX-Paket enthält seinerseits genau eine Definition; das Set verändert diesen Grundsatz nicht.
- Ein LEFXSET ist damit eine reine Verteilungseinheit: Es bestimmt, welche Pakete gemeinsam ausgeliefert und eingesetzt werden, ohne eigene fachliche Bedeutung zu erhalten.

```mermaid
flowchart TD
    S["LEFXSET<br/>(Zusammenstellung; fügt kein Verhalten hinzu)"]
    S --> P1["LEFX-Paket"]
    S --> P2["LEFX-Paket"]
    S --> P3["LEFX-Paket"]
    P1 --> D1["genau eine Definition"]
    P2 --> D2["genau eine Definition"]
    P3 --> D3["genau eine Definition"]
```

## 11. Thematische Paketsets

Thematische Paketsets bündeln Pakete nach Themen:

- **Sie sind kuratierte Distributionen und keine neuen fachlichen oder technischen Kategorien.** Ein thematisches Set führt keinen neuen Typ ein; es stellt lediglich eine ausgewählte, kuratierte Zusammenstellung bereits vorhandener Pakete bereit.
- Die Auswahl und Pflege eines thematischen Sets ist eine Kuratierungsaufgabe: Sie bestimmt, welche Pakete unter einem Thema gemeinsam ausgeliefert werden.
- **Die folgenden Namen sind ausschließlich Veranschaulichungen und keine festgelegten Produktnamen.** Sie deuten die jeweils gebündelte Thematik an (Kernzustände, Status-Overlays, Benachrichtigungsereignisse, Respeaker-DOA), treffen aber keine verbindliche Festlegung:

| Beispielname (Veranschaulichung) | Status |
|---|---|
| `core-states.lefxset` | Veranschaulichung; kein festgelegter Produktname |
| `status-overlays.lefxset` | Veranschaulichung; kein festgelegter Produktname |
| `notification-events.lefxset` | Veranschaulichung; kein festgelegter Produktname |
| `respeaker-doa.lefxset` | Veranschaulichung; kein festgelegter Produktname |

- Die endgültigen Namen und Inhalte der produktiven Sets werden erst bei der anschließenden Effektüberarbeitung festgelegt.

## 12. Versionen und Kompatibilität

LEFX-Pakete und LEFXSETs sind Verteilungseinheiten; für ihren Einsatz sind Versionierung und Kompatibilität zu berücksichtigen:

- Dieses Kapitel legt bewusst noch keine endgültigen Versions- oder Kompatibilitätsregeln fest. Die produktiven Set-Namen und Set-Inhalte stehen erst nach der anschließenden Effektüberarbeitung fest; aus den Beispielnamen lassen sich daher keine verbindlichen Zusagen ableiten.
- Festgelegt ist die globale Eindeutigkeit der Definition- und Preset-IDs. Diese Eindeutigkeit hält Referenzen unabhängig von Versionen eindeutig zuordenbar und trägt damit zur Kompatibilität bei.
- Die Buildbefehle und die mit dem Bau verbundenen Abläufe — und damit die Stelle, an der Versions- und Kompatibilitätsfragen konkretisiert werden — folgen erst in Kapitel 10.

## Entscheidungen zu Kapitel 8

Die im Kapitel-Entwurf als Empfehlungen formulierten Punkte werden als Festlegungen übernommen:

- **8A — Kurze IDs als kanonische Benutzerform:** Festgelegt. Die kurze ID ist die normale Benutzerform; die qualifizierte ID bleibt die Ausnahme für Diagnose und explizite Quellenauswahl.
- **8B — Globale Eindeutigkeit:** Festgelegt. Definition- und Preset-IDs bleiben global eindeutig und teilen einen gemeinsamen öffentlichen Namensraum.
- **8C — Qualifizierte IDs:** Festgelegt. Sie werden hauptsächlich für Diagnose und explizite Quellenauswahl verwendet und sind in diesem Sinne dokumentiert.
- **8D — Thematische LEFXSETs:** Festgelegt. Sie werden als kuratierte Auslieferungseinheiten behandelt, nicht als neue fachliche Typen.
- **8E — Produktive Sets:** Festgelegt. Die endgültigen Namen und Inhalte der produktiven Sets werden erst bei der anschließenden Effektüberarbeitung festgelegt; die Beispielnamen (`core-states.lefxset`, `status-overlays.lefxset`, `notification-events.lefxset`, `respeaker-doa.lefxset`) sind nur Veranschaulichungen.
- **8F — Freie eigene Werte im Vordergrund:** Festgelegt. Die Hauptfunktion ist das freie Setzen eigener Werte; Presets sind ausschließlich Empfehlungen und Vorschläge und werden unauffällig behandelt.
