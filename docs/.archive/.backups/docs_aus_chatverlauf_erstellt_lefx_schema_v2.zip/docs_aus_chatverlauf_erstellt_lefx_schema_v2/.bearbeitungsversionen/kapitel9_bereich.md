### AGENT_019

Kapitel 6 bis 8 sind mit deinen Ergänzungen festgehalten. Nun Kapitel 9 bis 11.

## Kapitel 9: Bedienung über CLI und API

**Ziel:** Ein einheitliches Bedienmodell erklären, ohne CLI und HTTP als zwei verschiedene Systeme erscheinen zu lassen.

### Gliederung

1. Steuerungskommando als gemeinsames Modell
2. Verb-zuerst-Grammatik
3. State-Kommandos
4. Overlay-Kommandos
5. Event-Kommandos
6. Aktivierungsmodus
7. Listen und Detailabfragen
8. HTTP-Entsprechungen
9. Validierungsfehler und Vorschläge

Kanonische Kommandos:

```text
set state
clear state
set overlay
update overlay
clear overlay
emit event
list
show
```

**Schwerpunkte:**

- Dokumentiert werden nur vollständige kanonische Formen.
- Tolerierte Kurzformen bleiben bewusst undokumentierte Eingabehilfe.
- Listen liefern standardmäßig kompakte IDs.
- `--details` beziehungsweise `?details=true` liefert vollständige Metadaten.
- `--json` verändert das CLI-Ausgabeformat, nicht den fachlichen Inhalt.
- API-Antworten bleiben immer JSON.
- Ungültige Eingaben verändern keine Runtime.
- Fuzzy-Treffer werden nur vorgeschlagen, niemals automatisch ausgeführt.

**Noch zu bestätigen:**

- **9A:** Aktuelles Vokabular `set`, `update`, `clear`, `emit`, `list`, `show` beibehalten? Empfehlung: Ja.
- **9B:** Ein bloßes `set` bedeutet weiterhin idempotent „einschalten“; Toggle nur explizit mit `--toggle`? Empfehlung: Ja. Das ist wiederholungs- und API-sicherer.
- **9C:** Undokumentierte eindeutige Kurzformen weiterhin akzeptieren, aber nach Annahme die kanonische Form melden? Empfehlung: Ja.
- **9D:** Beispiele zuerst als CLI zeigen und jeweils auf die identische HTTP-Operation verweisen? Empfehlung: Ja.

