# Validierungsprotokoll Kapitel 5 – Runde 1 (Einzel-Durchlauf)

**Datum:** 2026-08-02
**Geprüfte Datei:** `kapitel5_doku_runde1.md`
**Faktenquelle:** `kapitel5_bereich.md` (AGENT_017, „Kapitel 5: Schema V2")
**Gliederungsvorgabe:** `lefx_v2_doku_gesamtgliederung.md`, Kapitel 5 (16 Punkte)
**Sammel-Abgleich gegen:** `kapitel5_sammel_referenz.md` (1. Versuch)

---

## 1. Fakten-Check (streng, gegen `kapitel5_bereich.md`)

| Prüfpunkt | Erwartung (Quelle) | Befund | Ergebnis |
|---|---|---|---|
| Ziel | „Verbindliche technische Referenz für jede gültige Definition" | wörtlich im Kopfbereich und Abschnitt 1 | ✅ |
| Gliederung | 16 Punkte exakt (inkl. „Bedingte Pflichtfelder") | Abschnitte 1–16 exakt 1:1 | ✅ |
| Felder-Referenztabelle | `id` verpflichtend/global eindeutig · `overlay_mode` bedingt/nur Overlays · `runtime_input_schema` bedingt/nur kontrollierte Overlays · `input_sampling` bedingt/nur bei Runtime-Eingaben · `tags` optional/Suche und Katalogisierung | wörtlich übernommen + Kennzeichnungs-Spalte (keine neuen Felder) | ✅ |
| Separate Invariantenlisten | für State, kontrolliertes Overlay, zeitgesteuertes Overlay, Event | Abschnitt 14 als Tabelle je Kategorie | ✅ |
| Schwerpunkt: keine riesigen JSON-Ausgaben | kleine kanonische Ausschnitte | durchgängig (minimale JSON-Blöcke) | ✅ |
| Schwerpunkt: vollständige Beispiele | bleiben in `effect-development` | Abschnitte 5, 16 + Verweise | ✅ |
| Schwerpunkt: strikte Abweisung | unbekannte Felder + ungültige Kombinationen | Abschnitte 1, 2, 8, 10, 11, 15 | ✅ |
| Schwerpunkt: Überführung | `planning/lefx_schema_v2.md` → Referenz, Archivhinweis am alten Ort | Abschnitt 16 + Archivhinweis-Block | ✅ |
| Entscheidungen 5A–5D | als Festlegungen (Sprache, Umfang, Kennzeichnung, Überführung) | „Entscheidungen zu Kapitel 5" als Tabelle | ✅ |
| Kennzeichnung | `Verpflichtend` / `Bedingt` / `Optional` / `Empfehlung` sichtbar | durchgängig + Bedeutungstabelle im Kopf | ✅ |

### Ableitbare Präzisierungen (kein Rücksendegrund)
1. **Abschnitte 5, 7–11 (Konfiguration, Defaults, Capabilities, Layer, Farbmodell, Animation):** Die Quelle nennt diese Gliederungspunkte, legt aber keine Detailfelder fest. Die Fassung behandelt sie konservativ als Referenzumfang mit Regel-Kennzeichnung und verweist für Details auf `effect-development` — nichts erfunden.
2. **Kennzeichnungs-Spalte in der Felder-Referenztabelle:** Ergänzt die Status-Spalte der Quelle ohne neue Felder — direkte Umsetzung der Festlegung 5C.
3. **Kanonische JSON-Ausschnitte** (z. B. `{"id": "example:minimal"}`) sind als Veranschaulichung gekennzeichnet; `example:`-IDs sind erkennbar illustrativ.
4. **Kopfhinweis nennt Kapitel 4 als freigegeben:** Entspricht der Task-Vorgabe; Kapitel 4 wird in der parallelen Validierung (siehe `kapitel4_validierung_runde1_einzeln.md`) ebenfalls freigegeben — der Hinweis ist damit gedeckt.

### Redaktionelle Korrektur (transparent dokumentiert)
Keine erforderlich.

---

## 2. Sammel-Abgleich (gegen `kapitel5_sammel_referenz.md`, 1. Versuch)

| Kernaussage der Sammel-Referenz | In neuer Fassung | Ergebnis |
|---|---|---|
| Ziel identisch | ✅ | ✅ |
| Gliederung 16 Punkte identisch | ✅ | ✅ |
| Felder-Referenztabelle wörtlich identisch | ✅ (+ Kennzeichnung) | ✅ |
| `overlay_mode` nur `controlled`/`timed`; Push/Pull keine Moduswerte | ✅ (Abschnitte 4, 12) | ✅ |
| Bedingte Pflichtfelder (Tabelle + strikte Abweisung außerhalb der Bedingung) | ✅ (Abschnitt 13) | ✅ |
| Übergreifende Invarianten: unbekannte Felder/ungültige Kombinationen abweisen, Typen unveränderlich, Einsatzzwecke als Orientierung | ✅ (Abschnitt 14) | ✅ |
| Ungültige Kombinationen je Typ (State, kontrolliertes Overlay, zeitgesteuertes Overlay, Event) | ✅ (Abschnitte 14/15 als Invariantenlisten + Kombinationstabelle) | ✅ |
| Verweis auf `effect-development` + Überführung `planning/lefx_schema_v2.md` | ✅ (Abschnitt 16) | ✅ |
| Entscheidungen 1–4 (Sprache, Umfang, Kennzeichnung, Überführung) | ✅ (5A–5D) | ✅ |
| **Abweichung:** Layer-Platzierungstabelle mit Enum-Namen (`STATE_LAYER`, `ONGOING_OVERLAY_LAYER`, `TEMP_OVERLAY_LAYER`, `EVENT_LAYER`) | Neue Fassung führt keine Enum-Namen in Kapitel 5 | ⚠️ **bewusst quellentreu**: Die Enum-Namen stammen aus dem AGENT_017-Abschnitt „Kapitel 4: Lifecycle und Layer" (= heute Kapitel 3), NICHT aus der Faktenquelle von Kapitel 5; die neue Fassung übernimmt keine Fakten aus fremden Kapitel-Bereichen. Die Layer-Platzierung wird in Kapitel 3 (Layer und Komposition) geführt; Kapitel 5 verweist auf die Invarianten. |

**Sammel-Abgleich: BESTANDEN ✅** (die einzige Abweichung ist eine bewusste Quellentreue-Verbesserung: keine Faktenübernahme aus anderen Kapitel-Bereichen)

---

## 3. Qualitäts-Check

| Kriterium | Befund |
|---|---|
| Gliederungstreue | Exakt 16 Punkte + „Entscheidungen zu Kapitel 5" (4 Festlegungen als Tabelle) |
| Mermaid-Diagramme | 2 (Struktur einer `EffectDefinition`, Abhängigkeiten der bedingten Felder) — ≥ 2 gefordert ✅ |
| Tabellen | 6 (Kennzeichnungen, Felder-Referenz, `overlay_mode`-Werte, bedingte Pflichtfelder, Invarianten je Typ, ungültige Kombinationen) |
| Begriffe | „Definition", „`EffectDefinition`", „Schema", „Feld", „Overlay-Modus", „Invariante" durchgängig; Feld-/Enum-Namen englisch, Erklärtext deutsch; „Effekt" nur in „Effektquellen" |
| Stil | Kein Dialog, keine „Ich"-Formulierungen, Regeln sichtbar gekennzeichnet |

**Qualitäts-Check: BESTANDEN ✅**

---

## 4. Entscheidung

**Kapitel 5 ist VALIDIERT ✅ in Runde 1 (Einzel-Durchlauf)**

- Fakten-Check bestanden (Ziel wörtlich, 16 Gliederungspunkte exakt, Felder-Referenztabelle wörtlich, alle Schwerpunkte, 5A–5D als Festlegungen)
- Sammel-Abgleich bestanden (eine dokumentierte, quellentreue Verbesserung)
- Qualitäts-Check bestanden (2 Diagramme, 6 Tabellen)
- 4 ableitbare Präzisierungen, keine redaktionellen Korrekturen nötig
- `kapitel5_doku_runde1.md` wird als finale Fassung übernommen (`kapitel5_doku_final.md`); die alte Fassung des 1. Versuchs bleibt als `kapitel5_doku_final_alt.md` erhalten

*Keine Runde 2 erforderlich.*
