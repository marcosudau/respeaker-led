# Sonderkapitel I: DOA (Direction of Arrival)

**Projekt:** LED-Controller (LEFX Schema V2)
**Gerät:** ReSpeaker XVF3800
**Faktenquelle:** Projekt-Chat Turns 26–32 (Z. 3151–3555) — ausschließlich Chat-Fakten, keine Online-Recherche, keine externen Quellen (bewusster Vergleichsaufbau)
**Variante:** Normal (Ablauf wie Kapitel 1–12)
**Status:** Dokumentation, nichts committet/gepusht

## Ziel

Dokumentation der Richtungserkennung (DOA) des ReSpeaker XVF3800 im LED-Controller: Messwerte, Verhalten des DOA-Effekts, Ursachenanalyse des „Festhängens" und Korrekturmaßnahmen, wie sie im Projekt-Chat (Turns 26–32) erarbeitet wurden.

---

## 1. Anlass und Problemstellung

Beim Setzen des DOA-Effekts trat ein Fehler auf: Der Effekt „steht immer nur auf einer Richtung" und bewegt sich nicht, während andere Effekte funktionieren.

| Aspekt | Beobachtung |
|---|---|
| Fehlerbild | Beim Setzen des DOA-Effekts tritt ein Fehler auf |
| Symptom | Effekt „steht immer nur auf einer Richtung", bewegt sich nicht |
| Abgrenzung | Andere Effekte funktionieren |
| Vorgehen | Temporäres Debug-Logging (Turn 26), Service-Cleanup (Turn 27), Abtast- und USB-Analyse (Turns 28–29), Wertegrundlage (Turns 30–32), Korrekturmaßnahmen (Turn 32) |

Damit die Ursache eingegrenzt werden kann, wurde der DOA-Wertepfad vollständig dokumentiert: Parameter, Messwerte, Abtastung, USB-Verhalten und die Wertegrundlage des internen Vergleichseffekts.

### 1.1 Randbedingungen der Analyse: Service-Cleanup (Turn 27)

Vor der weiteren Analyse wurde ein verwaister Service-Prozess beendet (Log endete 23:15:57; Ports 8765–8770 danach frei). Der Studio-Prozess beendet den Service-Prozessbaum bei abruptem Schließen automatisch über ein Windows-Jobobjekt; zusätzlich existieren `closeEvent`, `aboutToQuit` und `finally`-Cleanup. Der Abbruchtest wurde bestanden (der Service überlebt `os._exit()` nicht). Teststand zu diesem Zeitpunkt: 167 Tests; die temporären DOA-Wertausgaben bleiben aktiv.

---

## 2. Der DOA-Effekt und seine Messwerte

### 2.1 Parameterübersicht (Parameteransicht)

| Parameter | Adresse | Größe | Zugriff | Typ | Beschreibung |
|---|---|---|---|---|---|
| `DOA_VALUE` | (20, 18) | 2 | ro | `uint16` | Get the doa value and if speech is detected, payload[0] = doa value, from 0 to 359, payload[1] = 1 if speech is detected, 0 if not |
| `LED_RING_COLOR` | (20, 19) | 12 | rw | `uint32` | Set the LED color of ring mode, each value is the color of one LED |

- `DOA_VALUE` liefert zwei `uint16`-Werte: `payload[0]` = DOA-Winkel (0–359), `payload[1]` = Aktivitäts-Flag (1 = Sprache erkannt, 0 = nicht).
- `LED_RING_COLOR` enthält 12 Farbwerte (`uint32`), einen je LED.

### 2.2 Temporäre DOA-Protokollierung

Zum Debugging wurde eine temporäre DOA-Protokollierung eingebaut. Pro Abfrage wird z. B. geschrieben:

```text
DOA DEBUG sample payload=(135, 1) direction_deg=135.0 speech_flag=1 forwarded_state=sound
```

- Protokolliert werden der Roh-Payload, der daraus abgeleitete Winkel (`direction_deg`), das Speech-Flag (`speech_flag`) und der weitergeleitete Zustand (`forwarded_state`).
- Auch ungültige Payloads/Winkel werden protokolliert.
- Das Speech-Flag wird in dieser Phase nur angezeigt, aber **weiterhin nicht ausgewertet**.
- Verifikation: 166 bestandene Tests (Turn 26); nichts committet oder gepusht.

### 2.3 Kennzeichnungen

| Kennzeichnung | Bedeutung |
|---|---|
| `payload[0]` | DOA-Winkel, 0–359 |
| `payload[1]` | VAD-Flag: 1 = Sprache/Aktivität erkannt, 0 = keine |
| `detection_state: "sound"` | an den Effekt weitergegebenes Aktivitätssignal |
| `LED_EFFECT = 4` | interner DOA-Modus |
| `LED_EFFECT = 5` | frei gesetzter Ringmodus |
| Base color `#002040` | Grundfarbe des internen DOA-Rings |
| Highlight `#00C066` | Hervorhebungsfarbe der erkannten Richtung |

---

## 3. Ursachenanalyse des Festhängens

Die Analyse ergab mehrere zusammenwirkende Ursachen:

| # | Ursache | Beschreibung | Beitrag |
|---|---|---|---|
| U1 | VAD-Flag ignoriert, `detection_state` immer `"sound"` | `payload[1]` wurde vollständig ignoriert; der Effekt bekam immer `"detection_state": "sound"` | Hauptursache: zuletzt gemessener Winkel bleibt dauerhaft sichtbar → wirkt wie Festhängen |
| U2 | 12 LEDs → 30° pro LED | Winkeländerungen wie 81°→88°→95° können weiterhin dieselbe LED wählen | Erklärt einen erheblichen Teil der wahrgenommenen Schwerfälligkeit: Effekt sieht festgefahren aus, obwohl sich der DOA-Wert laufend ändert |
| U3 | `DOA_VALUE[0]` behält die letzte Richtung | Wenn kein relevantes Geräusch aktiv ist, behält `payload[0]` offenbar einfach die zuletzt erkannte Richtung | Verstärkt den Festhänge-Eindruck in ruhigen Phasen |
| U4 | Niedrige Abtastrate | `interval_ms=125` → real etwa 7–8 Abfragen pro Sekunde | Bewegung wirkt träge |

```mermaid
flowchart LR
    A[VAD-Flag nicht ausgewertet] --> B[detection_state immer sound]
    B --> C[Letzter Winkel bleibt dauerhaft sichtbar]
    D[12 LEDs / 30 Grad pro LED] --> E[Kleine Winkeländerungen wählen dieselbe LED]
    C --> F[Effekt wirkt festgefahren]
    E --> F
    G[DOA_VALUE behält letzte Richtung ohne Geräusch] --> F
    H[Niedrige Abtastrate 7-8 Hz] --> F
```

### 3.1 Bewertung

- U1 ist die sehr wahrscheinliche Hauptursache des Festhänge-Eindrucks.
- U2 erklärt einen erheblichen Teil der wahrgenommenen Schwerfälligkeit: 360°/12 LEDs = 30° pro LED.
- Ein physischer Hardwaredefekt ist sehr unwahrscheinlich: `DOA_VALUE` liest nur einen flüchtigen Laufzeitwert, `LED_RING_COLOR` schreibt den aktuellen LED-Puffer; es findet kein Flash-Schreiben statt → kein relevanter Speicher-Verschleiß.

---

## 4. Abtastrate, Renderloop und USB-Grenzen

### 4.1 Renderloop und Abtastraten

Der Renderloop läuft mit **30 FPS**, ein Durchlauf etwa alle **33 ms**.

| Konfiguration | Erwartete Rate | Anmerkung |
|---|---|---|
| `interval_ms=125` (aktuell) | real etwa 7–8 Abfragen/s | Ausgangslage |
| `interval_ms=50` | praktisch ~15 Hz | Prüfung nur alle 33 ms |
| `interval_ms=0` | maximal ~30 Hz | eine Abfrage pro Frame |

- Pull-Abfragen sind an Renderframes gekoppelt → beliebige Zwischenraten sind nicht exakt möglich.

### 4.2 USB-Grenzen

- 30 LED-Schreibvorgänge + 30 DOA-Lesevorgänge = ~60 USB-Control-Transfers/s (praktische Grenze).
- Die Datenmenge ist winzig (~1,4 KB/s bei 30 FPS) und unkritisch; relevant sind die **Anzahl** der USB-Control-Transfers und die Firmware-Verarbeitungszeit.
- Kritischer sind die ReSpeaker-Verarbeitung, USB-Latenzen und die serielle Ausführung im Renderthread.
- Der Treiber hat einen sehr großzügigen Timeout und bis zu 100 Wiederholungsversuche → ein problematischer Transfer kann den Renderloop länger blockieren.
- Der Treiber wiederholt Firmware-`RETRY` bis zu 100-mal; alles läuft synchron → der Controller bleibt stehen, statt Anfragen aufzustauen.

**Folgen zu hoher Rate:**

| Folge | Beschreibung |
|---|---|
| FPS-Einbruch | Der Service erreicht die Renderfrequenz nicht mehr |
| Ruckeln | LED-Animationen ruckeln |
| USB-Fehler | Transfers liefern Retry, Timeout oder Stall |
| ReSpeaker unerreichbar | ReSpeaker reagiert zeitweise nicht, evtl. USB-Neuverbindung nötig |
| Renderthread blockiert | Im ungünstigsten Fall blockiert der Renderthread länger |

### 4.3 `LED_RING_COLOR`: ein Transfer für alle LEDs

- `LED_RING_COLOR` ist **ein** USB-Transfer mit zwingend allen 12 Farben: `12 × uint32 = 48 Byte`.
- Es gibt keine Möglichkeit, nur einzelne LEDs zu aktualisieren.

### 4.4 Frame-Diff-Optimierung

```python
if frame.leds == previous_leds:
    return
device.write("LED_RING_COLOR", frame.leds)
previous_leds = list(frame.leds)
```

| Szenario | Wirkung |
|---|---|
| Statischer Ring | Nach dem ersten Frame keine weiteren LED-Transfers |
| Langsame quantisierte Animation | Identische Zwischenframes werden übersprungen |
| Flüssige Animation | Weiterhin bis zu 30 Transfers/s |

- Im aktuellen Test dreht sich der darunterliegende State weiter; die Engine rechnet erst alle Layer zusammen und sendet dann den vollständigen Endframe → die Optimierung spart dort nur wenig.
- Empfehlung aus Turn 29: identische Gesamtframes nicht erneut übertragen; DOA mit 50 ms; Lesen/Schreiben seriell; USB-Laufzeiten und Fehler protokollieren; interpolieren.

---

## 5. Wertegrundlage und Vergleich mit dem internen Effekt

### 5.1 Der originale Door-Effekt als Referenz

- Der originale Door-Effekt (im ReSpeaker gespeichert) funktioniert gut: „da ist Bewegung drin"; Anzeige nur während Geräuschen.
- Wanduhr-Beispiel: Der Sekundenzeiger lässt die LED einmal pro Sekunde kurz aufblinken.
- Es ist **nicht exakt dieselbe Wertegrundlage**: Der interne ReSpeaker-DOA-Modus arbeitet direkt innerhalb der Firmware.

### 5.2 Wertegrundlage des internen Effekts

- Laut offizieller Dokumentation verwendet die eingebaute DOA-Anzeige den **vierten Wert von `AEC_AZIMUTH_VALUES`, also den Auto-selected beam**.
- `AEC_SPENERGY_VALUES`: dessen **vierter Wert** beschreibt die Speech-Energie des Auto-selected beam. Wert über null = erkannte Aktivität; höhere Werte ≈ lauteres/näheres Signal. Passt zur Wanduhr-Beobachtung.

| Wert | Bedeutung |
|---|---|
| `AEC_AZIMUTH_VALUES[3]` | genauer Winkel des ausgewählten (Auto-selected) Beams |
| `AEC_SPENERGY_VALUES[3]` | Speech-Energie dieses Beams (über null = erkannte Aktivität) |
| `DOA_VALUE[0]` | vereinfachter Winkel für Anwendungen (0–359) |
| `DOA_VALUE[1]` | vereinfachtes VAD-Flag (1 = Aktivität, 0 = keine) |

### 5.3 Vorteile des internen Effekts

- Direkter Zugriff auf interne DSP-/Beamforming-Werte
- Keine USB-Abtastverzögerung
- Vermutlich Aktualisierung mit dem internen Audiotakt
- Zugriff auf den Auto-selected beam
- Aktivitätsinformationen über die Beam-Energie
- Anzeige nur während erkannter Aktivität

### 5.4 Verhalten des internen Effekts

Arbeitsweise: kurzes Geräusch erkannt → Auto-selected beam bestimmt Richtung → LED an dieser Richtung kurz einschalten → bei fehlender Energie wieder ausblenden.

```mermaid
flowchart TD
    S[Kurzes Geräusch erkannt] --> B[Auto-selected beam bestimmt Richtung]
    B --> L[LED an dieser Richtung kurz einschalten]
    L --> E{Energie weiterhin vorhanden?}
    E -- ja --> L
    E -- nein --> F[LED wieder ausblenden]
    F --> W[Warten auf nächste Aktivität]
    W --> S
```

### 5.5 Einordnung von `DOA_VALUE`

- `DOA_VALUE` kann intern durchaus aus demselben Beamforming-System abgeleitet sein; die Dokumentation garantiert aber nicht, dass es exakt derselbe Wert mit demselben Aktualisierungs-/Aktivitätsverhalten ist.
- Dokumentiert ist ausdrücklich der Auto-selected beam als Grundlage der internen LED-Anzeige.
- `DOA_VALUE` ist die praktische, zusammengefasste Schnittstelle für Anwendungen; ein sofortiger Wechsel auf die ausführlichen AEC-Wertesätze ist nicht zwingend.

### 5.6 `DOA_VALUE` entschlüsselt (Turn 32)

- Parameteransicht der ReSpeaker-App: `DOA_VALUE — uint16 x2 — DoA value [0..359] and VAD flag`.
- Der zweite Wert ist **kein** Ergebnis einer Spracherkennung (Speech-to-Text), sondern ein **VAD-Flag: Voice Activity Detection**.
- Ausgangslage der Implementierung: `payload[0]` → Winkel, `payload[1]` → ignorieren, `detection_state` → immer `"sound"`.
- Wenn kein relevantes Geräusch aktiv ist, behält `payload[0]` offenbar einfach die zuletzt erkannte Richtung.
- Interner Effekt vermutlich: VAD = 1 → Richtung anzeigen; VAD = 0 → Richtungsanzeige ausblenden.

### 5.7 Monitorwerte (Screenshot)

| Monitorwert | Messwert |
|---|---|
| Direction of arrival | 266° |
| Voice activity | Active |
| Max beam energy | 26426.47 |
| Beam 1 | 26426.47 |
| Beam 3 | 26426.47 |

- Beam 3 = laut offizieller Dokumentation der Auto-selected beam.
- Beam 1 = Beam 3 (gleicher Energiewert) bedeutet vermutlich: Beam 1 wurde aktuell als bester Beam ausgewählt und auf Beam 3 durchgereicht. Die interne DOA-Anzeige verwendet genau diesen Auto-selected beam.

### 5.8 LED-Effekt-Konfiguration des internen Effekts

- `LED_EFFECT = 4` → interner DOA-Modus; `LED_EFFECT = 5` → frei gesetzter Ringmodus.
- `LED_DOA_COLOR` → Grundfarbe und Highlight-Farbe: Base color `#002040`, Highlight `#00C066` → Grundring + bei VAD-Aktivität hervorgehobene Richtung.
- `LED_SPEED` ist laut Protokolldokumentation primär für Breath und Rainbow gedacht; Wert `8` ist daher wahrscheinlich **nicht** die Reaktionsgeschwindigkeit der DOA-Auswertung.

### 5.9 Audioeinstellungen

- Noise Suppression, AGC, Echo Suppression, Double-talk Sensitivity können beeinflussen, was der DSP als Aktivität oder guten Beam bewertet.
- Vorerst nicht verändern; insbesondere nicht auf **Save to Flash** klicken.
- `AEC converged: No` ist allein kein DOA-Fehler (betrifft primär Echo-Unterdrückung und Far-End-Referenz).

### 5.10 Datenfluss DOA-Erkennung → Effekt (extern vs. intern)

```mermaid
flowchart TB
    subgraph FW[ReSpeaker-Firmware]
        DSP[Beamforming / DSP] --> AB[Auto-selected beam]
        AB --> A1[AEC_AZIMUTH_VALUES[3] - genauer Winkel]
        AB --> S1[AEC_SPENERGY_VALUES[3] - Speech-Energie]
        AB --> D0[DOA_VALUE[0] - vereinfachter Winkel 0-359]
        AB --> D1[DOA_VALUE[1] - VAD-Flag]
        A1 --> INT[Interne DOA-Anzeige - LED_EFFECT = 4]
        S1 --> INT
    end
    subgraph LEDC[LED-Controller]
        D0 --> EXT[Externer DOA-Effekt - detection_state]
        D1 --> EXT
        EXT --> RING[LED_RING_COLOR - 48 Byte]
    end
```

### 5.11 Vergleich externer vs. interner Effekt

| Kriterium | Interner Effekt | Externer Effekt (`DOA_VALUE`) |
|---|---|---|
| Wertegrundlage | Auto-selected beam (`AEC_AZIMUTH_VALUES[3]` + `AEC_SPENERGY_VALUES[3]`) | vereinfachte Schnittstelle (`DOA_VALUE[0]` Winkel, `DOA_VALUE[1]` VAD) |
| Zugriff | direkt auf DSP-/Beamforming-Werte | über USB-Abfrage |
| Aktualisierung | vermutlich interner Audiotakt | an Renderframes gekoppelt (max. ~30 Hz) |
| Abtastverzögerung | keine | USB-Abtastverzögerung |
| Aktivität | über Beam-Energie | über VAD-Flag (in der Ausgangslage ignoriert) |
| Verhalten | Anzeige nur während erkannter Aktivität | dauerhafte Anzeige des letzten Winkels (Ausgangslage) |

---

## 6. Korrekturmaßnahmen

### 6.1 Ziel-Einstellungen

| Ziel | Wert |
|---|---|
| Renderfrequenz | 30 Hz |
| DOA-Abfrage | einmal pro Renderframe |
| Max. DOA-Reads | 30/s |
| LED-Ausgabe | nur bei verändertem Gesamtframe |
| Provider-Cache | ein Messwert pro Frame für alle DOA-Effekte |

### 6.2 Regeln: Drei Bedingungen für 30 Hz (Turn 31)

1. **Kein Parallelzugriff:** ReSpeaker Console und LED-Controller dürfen nicht gleichzeitig zugreifen — solche parallelen Prozesse hatten bereits `USBError: Entity not found`-Fehler verursacht.
2. **Eine Hardwareabfrage pro Frame:** Theoretisch könnte jedes aktive Pull-Overlay seinen Provider separat aufrufen (bei mehreren DOA-Overlays: 60–90 USB-Abfragen). Der Provider soll zentral pro Renderframe cachen und allen Effekten denselben Messwert liefern.
3. **Serielles Lesen/Schreiben:** DOA-Lesen und LED-Schreiben seriell lassen — keine konkurrierenden USB-Threads, keine unkontrollierte Warteschlange.

### 6.3 Konkrete Korrektur (nächste Implementierungsschritte, Turn 32)

| Nr. | Maßnahme | Beschreibung |
|---|---|---|
| 1 | DOA einmal pro Renderframe abfragen | bei 30 FPS max. 30 Hz |
| 2 | VAD-Flag auswerten | `0` → `detection_state="none"`, `1` → `detection_state="sound"` |
| 3 | Ohne VAD ausblenden | Richtungsanzeige transparent machen |
| 4 | Kurze Haltezeit optional anbieten | ~70–150 ms |
| 5 | Providerwerte cachen | einmal pro Frame, auch bei mehreren DOA-Effekten |
| 6 | Frame-Diff | identische LED-Gesamtframes nicht erneut übertragen |
| 7 | AEC-Werte diagnostisch vergleichen | `AEC_AZIMUTH_VALUES` und `AEC_SPENERGY_VALUES` zunächst nur zusätzlich |

### 6.4 Ziel-Datenfluss

```mermaid
flowchart TD
    RL[Renderloop - 30 FPS] --> Q[DOA-Abfrage einmal pro Frame - max. 30 Hz]
    Q --> C[Provider-Cache - ein Messwert pro Frame]
    C --> E[DOA-Effekt]
    E --> V{VAD-Flag}
    V -- 0 --> N[detection_state = none - Richtung transparent]
    V -- 1 --> S[detection_state = sound - Richtung mit Haltezeit ~70-150 ms]
    N --> M[Layer-Mix zum Gesamtframe]
    S --> M
    M --> FD{Frame identisch?}
    FD -- ja --> RL
    FD -- nein --> W[device.write LED_RING_COLOR]
    W --> RL
```

### 6.5 Festlegungen (Entscheidungen A1–A5)

| Kennung | Entscheidung | Festlegung |
|---|---|---|
| A1 | DOA-Abfrage einmal pro Renderframe (max. 30 Hz), VAD-Flag auswerten (`0` → `none`, `1` → `sound`), ohne VAD transparent? | **Ja** — wird umgesetzt |
| A2 | Kurze Haltezeit (~70–150 ms) optional anbieten? | **Ja** — wird umgesetzt |
| A3 | Providerwerte einmal pro Frame cachen, identische LED-Gesamtframes nicht erneut übertragen? | **Ja** — wird umgesetzt |
| A4 | `AEC_AZIMUTH_VALUES`/`AEC_SPENERGY_VALUES` zunächst nur diagnostisch vergleichen, `DOA_VALUE` als primäre Schnittstelle behalten? | **Ja** — wird umgesetzt |
| A5 | Audioeinstellungen unverändert lassen und nicht auf „Save to Flash" klicken? | **Ja** — wird eingehalten |

### 6.6 Begründung der 30-Hz-Entscheidung

- In der offiziellen ReSpeaker-App kann man bis 30 Hz Live-Telemetrie auswählen → starkes Indiz, dass der ReSpeaker regelmäßige Telemetrieabfragen mit 30 Hz verträgt. Die App liest gleichzeitig DOA, Voice Activity und Beam-Energien.
- Die Konsole überwacht bei 30 Hz gleichzeitig DOA, VAD, vier Beam-Energien, RT60 und AEC-Status → bestätigt 30-Hz-Telemetrie mit Firmware **2.0.10**.
- 30 DOA-Abfragen/s sind grundsätzlich plausibel und geräteseitig vorgesehen; keine Beschädigung zu erwarten; schlimmstenfalls verzögerte Frames, USB-Retries oder vorübergehend hängender Service.
- Die offizielle App verwendet neben der Richtung ausdrücklich Voice Activity und Beam Energy → Aktivität und Richtung müssen gemeinsam ausgewertet werden.
- Turn 28 schlug testweise 50 ms (~15 Hz) vor; als Ziel-Einstellung gilt nun 30 Hz mit den drei Bedingungen aus Abschnitt 6.2.

---

## 7. Offene Punkte

| # | Offener Punkt | Stand / Anmerkung |
|---|---|---|
| O1 | Interpolation zwischen benachbarten LEDs | Vorschlag aus Turns 28/29 (Richtungsindikator zwischen zwei benachbarten LEDs interpolieren, je näher an der nächsten LED, desto heller); nicht Teil der Korrekturliste aus Turn 32 — Umsetzung offen |
| O2 | Exakte Haltezeit | Turn 30: ~100–200 ms; Turn 32: ~70–150 ms — Endwert in der Praxis festzulegen |
| O3 | AEC-Wertesätze als Ziel-Provider | Festlegung A4: zunächst nur diagnostisch vergleichen, `DOA_VALUE` als primäre Schnittstelle behalten; ein späterer Wechsel auf `AEC_AZIMUTH_VALUES[3]`/`AEC_SPENERGY_VALUES[3]` bleibt offen |
| O4 | USB-Laufzeit-/Fehler-Protokollierung | Vorschlag aus Turns 28/29 (USB-Lesedauer, Alter des letzten Winkels, USB-Laufzeiten und Fehler) — als Diagnosewerkzeug vorgesehen |
| O5 | Parallelzugriff ReSpeaker Console | Bedingung 1 (kein gleichzeitiger Zugriff) ist Betriebsregel; Verhalten bei versehentlichem Parallelzugriff weiter beobachten (`USBError: Entity not found`) |
| O6 | Audioeinstellungen | Noise Suppression, AGC, Echo Suppression, Double-talk Sensitivity bewusst unverändert (A5); tatsächlicher Einfluss auf die DOA-Bewertung des DSP bleibt offen |
| O7 | `AEC converged: No` | Betrifft primär Echo-Unterdrückung und Far-End-Referenz; allein kein DOA-Fehler — weitere Einordnung offen |
| O8 | `LED_SPEED` und DOA | Laut Dokumentation primär für Breath und Rainbow gedacht; Bedeutung des Werts `8` für die DOA-Auswertung nicht geklärt |
| O9 | 30-Hz-Validierung | Der Zwischenschritt-Vorschlag 50 ms (~15 Hz, Turn 28) ist durch die Ziel-Einstellung 30 Hz (Turns 31/32) abgelöst; praktische Stabilität von 30 Hz unter den drei Bedingungen noch zu validieren |
