# Validierung Schritt 2 — Sonderkapitel I: DOA (Direction of Arrival)

**Geprüfte Datei:** `sonderkapitel_doa_doku_runde1.md` (520 Zeilen)
**Referenz:** `sonderkapitel_doa_bereich.md` (Faktenbasis, 28 KB)
**Prüfer:** Haupt-Assistent (Schritt 2 der 3-stufigen Validierung, gleiche Vorgaben wie Schritt 1)
**Datum:** 2026-08-02
**Vorgabe:** Strenge Detailprüfung Zeile für Zeile; keine Erfindungen; jede Aussage in der Faktenbasis belegbar.

---

## 1. Ergebnis

**Urteil: BESTANDEN** ✅ — Die Doku ist für Schritt 3 (Marco) bereit.

- Kritisch: **0**
- Mittel: **0**
- Minor: **7** (davon 6 identisch mit Schritt 1, 1 zusätzlicher eigener Fund — siehe unten)

---

## 2. Vollständigkeitsprüfung

### 2.1 Pflicht-Werte (Teil C.1 der Faktenbasis, 20/20 vorhanden und erklärt)

| # | Wert | In Doku | Korrekt erklärt? |
|---|---|---|---|
| 1 | `DOA_VALUE[0]` (0–359) | §4.1, §4.2, §7.1 | ✅ Winkel, 0–359 |
| 2 | `DOA_VALUE[1]` (VAD-Flag) | §4.2, §7.1 | ✅ 1=Sprache, 0=keine; kein Speech-to-Text |
| 3 | `AEC_AZIMUTH_VALUES[0..2]` (Focused 1/2, Free running) | §3.1 | ✅ Radians, Reihenfolge korrekt |
| 4 | `AEC_AZIMUTH_VALUES[3]` (Auto selected beam) | §3.1, §3.3 | ✅ Grundlage der internen DOA-Anzeige |
| 5 | `AEC_SPENERGY_VALUES[0..2]` | §3.2 | ✅ Reihenfolge identisch |
| 6 | `AEC_SPENERGY_VALUES[3]` | §3.2 | ✅ >0 = Aktivität, höher = lauter/näher |
| 7 | `LED_RING_COLOR` (12×uint32 = 48 B) | §6.1, §6.2 | ✅ ein Transfer, alle 12 LEDs |
| 8 | `LED_EFFECT` (0–4; 5 nur Chat) | §6.2, §10.1 | ✅ 5 korrekt als Chat-Beobachtung gekennzeichnet |
| 9 | `LED_DOA_COLOR` (Base+Highlight) | §6.1, §6.2 | ✅ #002040 / #00C066 |
| 10 | `LED_SPEED` (breath/rainbow) | §6.1, §6.2 | ✅ nicht DOA-Reaktionszeit |
| 11 | `LED_BRIGHTNESS` | §6.1 | ✅ breath/rainbow |
| 12 | `LED_GAMMIFY` | §6.1 | ✅ 0/1 |
| 13 | `LED_COLOR` | §6.1 | ✅ breath/single color |
| 14 | `AUDIO_MGR_SELECTED_AZIMUTHS[0]` (NAN) | §5.1 | ✅ NAN = keine Sprache |
| 15 | `AUDIO_MGR_SELECTED_AZIMUTHS[1]` | §5.1 | ✅ Azimut Auto-select-Beam |
| 16 | `detection_state` | §5.4 | ✅ "sound"/"none"; Ignorieren als Fehlerursache |
| 17 | `interval_ms` (125→7–8 Hz, 50→~15 Hz, 0→max 30 Hz) | §7.6, §8.1 | ✅ alle drei Werte korrekt |
| 18 | Renderfrequenz 30 FPS | §7.6, §8.1 | ✅ ~33 ms |
| 19 | Beam-Energien (Monitor) | §5.2 | ✅ 26426.47, Beam 1 = Beam 3 |
| 20 | RT60 / AEC-Status | §5.3 | ✅ `AEC converged: No` ≠ DOA-Fehler |

### 2.2 Kombinationen (Teil C.2, 12/12 vorhanden und bewertet)

| Nr. | Kombination | Abschnitt | Bewertung deckungsgleich? |
|---|---|---|---|
| 1 | `DOA_VALUE[0]` + `DOA_VALUE[1]` | §7.1 | ✅ Festhänge-Ursache, VAD auswerten |
| 2 | `AEC_AZIMUTH_VALUES[3]` + `AEC_SPENERGY_VALUES[3]` | §7.2 | ✅ Zielkombination, Haltezeit 100–200 ms |
| 3 | Beam 1 = Beam 3 | §7.3 | ✅ durchgereicht, Audio-Mux [Q2] stützt |
| 4 | `DOA_VALUE` vs. `AEC_*` | §7.4 | ✅ erst DOA_VALUE, AEC diagnostisch |
| 5 | 12-LED-Quantisierung | §7.5 | ✅ 30°/LED, Interpolation |
| 6 | Abtastrate + Renderloop | §7.6 | ✅ Pull-Kopplung, 50 ms ≈ 15 Hz |
| 7 | USB-Gesamtlast | §7.7 | ✅ ~60 Transfers/s, seriell |
| 8 | Frame-Diff + Layer | §7.8 | ✅ nur geänderte Gesamtframes |
| 9 | 30 Hz + 3 Bedingungen | §7.9 | ✅ alle 3 Bedingungen + Ziel-Tabelle |
| 10 | Haltezeit | §7.10 | ✅ 70–150 / 100–200 ms |
| 11 | Audioeinstellungen | §7.11 | ✅ kein „Save to Flash" |
| 12 | `LED_EFFECT=4` + `LED_DOA_COLOR` | §7.12 | ✅ 5 nur Chat, nicht README |

### 2.3 Offene Punkte (Teil C.3, 5/5 ehrlich gekennzeichnet)

| Nr. | Offener Punkt | In §10.1? | Korrekt? |
|---|---|---|---|
| 1 | `LED_EFFECT=5` nur Chat | ✅ | ✅ nicht der README zugeschrieben |
| 2 | `respeaker_get_doa.py`-Legacy (Länge 4, Indizes 1/3) vs. `xvf_host.py` (Länge 2, 0/1) | ✅ | ✅ inkl. Status-Offset-Erklärung |
| 3 | Interne Aktualisierungsrate nur vermutet | ✅ | ✅ |
| 4 | `DOA_VALUE`-Ableitung aus Auto selected beam nicht garantiert | ✅ | ✅ |
| 5 | Zwei Haltezeit-Angaben ohne Festlegung | ✅ | ✅ |

---

## 3. Quellenprüfung

| Kürzel | URL in Doku | Übereinstimmung Teil B? | Zuordnung korrekt? |
|---|---|---|---|
| [Q1] | github.com/respeaker/.../host_control/README.md | ✅ exakt | ✅ LED_EFFECT=5 NICHT hierher |
| [Q2] | xmos.com/documentation/XM-014888-PC/... | ✅ exakt | ✅ |
| [Q3] | github.com/.../python_control/xvf_host.py | ✅ exakt | ✅ Zitate wörtlich identisch |
| [Q4] | github.com/.../python_control/respeaker_get_doa.py | ✅ exakt | ✅ |
| [Q5] | wiki.seeedstudio.com/respeaker_xvf3800_introduction | ✅ exakt | ✅ |
| [Q6] | intern (Chat-Verlauf) | ✅ | ✅ |
| — | doa.jpg (Zusatzverweis in [Q1]) | ✅ exakt | ✅ |

- Abrufdatum überall **2026-08-02** ✅
- **Keine erfundenen URLs, keine erfundenen Fakten** ✅

---

## 4. Stil- und Formatprüfung

- Deutscher Erklärungstext, technische Namen englisch ✅
- Kennzeichnungen „Chat-Befund" / „Quelle (validiert)" / „Bewertung/Empfehlung" durchgängig ✅
- Keine Dialogform, keine „Ich"-Formulierungen ✅
- 6 Tabellen (Übersicht §6.1, Kombinationen §7, Ziel-Einstellung §7.9, Abtastraten §8.1, offene Punkte §10.1, Quellen §11) ✅
- 4 Mermaid-Diagramme (§2.3, §4.3, §8.5, §9.4), Syntax plausibel, Code-Fences geschlossen (10 Fences = 5 Blöcke: 4 Mermaid + 1 Python) ✅
- Zahlen exakt: 30°/LED, 26426.47, 2.0.10, #002040/#00C066, 48 Byte, 100 Retries, ~60 Transfers/s ✅

---

## 5. Detailfunde

### 5.1 Vom Schritt-1-Protokoll übernommene Minor-Funde (6, bestätigt)

| # | Stelle | Fund | Schwere |
|---|---|---|---|
| F1 | §5.3 | RT60-Einordnungssatz („hat aber keine direkte Funktion in der Projekt-Effektlogik") ist eine Schlussfolgerung, die so nicht wörtlich in der Faktenbasis steht — als „Einordnung" kennzeichnen | Minor |
| F2 | §6.1 Tab. | Quellenspalte bei `LED_EFFECT` nennt „[Q1], Chat T32" — präzisieren, dass 0–4 aus [Q1] und 5 aus Chat stammt (im Text §6.2 ist es korrekt) | Minor |
| F3 | §2.1 | „ersetzt bzw. ergänzt" → präziser „bildet nach" (die interne Anzeige ist Referenz, wird nicht ersetzt) | Minor |
| F4 | §7.10 | Haltezeit-Erklärung („hält die Richtungsanzeige kurz nach dem letzten erkannten Signal sichtbar") ist Paraphrase, nicht wörtlich — als Erläuterung ok, ggf. als solche kennzeichnen | Minor |
| F5 | §9.1 | „vermutlich Aktualisierung mit dem internen Audiotakt" — korrekt als offener Punkt markiert, aber im Vorteile-Block doppelt erwähnt; Konsistenz prüfen | Minor |
| F6 | §2.2 | Audio-Mux-Zitat — korrekt, aber als eigenständige „Quelle (validiert)"-Box ohne Kontextzeile; Format-Konsistenz | Minor |

### 5.2 Zusätzlicher eigener Fund (Schritt 2, 1)

| # | Stelle | Fund | Schwere |
|---|---|---|---|
| F7 | §5.1 | „gewissermaßen die ‚komfortabelste' Schnittstelle" — wertende Formulierung, die in der Faktenbasis nicht steht (dort nur „dritte, noch stärker zusammengefasste Erkennungsmöglichkeit"). Als „Einordnung" kennzeichnen oder neutraler formulieren | Minor |

### 5.3 Positive Bestätigungen (Auszug)

- §4.1: `DOA_VALUE`-Zitat aus [Q3] **wörtlich identisch** mit Faktenbasis B.3 ✅
- §7.8: Frame-Diff-Codeblock identisch mit Faktenbasis A.4 ✅
- §9.3: alle 7 Korrektur-Schritte aus Turn 32 vollständig und in Reihenfolge ✅
- §10.2: Quellen-Validierungsergebnisse (wörtliche Übereinstimmung [Q3], LED_EFFECT=5 nicht in README) korrekt dargestellt ✅
- Turn-Zuordnungen (T26–T32) durchgängig korrekt ✅

---

## 6. Gesamturteil

**BESTANDEN** — Die Doku deckt alle 20 Pflicht-Werte (C.1), alle 12 Kombinationen (C.2) und alle 5 offenen Punkte (C.3) ab, zitiert ausschließlich die validierten Quellen aus Teil B mit exakten URLs und Abrufdatum, kennzeichnet Chat-Befunde vs. Quellen sauber und enthält keine Erfindungen über die Faktenbasis hinaus.

Die 7 Minor-Funde sind rein kosmetisch/präzisierend (Formulierungs- und Kennzeichnungs-Empfehlungen) — **keine inhaltliche Korrektur erforderlich**. Die Doku ist für Schritt 3 (Prüfung durch Marco) freigegeben.
