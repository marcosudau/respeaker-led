# Faktenquelle Sonderkapitel I: DOA (Normal-Variante, wie Kapitel 1–12)
# Extrahiert aus Chat-Verlauf Turns 26–32 (Z. 3151–3555)
# Hinweis: Diese Fassung enthält NUR Chat-Fakten — keine Online-Recherche, keine externen Quellen (bewusster Vergleichsaufbau).

## Sonderkapitel I: DOA (Direction of Arrival)

**Ziel:** Dokumentation der Richtungserkennung (DOA) des ReSpeaker XVF3800 im LED-Controller: Messwerte, Verhalten des DOA-Effekts, Ursachenanalyse des „Festhängens" und Korrekturmaßnahmen, wie sie im Projekt-Chat (Turns 26–32) erarbeitet wurden.

### Gliederung (Vorschlag)

1. Anlass und Problemstellung
2. Der DOA-Effekt und seine Messwerte
3. Ursachenanalyse des Festhängens
4. Abtastrate, Renderloop und USB-Grenzen
5. Wertegrundlage und Vergleich mit dem internen Effekt
6. Korrekturmaßnahmen
7. Offene Punkte

#-> Fakten aus Turns 26–32

**Turn 26 — DOA-Debug-Logging (temporär):**
- Beim Setzen des DOA-Effekts trat ein Fehler auf; der Effekt „steht immer nur auf einer Richtung", bewegt sich nicht. Andere Effekte funktionieren.
- Befehl + Beschreibung aus der Parameteransicht:
```text
"DOA_VALUE": (20, 18, 2, "ro", "uint16", "Get the doa value and if speech is detected, payload[0] = doa value, from 0 to 359, payload[1] = 1 if speech is detected, 0 if not"),
"LED_RING_COLOR": (20, 19, 12, "rw", "uint32", "Set the LED color of ring mode, each value is the color of one LED"),
```
- Temporäre DOA-Protokollierung eingebaut; pro Abfrage wird z. B. geschrieben:
```text
DOA DEBUG sample payload=(135, 1) direction_deg=135.0 speech_flag=1 forwarded_state=sound
```
- Ungültige Payloads/Winkel werden ebenfalls protokolliert. Das Speech-Flag wird nur angezeigt, aber weiterhin nicht ausgewertet. Verifikation: 166 bestandene Tests; nichts committet/gepusht.

**Turn 27 — Service-Cleanup:**
- Verwaister Service-Prozess beendet (Log endete 23:15:57; Ports 8765–8770 frei).
- Studio beendet den Service-Prozessbaum bei abruptem Schließen automatisch über ein Windows-Jobobjekt; zusätzlich `closeEvent`, `aboutToQuit`, `finally`-Cleanup; Abbruchtest bestanden (Service überlebt `os._exit()` nicht). 167 Tests; temporäre DOA-Wertausgaben bleiben aktiv.

**Turn 28 — DOA-Trägheit: Abtastrate + Interpolation auf 12 LEDs:**
- Renderloop: **30 FPS**, ein Durchlauf etwa alle **33 ms**.
- DOA-Abfrage aktuell `interval_ms=125` → real etwa **7–8 Abfragen pro Sekunde**.
- Pull-Abfragen sind an Renderframes gekoppelt → beliebige Zwischenraten nicht exakt möglich.
- Bei `50 ms` → praktisch eher ~15 Hz (Prüfung nur alle 33 ms). `interval_ms=0` → eine Abfrage pro Frame → maximal ~30 Hz.
- Praktische Grenzen: 30 LED-Schreibvorgänge + 30 DOA-Lesevorgänge = ~60 USB-Control-Transfers/s. Datenmenge winzig; kritischer sind ReSpeaker-Verarbeitung, USB-Latenzen, serielle Ausführung im Renderthread. Der Treiber hat einen sehr großzügigen Timeout und bis zu 100 Wiederholungsversuche → problematischer Transfer kann den Renderloop länger blockieren.
- **12 LEDs** → 360°/12 = **30° pro LED**. Winkel 81°→88°→95° kann weiterhin dieselbe LED wählen → Effekt sieht festgefahren aus, obwohl sich der DOA-Wert laufend ändert. Erklärt erheblichen Teil der wahrgenommenen Schwerfälligkeit.
- Vorschlag: (1) testweise 50 ms (~15 Hz), (2) USB-Lesedauer + Alter des letzten Winkels protokollieren, (3) Richtungsindikator zwischen zwei benachbarten LEDs interpolieren (je näher an der nächsten LED, desto heller), (4) nicht direkt auf 30 Abfragen/s gehen.

**Turn 29 — USB-Grenzen + LED-Frame-Diff:**
- Physischer Hardwaredefekt sehr unwahrscheinlich: `DOA_VALUE` liest nur einen flüchtigen Laufzeitwert, `LED_RING_COLOR` schreibt den aktuellen LED-Puffer; kein Flash-Schreiben → kein relevanter Speicher-Verschleiß.
- Folgen zu hoher Rate: Service erreicht FPS nicht mehr; LED-Animationen ruckeln; USB-Transfers liefern Retry, Timeout oder Stall; ReSpeaker reagiert zeitweise nicht, evtl. USB-Neuverbindung nötig; im ungünstigsten Fall blockiert der Renderthread länger.
- Treiber wiederholt Firmware-`RETRY` bis zu 100-mal; alles synchron → Controller bleibt stehen statt Anfragen aufzustauen.
- `LED_RING_COLOR` ist **ein** USB-Transfer mit zwingend allen 12 Farben: `12 × uint32 = 48 Byte`. Keine Möglichkeit, nur einzelne LEDs zu aktualisieren.
- Frame-Diff-Optimierung:
```python
if frame.leds == previous_leds:
    return
device.write("LED_RING_COLOR", frame.leds)
previous_leds = list(frame.leds)
```
- Wirkung: statischer Ring → nach erstem Frame keine weiteren LED-Transfers; langsame quantisierte Animation → identische Zwischenframes übersprungen; flüssige Animation → weiterhin bis zu 30 Transfers/s.
- Im aktuellen Test dreht sich der darunterliegende State weiter; Engine rechnet erst alle Layer zusammen und sendet dann den vollständigen Endframe → Optimierung spart dort nur wenig.
- Datenmenge ~1,4 KB/s bei 30 FPS unkritisch; relevant sind Anzahl USB-Control-Transfers und Firmware-Verarbeitungszeit.
- Empfehlung: identische Gesamtframes nicht erneut übertragen; DOA 50 ms; Lesen/Schreiben seriell; USB-Laufzeiten und Fehler protokollieren; interpolieren.

**Turn 30 — DOA-Wertegrundlage: AEC Auto-selected Beam vs. DOA_VALUE:**
- Der originale Door-Effekt (im ReSpeaker gespeichert) funktioniert gut: „da ist Bewegung drin", Anzeige nur während Geräuschen; Wanduhr-Beispiel: Sekundenzeiger lässt die LED einmal pro Sekunde kurz aufblinken.
- Nicht exakt dieselbe Wertegrundlage: Der interne ReSpeaker-DOA-Modus arbeitet direkt innerhalb der Firmware; laut offizieller Dokumentation verwendet die eingebaute DOA-Anzeige den **vierten Wert von `AEC_AZIMUTH_VALUES`, also den Auto-selected beam**.
- Eigene Implementierung damals: `DOA_VALUE[0]` = ganzzahliger Winkel, `DOA_VALUE[1]` = Aktivitäts-/Speech-Flag; `payload[1]` wurde vollständig ignoriert; Effekt bekam immer `"detection_state": "sound"` → zuletzt gemessener Winkel bleibt dauerhaft sichtbar → sieht wie Festhängen aus.
- Vorteile des internen Effekts: direkter Zugriff auf interne DSP-/Beamforming-Werte; keine USB-Abtastverzögerung; vermutlich Aktualisierung mit dem internen Audiotakt; Zugriff auf Auto-selected beam; Aktivitätsinformationen über die Beam-Energie; Anzeige nur während erkannter Aktivität.
- `AEC_SPENERGY_VALUES`: dessen **vierter Wert** beschreibt die Speech-Energie des Auto-selected beam. Wert über null = erkannte Aktivität; höhere Werte ≈ lauteres/näheres Signal. Passt zur Wanduhr-Beobachtung.
- Arbeitsweise des internen Effekts: kurzes Geräusch erkannt → Auto-selected beam bestimmt Richtung → LED an dieser Richtung kurz einschalten → bei fehlender Energie wieder ausblenden.
- Einordnung: `DOA_VALUE` kann intern durchaus aus demselben Beamforming-System abgeleitet sein; die Dokumentation garantiert aber nicht, dass es exakt derselbe Wert mit demselben Aktualisierungs-/Aktivitätsverhalten ist. Dokumentiert ist ausdrücklich der Auto-selected beam als Grundlage der internen LED-Anzeige.
- Vorschlag: Vergleichsprovider, der gleichzeitig protokolliert: `DOA_VALUE`, `AEC_AZIMUTH_VALUES[3]`, `AEC_SPENERGY_VALUES[3]`. Ziel-Provider: `AEC_AZIMUTH_VALUES[3]` als Richtung und `AEC_SPENERGY_VALUES[3]` als Aktivität; kurze Haltezeit ~100–200 ms, dann ausblenden.

**Turn 31 — 30-Hz-DOA-Telemetrie + Bedingungen:**
- In der offiziellen ReSpeaker-App kann man bis 30 Hz Live-Telemetrie auswählen → starkes Indiz, dass der ReSpeaker regelmäßige Telemetrieabfragen mit 30 Hz verträgt. Die App liest gleichzeitig DOA, Voice Activity und Beam-Energien.
- 30 DOA-Abfragen/s grundsätzlich plausibel und geräteseitig vorgesehen; keine Beschädigung zu erwarten; schlimmstenfalls verzögerte Frames, USB-Retries oder vorübergehend hängender Service.
- **Drei Bedingungen:**
  1. ReSpeaker Console und LED-Controller dürfen nicht gleichzeitig zugreifen — solche parallelen Prozesse hatten bereits `USBError: Entity not found`-Fehler verursacht.
  2. Nur eine Hardwareabfrage pro Frame — theoretisch könnte jedes aktive Pull-Overlay seinen Provider separat aufrufen (bei mehreren DOA-Overlays: 60–90 USB-Abfragen). Provider soll zentral pro Renderframe cachen und allen Effekten denselben Messwert liefern.
  3. DOA-Lesen und LED-Schreiben seriell lassen — keine konkurrierenden USB-Threads, keine unkontrollierte Warteschlange.
- Ziel-Einstellung: Renderfrequenz 30 Hz; DOA-Abfrage einmal pro Renderframe; max. 30 DOA-Reads/s; LED-Ausgabe nur bei verändertem Gesamtframe; Provider-Cache ein Messwert pro Frame für alle DOA-Effekte.
- Die offizielle App verwendet neben der Richtung ausdrücklich Voice Activity und Beam Energy → Aktivität und Richtung müssen gemeinsam ausgewertet werden.

**Turn 32 — DOA_VALUE entschlüsselt: Winkel + VAD-Flag:**
- Parameteransicht der ReSpeaker-App: `DOA_VALUE — uint16 x2 — DoA value [0..359] and VAD flag`.
- Der zweite Wert ist **kein** Ergebnis einer Spracherkennung (Speech-to-Text), sondern ein **VAD-Flag: Voice Activity Detection**.
- Aktuelle Implementierung: `payload[0]` → Winkel, `payload[1]` → ignorieren, `detection_state` → immer `"sound"`. Sehr wahrscheinliche Ursache für den Festhänge-Eindruck: Wenn kein relevantes Geräusch aktiv ist, behält `payload[0]` offenbar einfach die zuletzt erkannte Richtung.
- Interner Effekt vermutlich: VAD = 1 → Richtung anzeigen; VAD = 0 → Richtungsanzeige ausblenden.
- Monitorwerte (Screenshot): `Direction of arrival: 266°`, `Voice activity: Active`, `Max beam energy: 26426.47`, `Beam 1: 26426.47`, `Beam 3: 26426.47`.
- Beam 3 = laut offizieller Dokumentation der Auto-selected beam. Beam 1 = Beam 3 (gleicher Energiewert) bedeutet vermutlich: Beam 1 wurde aktuell als bester Beam ausgewählt und auf Beam 3 durchgereicht. Die interne DOA-Anzeige verwendet genau diesen Auto-selected beam.
- Zusammenhang der Werte:
```text
AEC_AZIMUTH_VALUES[3]  → genauer Winkel des ausgewählten Beams
AEC_SPENERGY_VALUES[3] → Energie dieses Beams
DOA_VALUE[0]           → vereinfachter Winkel für Anwendungen
DOA_VALUE[1]           → vereinfachtes VAD-Flag
```
- `DOA_VALUE` scheint die praktische, zusammengefasste Schnittstelle für Anwendungen zu sein; nicht zwingend sofort auf die ausführlichen AEC-Wertesätze wechseln.
- 30 Hz: Die Konsole überwacht bei 30 Hz gleichzeitig DOA, VAD, vier Beam-Energien, RT60, AEC-Status → bestätigt 30-Hz-Telemetrie mit Firmware **2.0.10**.
- Interner LED-Effekt (Parameteransicht): `LED_EFFECT = 4` → interner DOA-Modus; `LED_EFFECT = 5` → frei gesetzter Ringmodus; `LED_DOA_COLOR` → Grundfarbe und Highlight-Farbe. Base color: `#002040`; Highlight: `#00C066` → Grundring + bei VAD-Aktivität hervorgehobene Richtung.
- `LED_SPEED` ist laut Protokolldokumentation primär für Breath und Rainbow gedacht; Wert `8` ist daher wahrscheinlich nicht die Reaktionsgeschwindigkeit der DOA-Auswertung.
- Audioeinstellungen: Noise Suppression, AGC, Echo Suppression, Double-talk Sensitivity können beeinflussen, was der DSP als Aktivität oder guten Beam bewertet. Vorerst nicht verändern; insbesondere nicht auf **Save to Flash** klicken. `AEC converged: No` ist allein kein DOA-Fehler (betrifft primär Echo-Unterdrückung und Far-End-Referenz).
- Konkrete Korrektur (nächste Implementierungsschritte):
  1. DOA einmal pro Renderframe abfragen (bei 30 FPS max. 30 Hz).
  2. VAD-Flag nicht mehr ignorieren: `0` → `detection_state="none"`, `1` → `detection_state="sound"`.
  3. Ohne VAD die Richtungsanzeige transparent machen.
  4. Optional sehr kurze Haltezeit ~70–150 ms anbieten.
  5. Providerwerte einmal pro Frame cachen (auch bei mehreren DOA-Effekten).
  6. Identische LED-Gesamtframes nicht erneut übertragen.
  7. `AEC_AZIMUTH_VALUES` und `AEC_SPENERGY_VALUES` zunächst nur zusätzlich diagnostisch vergleichen.

#-> Schwerpunkte

- DOA-Effekt „steht immer auf einer Richtung": Ursache ist sehr wahrscheinlich die Kombination aus ignoriertem VAD-Flag und dauerhaft gemeldetem `detection_state="sound"`.
- 12 LEDs = 30°/LED → kleine Winkeländerungen können dieselbe LED wählen (scheinbares Festhängen); Interpolation zwischen Nachbar-LEDs macht sie sichtbar.
- 30 Hz ist geräteseitig vorgesehen (Console-Firmware 2.0.10), aber nur mit drei Bedingungen stabil: kein Parallelzugriff, eine Abfrage/Frame + Provider-Cache, serielles Lesen/Schreiben.
- Wertegrundlage des internen Effekts: Auto-selected beam (`AEC_AZIMUTH_VALUES[3]` + `AEC_SPENERGY_VALUES[3]`); `DOA_VALUE` ist die vereinfachte Anwendungsschnittstelle (Winkel + VAD-Flag).
- Der Nachbau des internen Effekts: VAD auswerten, ohne VAD ausblenden, kurze Haltezeit (~70–150 ms bzw. ~100–200 ms), Frame-Diff, Interpolation.

#-> Entscheidungen

- **A1:** DOA-Abfrage einmal pro Renderframe (max. 30 Hz), VAD-Flag auswerten (`0` → `none`, `1` → `sound`), ohne VAD transparent? Empfehlung: Ja.
- **A2:** Kurze Haltezeit (~70–150 ms) optional anbieten? Empfehlung: Ja.
- **A3:** Providerwerte einmal pro Frame cachen, identische LED-Gesamtframes nicht erneut übertragen? Empfehlung: Ja.
- **A4:** `AEC_AZIMUTH_VALUES`/`AEC_SPENERGY_VALUES` zunächst nur diagnostisch vergleichen, `DOA_VALUE` als primäre Schnittstelle behalten? Empfehlung: Ja.
- **A5:** Audioeinstellungen unverändert lassen und nicht auf „Save to Flash" klicken? Empfehlung: Ja.
