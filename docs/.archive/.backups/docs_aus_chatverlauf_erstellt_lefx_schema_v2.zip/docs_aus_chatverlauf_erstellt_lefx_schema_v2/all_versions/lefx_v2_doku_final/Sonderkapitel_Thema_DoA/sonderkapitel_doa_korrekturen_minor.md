# Redaktionelle Korrekturen (Minor-Funde F1–F7) — Sonderkapitel I: DOA

**Datei:** `sonderkapitel_doa_doku_runde1.md` (520 Zeilen, unverändert)
**Anlass:** Marco, 2026-08-02 13:17 UTC: „pflege erst die Änderungen ein."
**Basis:** Minor-Funde aus Validierung Schritt 1 (`sonderkapitel_doa_validierung_schritt1.md`, F1–F6) + Schritt 2 (`sonderkapitel_doa_validierung_schritt2.md`, F7).
**Konvention:** Redaktionelle Korrekturen direkt angewendet + transparent im Protokoll.

| Fund | Stelle | Korrektur | Status |
|---|---|---|---|
| F1 | §5.3 (RT60) | Satz „hat aber keine direkte Funktion in der Projekt-Effektlogik" als *(Einordnung: … in der Faktenbasis nicht belegt)* gekennzeichnet | ✅ |
| F2 | §6.1 (Tabelle `LED_EFFECT`) | Quellenspalte präzisiert: `[Q1] (Werte 0–4), Chat T32 (Wert 5)` | ✅ |
| F3 | §2.1 | „ersetzt bzw. ergänzt" → „bildet diese Anzeige durch eigene Effekte nach" | ✅ |
| F4 | §7.10 (Haltezeit) | Paraphrase als „(Erläuterung, nicht wörtlich im Chat belegt)" gekennzeichnet | ✅ |
| F5 | §9.1 (Audiotakt-Vermutung) | Verweis konkretisiert: „(Vermutung — siehe offener Punkt 3, Abschnitt 10.1)" — Dopplung Fließtext/Tabelle bleibt, jetzt konsistent referenziert | ✅ |
| F6 | §2.2 (Audio-Mux-Zitat) | Box mit Kontextzeile ergänzt: „Der Audio-Mux legt fest, welcher Beam als Ausgang dient." | ✅ |
| F7 | §5.1 (`AUDIO_MGR_SELECTED_AZIMUTHS`) | „komfortabelste Schnittstelle" → neutraler: „im Vergleich zu `DOA_VALUE` die am stärksten zusammengefasste Schnittstelle (Einordnung, nicht wörtlich in der Quelle belegt)" | ✅ |

**Verifikation:** Alle 7 neuen Formulierungen genau 1× vorhanden; keine Alt-Formulierungen mehr (0 Treffer); Zeilenanzahl 520 (rein textliche Ersetzungen, keine Strukturänderung).

**Wirkung:** Keine inhaltliche Änderung an Fakten, Werten, Kombinationen, Quellen oder offenen Punkten — ausschließlich Kennzeichnungs- und Formulierungspräzisierungen. Die Doku bleibt für Schritt 3 (Marco-Prüfung) freigegeben.
