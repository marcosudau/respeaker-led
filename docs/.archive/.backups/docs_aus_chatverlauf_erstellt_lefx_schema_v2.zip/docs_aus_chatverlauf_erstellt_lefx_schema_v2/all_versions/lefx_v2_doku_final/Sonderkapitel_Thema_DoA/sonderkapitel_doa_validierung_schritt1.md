# Validierungsprotokoll Schritt 1 — Sonderkapitel I: DOA

**Geprüfte Datei:** `/home/marco/workspace/sonderkapitel_doa_doku_runde1.md` (520 Zeilen)
**Referenz (verbindliche Faktenbasis):** `/home/marco/workspace/sonderkapitel_doa_bereich.md` (28 KB, Teile A–D)
**Prüfer:** Unabhängiger Validator (Stufe 1 von 3, Detailauftrag Marco)
**Datum der Prüfung:** 2026-08-02
**Methode:** Zeilenweiser Vollabgleich der Doku gegen Teile A, B, C, D der Faktenbasis; Prüfung aller C.1-Werte (20), C.2-Kombinationen (12), C.3-offenen Punkte (4+1), Quellenangaben (Teil B), Stil-Konventionen (Teil D) und Formatierung (Tabellen/Mermaid/Code-Fences).

---

## 1. Vollständigkeitstabelle — Teil C.1: Einzelwerte (Pflicht: alle 20)

| Nr. | Wert | In Doku vorhanden? (Stelle) | Erklärung korrekt? | Anmerkung |
|---|---|---|---|---|
| 1 | `DOA_VALUE[0]` (Winkel 0–359) | ✅ §4.2, §4.3 | ✅ korrekt: „vereinfachter Richtungswinkel in Grad (0–359)" | deckungsgleich mit C.1 + A.7 |
| 2 | `DOA_VALUE[1]` (VAD-Flag) | ✅ §4.2, §4.3 | ✅ korrekt: 1 = Sprachaktivität, 0 = keine; explizit kein Speech-to-Text | deckungsgleich mit A.7 |
| 3 | `AEC_AZIMUTH_VALUES[0..2]` (Focused 1/2, Free running) | ✅ §3.1 | ✅ korrekt, Reihenfolge korrekt | identisch B.1/B.2 |
| 4 | `AEC_AZIMUTH_VALUES[3]` (Auto selected beam — Grundlage interne DOA-Anzeige) | ✅ §3.1, §2.3, §7.2 | ✅ korrekt: „The DoA indication uses the last value (Auto selected beam)" | korrekt [Q1] zugeordnet |
| 5 | `AEC_SPENERGY_VALUES[0..2]` | ✅ §3.2 | ✅ korrekt, Reihenfolge korrekt | identisch B.1 |
| 6 | `AEC_SPENERGY_VALUES[3]` (Energie, >0 = Aktivität, höher = lauter/näher) | ✅ §3.2, §7.2 | ✅ korrekt inkl. Abschwächung durch Rauschen/Echo/Nachhall | Zitat wörtlich B.1 |
| 7 | `LED_RING_COLOR` (12×uint32 = 48 B, EIN Transfer, alle 12 LEDs) | ✅ §6.1, §6.2 | ✅ korrekt: ein USB-Transfer, kein Einzel-LED-Update | deckungsgleich A.4 |
| 8 | `LED_EFFECT` (0–4, 5 nur Chat) | ✅ §6.1, §6.2, §7.12, §10.1 | ✅ korrekt: 0–4 aus [Q1], Wert 5 ausdrücklich NICHT der README zugeschrieben | Kernanforderung erfüllt |
| 9 | `LED_DOA_COLOR` (Base+Highlight) | ✅ §6.1, §6.2 | ✅ korrekt inkl. Beispiel #002040/#00C066 | deckungsgleich B.1 + A.7 |
| 10 | `LED_SPEED` (breath/rainbow, NICHT DOA-Reaktionszeit) | ✅ §6.1, §6.2 | ✅ korrekt: Wert 8 „wahrscheinlich nicht die Reaktionsgeschwindigkeit der DOA-Auswertung" | deckungsgleich A.7 |
| 11 | `LED_BRIGHTNESS` | ✅ §6.1 | ✅ korrekt („Helligkeit für breath/rainbow"), aber ohne expliziten DOA-Bezug | siehe Fund F4 |
| 12 | `LED_GAMMIFY` | ✅ §6.1 | ✅ korrekt („Gamma-Korrektur 0/1") | siehe Fund F4 |
| 13 | `LED_COLOR` | ✅ §6.1 | ✅ korrekt („Farbe für breath und single color") | siehe Fund F4 |
| 14 | `AUDIO_MGR_SELECTED_AZIMUTHS[0]` (NAN = keine Sprache) | ✅ §5.1 | ✅ korrekt, Zitat wörtlich [Q2] | identisch B.2 |
| 15 | `AUDIO_MGR_SELECTED_AZIMUTHS[1]` (aktueller Auto-select-Azimut) | ✅ §5.1 | ✅ korrekt | identisch B.2 |
| 16 | `detection_state` ("sound"/"none") | ✅ §5.4 | ✅ korrekt inkl. Fehlerbild „immer sound" | deckungsgleich A.1/A.5/A.7 |
| 17 | `interval_ms` (125→7–8 Hz, 50→~15 Hz, 0→max 30 Hz) | ✅ §8.1, §7.6 | ✅ alle drei Werte korrekt | deckungsgleich A.3 |
| 18 | Renderfrequenz 30 FPS (~33 ms) | ✅ §8.1, §7.6 | ✅ korrekt | deckungsgleich A.3 |
| 19 | Beam-Energien (Monitor: Max 26426.47, Beam 1 = Beam 3) | ✅ §5.2, §7.3 | ✅ korrekt | deckungsgleich A.7 |
| 20 | RT60 / AEC-Status (AEC converged: No ≠ DOA-Fehler) | ✅ §5.3 | ✅ korrekt | deckungsgleich A.7/C.1 |

**Ergebnis C.1: 20/20 vorhanden, 20/20 korrekt.**

## 2. Vollständigkeitstabelle — Teil C.2: Kombinationen (Pflicht: alle 12)

| Nr. | Kombination | In Doku vorhanden? (Stelle) | Bewertung wie Faktenbasis? | Anmerkung |
|---|---|---|---|---|
| 1 | `DOA_VALUE[0]` + `DOA_VALUE[1]` (Winkel + VAD) | ✅ §7.1 | ✅ VAD=1→anzeigen, 0→ausblenden; Ursache „Festhängen"; Korrektur `0`→none, `1`→sound | deckungsgleich C.2.1/A.7 |
| 2 | Auto-selected beam Richtung + Energie | ✅ §7.2 | ✅ Wertegrundlage des internen Effekts; Zielkombination mit Haltezeit 100–200 ms | deckungsgleich C.2.2/A.5 |
| 3 | Beam 1 = Beam 3 (durchgereicht) | ✅ §7.3 | ✅ Deutung identisch, gestützt durch Audio-Mux [Q2] | deckungsgleich C.2.3/A.7 |
| 4 | `DOA_VALUE` vs. `AEC_*`-Werte | ✅ §7.4 | ✅ erst DOA_VALUE, AEC-Werte diagnostisch | deckungsgleich C.2.4/A.7 |
| 5 | 12-LED-Quantisierung 30°/LED | ✅ §7.5 | ✅ 81°→88°→95° dieselbe LED; Interpolation als Lösung | deckungsgleich C.2.5/A.3 |
| 6 | Abtastrate + Renderloop (Pull gekoppelt, `interval_ms=0` = 1×/Frame) | ✅ §7.6 | ✅ exakte Zwischenraten unmöglich; 50 ms ≈ 15 Hz empfohlen | deckungsgleich C.2.6/A.3 |
| 7 | USB-Gesamtlast ~60 Transfers/s | ✅ §7.7 | ✅ 30 Writes + 30 Reads; ~1,4 KB/s unkritisch; seriell | deckungsgleich C.2.7/A.3/A.4 |
| 8 | Frame-Diff + Layer-Komposition | ✅ §7.8 | ✅ Code-Beispiel identisch mit A.4; spart bei bewegtem State wenig | deckungsgleich C.2.8/A.4 |
| 9 | 30 Hz + 3 Bedingungen | ✅ §7.9 | ✅ alle 3 Bedingungen (kein Parallelzugriff, 1 Abfrage/Frame + Cache, seriell) + Ziel-Einstellungs-Tabelle identisch A.6 | deckungsgleich C.2.9/A.6 |
| 10 | Haltezeit 70–150 ms bzw. 100–200 ms | ✅ §7.10 | ✅ beide Angaben korrekt zugeordnet (T30: 100–200, T32: 70–150); Wanduhr-Beispiel | deckungsgleich C.2.10/A.5/A.7 |
| 11 | Audioeinstellungen + kein Save to Flash | ✅ §7.11 | ✅ Noise Suppression, AGC, Echo Suppression, Double-talk; kein „Save to Flash"; AEC converged: No ≠ DOA-Fehler | deckungsgleich C.2.11/A.7 |
| 12 | `LED_EFFECT=4` + `LED_DOA_COLOR` | ✅ §7.12 | ✅ interner DOA-Modus, Base/Highlight; `LED_EFFECT=5` als Chat-Beobachtung, nicht README | deckungsgleich C.2.12/A.7 |

**Ergebnis C.2: 12/12 vorhanden, 12/12 Bewertungen korrekt.**

## 3. Vollständigkeitstabelle — Teil C.3: Offene Punkte (Pflicht: 4 + 1)

| Nr. | Offener Punkt | In Doku vorhanden? (Stelle) | Ehrlich gekennzeichnet? | Anmerkung |
|---|---|---|---|---|
| 1 | `LED_EFFECT = 5` nur Chat-Beobachtung | ✅ §10.1 Nr. 1 | ✅ „Als Chat-Beobachtung kennzeichnen, nicht als Quelle belegt" | zusätzlich in §6.1/6.2/7.12 korrekt behandelt |
| 2 | `respeaker_get_doa.py` (Länge 4, Indizes 1/3) vs. `xvf_host.py` (Länge 2, Indizes 0/1) | ✅ §10.1 Nr. 2 | ✅ inkl. Status-Byte-Erklärung (`length = data[2] + 1`), Maßgeblichkeit xvf_host.py | deckungsgleich B.4 |
| 3 | Interne Aktualisierungsrate nur vermutet | ✅ §10.1 Nr. 3 | ✅ „im Chat nur vermutet, nicht verifiziert" | deckungsgleich A.5/C.3; auch §9.1 korrekt markiert |
| 4 | DOA_VALUE-Ableitung aus Auto selected beam offiziell nicht garantiert | ✅ §10.1 Nr. 4 + §4.3 | ✅ als offen gekennzeichnet, keine Falschbehauptung | deckungsgleich A.5/C.3 |
| 5 | Zwei Haltezeit-Angaben ohne Festlegung | ✅ §10.1 Nr. 5 | ✅ „keine abschließende Festlegung … beide als Option dokumentiert" | korrekt aus C.2.10 abgeleitet |

**Ergebnis C.3: 5/5 vorhanden, 5/5 ehrlich gekennzeichnet.**

## 4. Detailfunde

### 4.1 Abweichungen / Unklarheiten (nummerierte Funde)

**Fund F1 — Schweregrad: Minor**
- **Stelle:** Doku §5.3, Bullet „RT60" (nach dem Chat-Befund-Block).
- **Befund:** Der Satz „…hat aber keine direkte Funktion in der Projekt-Effektlogik" steht so nicht in der Faktenbasis. Dort (C.1, A.7) steht nur, dass RT60 von der Konsole bei 30 Hz mitüberwacht wird. Es ist eine plausible Schlussfolgerung, aber keine belegte Aussage — und sie steht in einem Absatz, der als „Chat-Befund"-Umfeld gelesen werden könnte.
- **Empfehlung:** Als „Bewertung/Einordnung" kennzeichnen oder weglassen. Keine inhaltliche Korrektur nötig.

**Fund F2 — Schweregrad: Minor**
- **Stelle:** Doku §2.1, Einordnungskasten.
- **Befund:** „Das Projekt … ersetzt bzw. ergänzt diese Anzeige durch eigene Effekte" — die Faktenbasis spricht nur vom „Nachbilden/Nachbauen" des internen Effekts (A.5, C.2.2). „Ersetzt bzw. ergänzt" ist eine Interpretationsformulierung.
- **Empfehlung:** Auf „bildet die Anzeige durch eigene Effekte nach" umformulieren oder als Einordnung kennzeichnen.

**Fund F3 — Schweregrad: Minor**
- **Stelle:** Doku §6.1, Tabelle, Zeile `LED_EFFECT`, Quellenspalte „[Q1], Chat T32".
- **Befund:** Die Quellenspalte nennt [Q1] für eine Zeile, deren Kernbotschaft ist, dass Wert 5 **nicht** in [Q1] steht. Der beschreibende Zelltext stellt das korrekt klar („nur laut App, nicht in der README"), aber die Quellenspalte könnte streng gelesen als Zuschreibung von Wert 5 an [Q1] missverstanden werden — genau das, was die Validierungsvorgabe („LED_EFFECT=5 NICHT der README zuschreiben") ausschließen will.
- **Empfehlung:** Quellenspalte präzisieren, z. B. „[Q1] (0–4), Chat T32 (5)".

**Fund F4 — Schweregrad: Minor**
- **Stelle:** Doku §6.1, Zeilen `LED_BRIGHTNESS`, `LED_GAMMIFY`, `LED_COLOR`.
- **Befund:** Diese drei Werte werden nur mit ihrer Funktionsbeschreibung („Helligkeit für breath/rainbow" etc.) erklärt, ohne expliziten Bezug zum DOA-Effekt. Die Faktenbasis (C.1) gibt genau diese Beschreibungen vor — die Doku ist also nicht falsch —, aber die Auflage „alle Werte in Bezug auf DOA-Effekt und Erkennung erklären" (Teil D.1) wäre durch einen expliziten Zusatz „kein DOA-Bezug" wasserdichter erfüllt.
- **Empfehlung:** Optional je Zeile „(kein DOA-Bezug)" ergänzen.

**Fund F5 — Schweregrad: Minor**
- **Stelle:** Doku §9.3, Blockquote-Überschrift „(Turn 32, verbindliche nächste Implementierungsschritte)".
- **Befund:** Die Faktenbasis (A.7) sagt „Konkrete Korrektur (nächste Implementierungsschritte)" — das Wort „verbindliche" ist ein Zusatz der Doku. Inhaltlich unproblematisch (die Schritte sind die vom Chat vorgegebenen), streng genommen aber eine Zutat.
- **Empfehlung:** „verbindliche" entfernen oder durch „konkrete" ersetzen.

**Fund F6 — Schweregrad: Minor**
- **Stelle:** Doku §8.1, Tabelle, Zeile `interval_ms = 125`, Spalte „Erklärung".
- **Befund:** „Ausgangszustand der Fehleranalyse" ist eine Charakterisierung; die Faktenbasis (A.3) sagt neutral „DOA-Abfrage aktuell `interval_ms=125`". Kein Widerspruch, nur ein kleiner Zusatz.
- **Empfehlung:** Kann bleiben; faktenbasiert wäre „Ausgangszustand der Analyse (Turn 28)".

**Keine Kritischen und keine Mittleren Funde.** Alle Abweichungen sind kosmetischer/präzisierender Natur; kein einziger Wert, keine Zuordnung, kein Zitat und keine Bewertung widerspricht der Faktenbasis.

### 4.2 Positive Bestätigungen (stichpunktartig)

- **Alle 20 C.1-Werte** in der Doku vorhanden, an den richtigen Stellen erklärt, fachlich korrekt.
- **Alle 12 C.2-Kombinationen** in Abschnitt 7 mit identischer Bewertung wie in C.2; die Abschnitts-Übersichtstabelle (Nr. 1–12) spiegelt C.2 exakt.
- **Alle 5 offenen Punkte (4 aus C.3 + Haltezeit)** in §10.1 ehrlich gekennzeichnet; die Haltezeit-Doppelangabe (70–150 vs. 100–200 ms) wird nirgends einseitig „festgelegt".
- **Kernfalle bestanden:** `LED_EFFECT = 5` wird an keiner Stelle der README zugeschrieben — durchgängig als Chat-/App-Beobachtung markiert (§6.1, §6.2, §7.12, §10.1, §10.2).
- **Zitate wörtlich identisch** mit Teil B: [Q1] AEC_AZIMUTH/SPENERGY/LED-Quotes, [Q2] AUDIO_MGR_SELECTED_AZIMUTHS/Audio-Mux/Auto-Selection, [Q3] xvf_host.py-Definitionen, inkl. Beispielwerte (`0.91378 (52.36 deg) …`, `2080656 0 2083455 2080656`).
- **Turn-Zuordnungen durchgängig korrekt** (T26: Definitionen wörtlich identisch; T28: Abtastrate/Quantisierung/Frame-Diff; T29: USB/Flash; T30: Auto-selected beam/Wanduhr/100–200 ms; T31: 30 Hz + 3 Bedingungen; T32: VAD-Erkenntnis/Monitorwerte/70–150 ms/2.0.10).
- **Zahlenwerte exakt:** 30°/LED, 7–8 Hz, ~15 Hz, max. 30 Hz, ~60 Transfers/s, ~1,4 KB/s, 48 Byte, 33 ms, 100 Retries, 266°, 26426.47, #002040/#00C066, Firmware 2.0.10, 0–359, NAN.
- **Kennzeichnungen** „Chat-Befund" / „Quelle (validiert)" / „Bewertung/Empfehlung" durchgängig und korrekt gesetzt; keine Dialogform, kein „Ich".
- **DOA_VALUE-Ableitung** korrekt als offen markiert (§4.3, §10.1 Nr. 4) — keine überzogene Behauptung.
- **`AEC converged: No` ≠ DOA-Fehler** korrekt übernommen (§5.3, §7.11).
- **AUDIO_MGR_SELECTED_AZIMUTHS** wird ehrlich als „vom Projekt nicht verwendet, vollständigkeitshalber dokumentiert" eingeordnet (§5.1).
- **Formatierung:** alle Code-Fences geschlossen; 4 Mermaid-Diagramme (§2.3, §4.3, §8.5, §9.4) syntaktisch plausibel (subgraph-ID mit Label, HTML-Entity `&gt;` korrekt, Edge-Labels korrekt); alle Tabellen (6.1, 7, 7.9, 8.1, 10.1, 11) wohlgeformt mit konsistenter Spaltenzahl.

## 5. Quellenprüfung

| URL in der Doku (§11 + Ergänzung) | Entspricht Teil B? | Zuordnung in der Doku korrekt? |
|---|---|---|
| `https://github.com/respeaker/reSpeaker_XVF3800_USB_4MIC_ARRAY/blob/master/host_control/README.md` | ✅ = B.1 ([Q1]) | ✅ AEC_AZIMUTH, AEC_SPENERGY, LED_EFFECT 0–4, LED_DOA_COLOR, LED_SPEED, LED_BRIGHTNESS, LED_GAMMIFY, LED_COLOR, SAVE/CLEAR_CONFIGURATION, Default-Rainbow→DOA, Beamforming-Beschreibung — alles korrekt [Q1] zugeordnet |
| `https://www.xmos.com/documentation/XM-014888-PC/html/modules/fwk_xvf/doc/user_guide/03_using_the_host_application.html` | ✅ = B.2 ([Q2]) | ✅ AUDIO_MGR_SELECTED_AZIMUTHS, Koordinatensystem 0–180/0–360, Audio-Mux, Auto-Selection-Verhalten, Fixed-Beams — korrekt [Q2] zugeordnet |
| `https://github.com/respeaker/reSpeaker_XVF3800_USB_4MIC_ARRAY/blob/master/python_control/xvf_host.py` | ✅ = B.3 ([Q3]) | ✅ DOA_VALUE- und LED_RING_COLOR-Definitionen korrekt [Q3] zugeordnet |
| `https://github.com/respeaker/reSpeaker_XVF3800_USB_4MIC_ARRAY/blob/master/python_control/respeaker_get_doa.py` | ✅ = B.4 ([Q4]) | ✅ Legacy-Konvention (Länge 4, Indizes 1/3) korrekt [Q4] zugeordnet |
| `https://wiki.seeedstudio.com/respeaker_xvf3800_introduction` | ✅ = B.5 ([Q5]) | ✅ 4-Mic-Array, 360° bis 5 m, kreisförmige (quadratische) Anordnung, Firmware-Beispiele — korrekt [Q5] zugeordnet |
| intern: `chat_history_lefx_schema_v2---db0c18aa-4ee2-4ce5-94d3-e38e01bf80a5.md`, Z. 3151–3555, Turns 26–32 | ✅ = Kopf der Faktenbasis ([Q6]) | ✅ Chat-Befunde durchgängig [Q6] zugeordnet |
| `https://github.com/respeaker/reSpeaker_XVF3800_USB_4MIC_ARRAY/blob/master/doc/doa.jpg` | ✅ = B.1 („Ergänzender Verweis") | ✅ korrekt als „Ergänzender Verweis innerhalb von [Q1]" deklariert |

**Quellenprüfung bestanden:** Keine erfundenen URLs, keine falsch zugeordneten Fakten, Abrufdatum 2026-08-02 durchgängig angegeben. Kritische Zuordnung (LED_EFFECT=5) ist sauber: [Q1] belegt nur 0–4, Wert 5 ist überall als Chat-Beobachtung gekennzeichnet.

## 6. Stil- und Formalkontrolle (Teil D)

- ✅ Deutscher Erklärungstext, technische Namen englisch — durchgängig.
- ✅ Keine Dialogform, kein „Ich" — durchgängig.
- ✅ Kennzeichnung „Chat-Befund" / „Quelle (validiert)" / „Bewertung/Empfehlung" — durchgängig und konsistent (Lesehinweis im Kopf erklärt das Muster).
- ✅ Tabellen und Mermaid-Diagramme korrekt; keine kaputten Code-Fences.
- ✅ Erfüllt die 5 Pflichtanforderungen aus Teil D (alle Werte erklärt, alle Kombinationen, exakte Quellen, Gesamtthema verständlich, offene Punkte ehrlich).

## 7. Gesamturteil

**BESTANDEN**

**Begründung:**
- Vollständigkeit: 20/20 C.1-Werte, 12/12 C.2-Kombinationen, 5/5 offene Punkte — alle vorhanden und inhaltlich korrekt.
- Richtigkeit: Kein einziger Widerspruch zur Faktenbasis; alle Zitate wörtlich identisch; alle Zahlen, Turn-Zuordnungen und Quellen exakt.
- Kernrisiken (LED_EFFECT=5-Zuordnung, DOA_VALUE-Ableitung, Haltezeit-Doppelangabe, Legacy-Skript-Abweichung, AEC converged ≠ DOA-Fehler) sind sämtlich korrekt behandelt — genau die Punkte, an denen Marco in Schritt 3 sonst ansetzen würde.
- Alle 6 Funde sind Minor (kosmetisch/präzisierend), keiner erfordert eine inhaltliche Korrektur.

**Zählung der Funde nach Schweregrad:**
- Kritisch: 0
- Mittel: 0
- Minor: 6 (F1–F6)

**Empfehlung für Schritt 2 (Haupt-Assistent):** Die Doku ist **bereit** für Schritt 2. Empfohlen wird, die 6 Minor-Funde als Option zur Kenntnis zu geben (keine Pflicht): F1 (RT60-Einordnung kennzeichnen), F2 („ersetzt bzw. ergänzt" → „bildet nach"), F3 (Quellenspalte LED_EFFECT präzisieren), F4 (expliziter Nicht-DOA-Hinweis bei BRIGHTNESS/GAMMIFY/COLOR), F5 („verbindliche" streichen), F6 („Ausgangszustand" neutraler formulieren). Inhaltlich ist nichts nachzubessern; die Doku ist faktenbasiert, quellentreu und vollständig.
