# Sonderkapitel I: DOA (Direction of Arrival) — Faktenbasis

**Auftraggeber:** Marco (verbindlich)
**Quellen:** Chat-Verlauf Turns 26–32 (`chat_history_lefx_schema_v2---db0c18aa-4ee2-4ce5-94d3-e38e01bf80a5.md`, Z. 3151–3555) + Online-Recherche (abgerufen 2026-08-02)
**Besondere Auflage:** Alle genannten Werte müssen in Bezug auf DOA-Effekt und Erkennung erklärt werden; alle auftauchenden Kombinationen von Werten und deren Bewertung (sofern dem Chat zu entnehmen); fehlende Erklärungen sind online zu recherchieren **mit exakten Quellenangaben**; die Quellen müssen mit-validiert und geprüft werden. Das gesamte Thema DOA, die unterschiedlichen Erkennungsmöglichkeiten und Kombinationen sowie die Einzel-Begriffe der Werte müssen gut verständlich erklärt werden.

---

## Teil A: Fakten aus Turns 26–32 (wörtlich/nah am Chat)

### A.1 Turn 26 — DOA-Debug-Logging (temporär) eingebaut

**Kontext:** Beim Setzen des DOA-Effekts trat ein Fehler auf; der Effekt „steht immer nur auf einer Richtung", bewegt sich nicht. Andere Effekte funktionieren.

**Zitat USER__026 (Befehl + Beschreibung):**
```text
"DOA_VALUE": (20, 18, 2, "ro", "uint16", "Get the doa value and if speech is detected, payload[0] = doa value, from 0 to 359, payload[1] = 1 if speech is detected, 0 if not"),
"LED_RING_COLOR": (20, 19, 12, "rw", "uint32", "Set the LED color of ring mode, each value is the color of one LED"),
```

**Fakten AGENT_026:**
- Temporäre DOA-Protokollierung eingebaut; pro Abfrage werden geschrieben:
```text
DOA DEBUG sample payload=(135, 1) direction_deg=135.0 speech_flag=1 forwarded_state=sound
```
- Ungültige Payloads oder Winkel werden ebenfalls protokolliert.
- Das Speech-Flag wird nur angezeigt, **aber weiterhin nicht ausgewertet**.
- Verifikation: 166 bestandene Tests; nichts committet/gepusht.

### A.2 Turn 27 — Verwaisten Service-Prozess beendet + Cleanup

**Kontext:** „die logs laufen weiter, trotz python" — der Service lief als verwaister Python-Kindprozess weiter.

**Fakten AGENT_027:**
- Service regulär beendet; Log endete um 23:15:57; Ports 8765–8770 sind frei.
- Studio beendet den gesamten Service-Prozessbaum bei abruptem Schließen automatisch über ein Windows-Jobobjekt; zusätzlich `closeEvent`, `aboutToQuit`, `finally`-Cleanup.
- Abbruchtest erfolgreich: Service überlebt selbst `os._exit()` des Studios nicht.
- 167 Tests bestanden; temporäre DOA-Wertausgaben bleiben aktiv.

### A.3 Turn 28 — DOA-Trägheit: Abtastrate + Interpolation auf 12 LEDs

**Kontext (USER__028):** „der nach einer kurzen Weile, nachdem der zwei, dreimal hin und her springt, irgendwie festhängt. Oder die Werte sich nicht mehr richtig aktualisieren." Hardware-Problem ausgeschlossen (darunterliegender State dreht sich weiter). „Was hat der denn momentan für eine Abtastrate?"

**Fakten AGENT_028:**
- Renderloop: **30 FPS**, ein Durchlauf etwa alle **33 ms**.
- DOA-Abfrage aktuell `interval_ms=125` → real etwa **7–8 Abfragen pro Sekunde**.
- Pull-Abfragen sind an Renderframes gekoppelt → beliebige Zwischenraten nicht exakt möglich.
- Bei `50 ms` → praktisch eher ~15 Hz (Prüfung nur alle 33 ms).
- `interval_ms=0` → eine Abfrage pro Frame → maximal ~30 Hz.
- Praktische Grenzen: 30 LED-Schreibvorgänge + 30 DOA-Lesevorgänge = ~60 USB-Control-Transfers/s. Datenmenge winzig; kritischer sind ReSpeaker-Verarbeitung, USB-Latenzen, serielle Ausführung im Renderthread. Der Treiber hat einen sehr großzügigen Timeout und bis zu 100 Wiederholungsversuche → problematischer Transfer kann den Renderloop länger blockieren.
- **12 LEDs** → 360°/12 = **30° pro LED**. Winkel 81°→88°→95° kann weiterhin dieselbe LED wählen → Effekt sieht festgefahren aus, obwohl sich der DOA-Wert laufend ändert. Erklärt erheblichen Teil der wahrgenommenen Schwerfälligkeit.
- Vorschlag: (1) testweise 50 ms (~15 Hz), (2) USB-Lesedauer + Alter des letzten Winkels protokollieren, (3) **Richtungsindikator zwischen zwei benachbarten LEDs interpolieren** (je näher an der nächsten LED, desto heller), (4) nicht direkt auf 30 Abfragen/s gehen.

### A.4 Turn 29 — USB-Grenzen + LED-Frame-Diff-Optimierung

**Fragen USER__029:** (1) Was passiert, wenn man die Grenze überschreitet — kann etwas kaputtgehen? (2) Bei 30 LED-Schreibvorgängen/s: pro LED abgleichen, ob sich etwas ändert, und nur notwendige schreiben?

**Fakten AGENT_029:**
- **Kaputtgehen:** Physischer Hardwaredefekt sehr unwahrscheinlich. `DOA_VALUE` liest nur einen flüchtigen Laufzeitwert, `LED_RING_COLOR` schreibt den aktuellen LED-Puffer; kein Flash-Schreiben → kein relevanter Speicher-Verschleiß.
- Folgen zu hoher Rate: Service erreicht FPS nicht mehr; LED-Animationen ruckeln/verzögern; USB-Transfers liefern Retry, Timeout oder Stall; ReSpeaker reagiert zeitweise nicht und muss evtl. per USB neu verbunden werden; im ungünstigsten Fall blockiert der Renderthread längere Zeit.
- Treiber wiederholt Firmware-`RETRY` bis zu 100-mal; alles synchron → Controller bleibt stehen statt Anfragen aufzustauen (schützt vor unkontrollierter Überlastung, kann aber sichtbaren Stillstand verursachen).
- **LED_RING_COLOR ist EIN USB-Transfer** mit zwingend allen 12 Farben: `12 × uint32 = 48 Byte`. Keine Möglichkeit, nur einzelne LEDs zu aktualisieren. Sobald sich eine LED ändert, muss der vollständige Ringpuffer übertragen werden.
- Frame-Diff-Vorschlag (umgesetzt als Optimierung):
```python
if frame.leds == previous_leds:
    return
device.write("LED_RING_COLOR", frame.leds)
previous_leds = list(frame.leds)
```
- Wirkung: statischer Ring → nach erstem Frame keine weiteren LED-Transfers; langsame quantisierte Animation → identische Zwischenframes übersprungen; flüssige Animation → weiterhin bis zu 30 Transfers/s.
- Hinweis: Im aktuellen Test dreht sich der darunterliegende State weiter; Engine rechnet erst alle Layer zusammen und sendet dann den vollständigen Endframe → diese Optimierung spart dort nur wenig.
- Datenmenge ~1,4 KB/s bei 30 FPS unkritisch; relevant sind Anzahl USB-Control-Transfers und Firmware-Verarbeitungszeit.
- Empfehlung: identische Gesamtframes nicht erneut übertragen; DOA 50 ms; Lesen/Schreiben seriell; USB-Laufzeiten und Fehler protokollieren; interpolieren. 30 Hz beschädigt nichts, ist aber vermutlich unnötig.

### A.5 Turn 30 — DOA-Wertegrundlage: AEC Auto-selected Beam vs. DOA_VALUE

**Kontext (USER__030):** Der originale Door-Effekt (im ReSpeaker gespeichert) funktioniert richtig gut — „da ist Bewegung drin", Anzeige nur während Geräuschen; Wanduhr-Beispiel: Sekundenzeiger lässt die LED einmal pro Sekunde kurz aufblinken.

**Fakten AGENT_030:**
- **Nein, nicht exakt dieselbe Wertegrundlage.** Der interne ReSpeaker-DOA-Modus arbeitet direkt innerhalb der Firmware; laut offizieller Dokumentation verwendet die eingebaute DOA-Anzeige den **vierten Wert von `AEC_AZIMUTH_VALUES`, also den Auto-selected beam** (vom internen Beamforming-System ausgewählt).
- Unsere Implementierung verwendete damals: `DOA_VALUE[0]` = ganzzahliger Winkel, `DOA_VALUE[1]` = Aktivitäts-/Speech-Flag. `payload[1]` wurde vollständig ignoriert; dem Effekt wurde immer `"detection_state": "sound"` gemeldet → zuletzt gemessener Winkel bleibt dauerhaft sichtbar → sieht wie Festhängen aus.
- Vorteile des internen Effekts: direkter Zugriff auf interne DSP-/Beamforming-Werte; keine USB-Abtastverzögerung; vermutlich Aktualisierung mit dem internen Audiotakt; Zugriff auf Auto-selected beam; Aktivitätsinformationen über die Beam-Energie; Anzeige nur während erkannter Aktivität.
- `AEC_SPENERGY_VALUES`: dessen **vierter Wert** beschreibt die Speech-Energie des Auto-selected beam. Wert über null = erkannte Aktivität; höhere Werte ≈ lauteres/näheres Signal. Passt zur Wanduhr-Beobachtung.
- Arbeitsweise des internen Effekts:
```text
kurzes Geräusch erkannt
→ Auto-selected beam bestimmt Richtung
→ LED an dieser Richtung kurz einschalten
→ bei fehlender Energie wieder ausblenden
```
- Einordnung: `DOA_VALUE` kann intern durchaus aus demselben Beamforming-System abgeleitet sein; die Dokumentation garantiert aber nicht, dass es exakt derselbe Wert mit demselben Aktualisierungs-/Aktivitätsverhalten ist. Dokumentiert ist ausdrücklich der Auto-selected beam als Grundlage der internen LED-Anzeige.
- Vorschlag: Vergleichsprovider, der gleichzeitig protokolliert: `DOA_VALUE`, `AEC_AZIMUTH_VALUES[3]`, `AEC_SPENERGY_VALUES[3]`. Ziel-Provider: `AEC_AZIMUTH_VALUES[3]` als Richtung und `AEC_SPENERGY_VALUES[3]` als Aktivität; kurze Haltezeit ~100–200 ms, dann ausblenden.

### A.6 Turn 31 — 30-Hz-DOA-Telemetrie bestätigt + Bedingungen

**Kontext (USER__031):** In der offiziellen ReSpeaker-App kann man bis 30 Hz auswählen. „Dann sollten wir eigentlich kein Problem kriegen, ne?"

**Fakten AGENT_031:**
- 30 Hz Live Telemetry in der offiziellen ReSpeaker Console = starkes Indiz, dass der ReSpeaker regelmäßige Telemetrieabfragen mit 30 Hz verträgt. Die App liest nicht nur einen Winkel, sondern zeigt gleichzeitig DOA, Voice Activity und Beam-Energien.
- **30 DOA-Abfragen/s sind grundsätzlich plausibel und geräteseitig vorgesehen.** Keine Beschädigung zu erwarten. LED-Ausgabe mit 48 Byte/Frame klein. Schlimmstenfalls verzögerte Frames, USB-Retries oder vorübergehend hängender Service.
- **Drei wichtige Bedingungen:**
  1. **ReSpeaker Console und LED-Controller dürfen nicht gleichzeitig zugreifen** — genau solche parallelen Prozesse hatten bereits `USBError: Entity not found`-Fehler verursacht.
  2. **Nur eine Hardwareabfrage pro Frame** — momentan könnte theoretisch jedes aktive Pull-Overlay seinen Provider separat aufrufen (bei mehreren DOA-Overlays: 60–90 USB-Abfragen). Der Provider sollte zentral pro Renderframe cachen und allen Effekten denselben Messwert liefern.
  3. **DOA-Lesen und LED-Schreiben seriell lassen** — keine konkurrierenden USB-Threads, keine unkontrollierte Warteschlange.
- Ziel-Einstellung:
```text
Renderfrequenz:       30 Hz
DOA-Abfrage:          einmal pro Renderframe
Maximale DOA-Reads:   30 pro Sekunde
LED-Ausgabe:          nur bei verändertem Gesamtframe
Provider-Cache:       ein Messwert pro Frame für alle DOA-Effekte
```
- Die offizielle App verwendet neben der Richtung ausdrücklich **Voice Activity** und **Beam Energy** → Aktivität und Richtung müssen gemeinsam ausgewertet werden.

### A.7 Turn 32 — DOA_VALUE entschlüsselt: Winkel + VAD-Flag

**Kontext (USER__032):** 4 Screenshots der ReSpeaker-App (Parameter-Tabs) übergeben.

**Fakten AGENT_032:**
- **Zentrale Erkenntnis:** In der Parameteransicht steht ausdrücklich:
```text
DOA_VALUE
uint16 x2
DoA value [0..359] and VAD flag
```
- Der zweite Wert ist **kein** Ergebnis einer Spracherkennung (Speech-to-Text), sondern ein **VAD-Flag: Voice Activity Detection**.
- Aktuelle (damalige) Implementierung: `payload[0]` → Winkel, `payload[1]` → ignorieren, `detection_state` → immer `"sound"`. Sehr wahrscheinliche Ursache für den Festhänge-Eindruck: Wenn kein relevantes Geräusch aktiv ist, behält `payload[0]` offenbar einfach die zuletzt erkannte Richtung.
- Interner Effekt vermutlich:
```text
VAD = 1 → Richtung anzeigen
VAD = 0 → Richtungsanzeige ausblenden
```
- **Monitorwerte (Screenshot 1):**
```text
Direction of arrival: 266°
Voice activity: Active
Max beam energy: 26426.47
Beam 1: 26426.47
Beam 3: 26426.47
```
- Beam 3 = laut offizieller Dokumentation der Auto-selected beam. Beam 1 = Beam 3 (gleicher Energiewert) bedeutet vermutlich: Beam 1 wurde aktuell als bester Beam ausgewählt und auf Beam 3 durchgereicht. Die interne DOA-Anzeige verwendet genau diesen Auto-selected beam.
- **Zusammenhang der Werte:**
```text
AEC_AZIMUTH_VALUES[3]  → genauer Winkel des ausgewählten Beams
AEC_SPENERGY_VALUES[3] → Energie dieses Beams
DOA_VALUE[0]           → vereinfachter Winkel für Anwendungen
DOA_VALUE[1]           → vereinfachtes VAD-Flag
```
- `DOA_VALUE` scheint die praktische, zusammengefasste Schnittstelle für Anwendungen zu sein; nicht zwingend sofort auf die ausführlichen AEC-Wertesätze wechseln.
- **30 Hz:** Die Konsole überwacht bei 30 Hz gleichzeitig DOA, VAD, vier Beam-Energien, RT60, AEC-Status → bestätigt, dass 30-Hz-Telemetrie mit Firmware **2.0.10** vorgesehen ist.
- **Interner LED-Effekt (Parameteransicht):**
```text
LED_EFFECT = 4       → interner DOA-Modus
LED_EFFECT = 5       → frei gesetzter Ringmodus
LED_DOA_COLOR        → Grundfarbe und Highlight-Farbe
```
  - Base color: `#002040`; Highlight: `#00C066` → Grundring + bei VAD-Aktivität hervorgehobene Richtung.
- `LED_SPEED` ist laut Protokolldokumentation primär für Breath und Rainbow gedacht; Wert `8` ist daher wahrscheinlich nicht die Reaktionsgeschwindigkeit der DOA-Auswertung.
- **Audioeinstellungen:** Noise Suppression, AGC, Echo Suppression, Double-talk Sensitivity können beeinflussen, was der DSP als Aktivität oder guten Beam bewertet. Vorerst nicht verändern; insbesondere nicht auf **Save to Flash** klicken. `AEC converged: No` ist allein kein DOA-Fehler (betrifft primär Echo-Unterdrückung und Far-End-Referenz).
- **Konkrete Korrektur (nächste Implementierungsschritte):**
  1. DOA einmal pro Renderframe abfragen (bei 30 FPS max. 30 Hz).
  2. VAD-Flag nicht mehr ignorieren: `0` → `detection_state="none"`, `1` → `detection_state="sound"`.
  3. Ohne VAD die Richtungsanzeige transparent machen.
  4. Optional sehr kurze Haltezeit ~70–150 ms anbieten.
  5. Providerwerte einmal pro Frame cachen (auch bei mehreren DOA-Effekten).
  6. Identische LED-Gesamtframes nicht erneut übertragen.
  7. `AEC_AZIMUTH_VALUES` und `AEC_SPENERGY_VALUES` zunächst nur zusätzlich diagnostisch vergleichen.

---

## Teil B: Online-Recherche (abgerufen 2026-08-02, validiert)

### B.1 Quelle 1 — Offizielle ReSpeaker-Dokumentation (GitHub README)
**URL:** https://github.com/respeaker/reSpeaker_XVF3800_USB_4MIC_ARRAY/blob/master/host_control/README.md

**Bestätigte Fakten (wörtlich/nah):**
- `AEC_AZIMUTH_VALUES` (Read Only, 4 Params, radians): „The command outputs four values: Focused beam 1, Focused beam 2, Free running beam, Auto selected beam. Each value represents the azimuth angle of the corresponding beam, provided in both radians and degrees. **The DoA indication uses the last value (Auto selected beam).**"
  - Beispiel: `AEC_AZIMUTH_VALUES 0.91378 (52.36 deg) 0.00000 (0.00 deg) 1.57080 (90.00 deg) 0.91378 (52.36 deg)`
  - Hinweis: Beamforming-Beschreibung: „the system uses an array of beams to focus on speakers, reducing unwanted sounds and reverberation… The XVF3800 employs a free-running beam that scans the environment, identifies potential speakers, and switches one of the two focused beams to that direction. During normal operation, the audio processing pipeline automatically selects the best signal for output (Auto selected beam)."
- `AEC_SPENERGY_VALUES` (Read Only, 4 Params): „Speech Energy is a value that indicates whether speech is present in the beam as well as the amplitude, which is similar to VAD (Voice Activity Detection). **Non-zero spenergy means that the beam probably contains speech. Higher values indicate louder or closer speech**, however noise, echo and reverb can cause the energy level to decrease." Reihenfolge identisch: Focused beam 1, Focused beam 2, Free running beam, Auto selected beam.
  - Beispiel: `AEC_SPENERGY_VALUES 2080656 0 2083455 2080656`
- `LED_EFFECT` (RW, 1, uint8): „Set the LED effect mode, 0 = off, 1 = breath, 2 = rainbow, 3 = single color, **4 = doa**".
- `LED_BRIGHTNESS` (RW, 1, uint8): Helligkeit für breath/rainbow.
- `LED_GAMMIFY` (RW, 1, uint8): Gamma-Korrektur 0/1.
- `LED_SPEED` (RW, 1, uint8): „Set the effect speed of breath and rainbow mode".
- `LED_COLOR` (RW, 1, uint32): Farbe für breath und single color.
- `LED_DOA_COLOR` (RW, 2, uint32): „Set the LED color of doa mode, the first value is the base color and the second value is the doa color".
- Standardverhalten: „By default, reSpeaker XVF3800 runs rainbow mode when boot, and then switch to doa mode after 2 seconds."
- `SAVE_CONFIGURATION` / `CLEAR_CONFIGURATION`: speichert/löscht alle schreibbaren Parameter im Flash.
- DoA-Winkeldiagramm: https://github.com/respeaker/reSpeaker_XVF3800_USB_4MIC_ARRAY/blob/master/doc/doa.jpg
- Verweise auf XMOS-Dokumentation: beamforming-subsystem + beamformer (siehe Quelle 2).
- **Wichtige Abweichung zur Chat-Aussage:** Die README listet für `LED_EFFECT` nur 0–4. Der im Chat (Turn 32) genannte Wert **`LED_EFFECT = 5` („frei gesetzter Ringmodus") ist in der öffentlichen README nicht dokumentiert** — vermutlich firmware-/app-spezifisch (Firmware 2.0.10). Als solche kennzeichnen: Chat-Beobachtung, offiziell nicht in der README belegt.

### B.2 Quelle 2 — XMOS XVF3800-Dokumentation (v3.2.1)
**URL:** https://www.xmos.com/documentation/XM-014888-PC/html/modules/fwk_xvf/doc/user_guide/03_using_the_host_application.html

**Bestätigte Fakten:**
- Beam-Subsystem: „The XVF3800 uses a free running beam that scans the environment, identifies likely speakers and switches one of the two focused beams to that direction. In normal operation the audio pipeline automatically selects the best signal to output."
- `AEC_AZIMUTH_VALUES`: 4 Werte in gleicher Reihenfolge; je Azimut in Radian und Grad. Koordinatensystem hängt von der Hardware-Konfiguration ab: **lineare Konfiguration nur 0–180°, quadratische Konfiguration 0–360°**.
- `AEC_SPENERGY_VALUES`: 4 Gleitkommawerte, gleiche Beam-Zuordnung; „Non-zero spenergy means that the beam probably contains speech. Higher values indicate louder or closer speech, however noise, echo and reverb can cause the energy level to decrease."
- **Zusätzliche Erkenntnis (`AUDIO_MGR_SELECTED_AZIMUTHS`):** XVF3800 „computes an additional azimuth value which combines speech energy and azimuths to provide a single value which indicates the direction and presence of a speaker. This value can be read using the command `AUDIO_MGR_SELECTED_AZIMUTHS`. The command returns 2 values, the first of which is the processed azimuth which will be NAN if there is no speech, otherwise it will be the azimuth of the current speaker. The second is the current azimuth of the auto select beam."
- Fixed-Beam-Modus (für bekannte, feste Sprecherpositionen): `AEC_FIXEDBEAMSAZIMUTH_VALUES`, `AEC_FIXEDBEAMSELEVATION_VALUES`, `AEC_FIXEDBEAMSONOFF`, `AEC_FIXEDBEAMNOISETHR`, `AEC_FIXEDBEAMSGATING` (bei aktivem Gating werden Fixed Beams mit niedriger Speech-Energie gemutet; nur ein Fixed Beam gleichzeitig aktiv). Hinweis: „the azimuth angle provided by the DoA function is dependent on the measurements of the acoustic path" → Werte können von festen Beam-Azimuten abweichen.
- Auto-Selection-Verhalten: „The auto selection algorithm will switch between beams rapidly in some circumstances. The two focused beams update relatively slowly, but the free running beam is designed to be sensitive so that it can rapidly pick up the speech signal for a new talker entering the soundscape. As a result it can also pick up any noise signals present."
- Audio-Mux (AUDIO_MGR_OP_L/R): Kategorie 6, Quelle 3 = „The 'auto-select' beam; chooses the best of the previous three beams as an output, recommended option" — bestätigt die „durchgereichte"-Interpretation aus Turn 32.

### B.3 Quelle 3 — Offizielles xvf_host.py (python_control)
**URL:** https://github.com/respeaker/reSpeaker_XVF3800_USB_4MIC_ARRAY/blob/master/python_control/xvf_host.py

**Bestätigte Fakten (wörtlich):**
```python
"DOA_VALUE": (20, 18, 2, "ro", "uint16", "Get the doa value and if speech is detected, payload[0] = doa value, from 0 to 359, payload[1] = 1 if speech is detected, 0 if not"),
"LED_RING_COLOR": (20, 19, 12, "rw", "uint32", "Set the LED color of ring mode, each value is the color of one LED"),
```
→ Die im Chat (Turn 26) zitierten Definitionen sind **wörtlich identisch** mit der offiziellen Datei. ✅

### B.4 Quelle 4 — Offizielles Beispielskript respeaker_get_doa.py (python_control)
**URL:** https://github.com/respeaker/reSpeaker_XVF3800_USB_4MIC_ARRAY/blob/master/python_control/respeaker_get_doa.py

**Bestätigte Fakten:**
```python
PARAMETERS = {
    "VERSION": (48, 0, 3, "ro", "uint8"),
    "AEC_AZIMUTH_VALUES": (33, 75, 16, "ro", "radians"),
    "DOA_VALUE": (20, 18, 4, "ro", "uint16"),
    "REBOOT": (48, 7, 1, "wo", "uint8"),
}
# main():
result = dev.read("DOA_VALUE")
print('{}: {}, {}: {}'.format("SPEECH_DETECTED", result[3], "DOA_VALUE", result[1]))
```
- **Abweichung:** Dieses Beispielskript deklariert `DOA_VALUE` mit **Länge 4** (statt 2 wie xvf_host.py) und liest `result[3]` als SPEECH_DETECTED, `result[1]` als DOA_VALUE. Hinweis: Die `read()`-Methode fügt 1 Status-Byte hinzu (`length = data[2] + 1`) und liefert bei uint16 `response.tolist()` → Index-Konventionen hier (1 und 3) deuten auf einen zusätzlichen Status-Offset. **Die Chat-/xvf_host.py-Variante (payload[0] = Winkel, payload[1] = VAD, Länge 2) ist die für unsere Implementierung maßgebliche; die Skript-Variante (Länge 4) muss als abweichende Legacy-Konvention dokumentiert werden.** Dies ist ein expliziter Prüfpunkt für die Quellenvalidierung.

### B.5 Quelle 5 — Seeed Studio Wiki (Produktübersicht)
**URL:** https://wiki.seeedstudio.com/respeaker_xvf3800_introduction

**Bestätigte Fakten:**
- „The ReSpeaker XVF3800 USB 4-Mic Array is a professional 4-mic circular array with XMOS XVF3800, featuring AEC, AGC, DoA, beamforming, VAD, noise suppression, de-reverberation, **360° voice capture (up to 5m)**."
- Firmware-Versionen im offiziellen GitHub-Repo; Beispiel `VERSION: [2, 0, 7]`; DoA-Beispiel `python xvf_host.py DOA_VALUE`.
- 4-Mikrofon-Anordnung: kreisförmig (quadratische Geometrie) → 0–360°.

---

## Teil C: Wert- und Kombinationsübersicht (Pflicht für das Kapitel)

### C.1 Einzelwerte (alle erklären)
| Wert/Kommando | Typ/Format | Bedeutung | Quelle |
|---|---|---|---|
| `DOA_VALUE[0]` | uint16, 0–359 | Vereinfachter Richtungswinkel (Grad) | Chat T26/T32, xvf_host.py |
| `DOA_VALUE[1]` | uint16 | VAD-Flag (1 = Sprachaktivität, 0 = keine) | Chat T32, xvf_host.py |
| `AEC_AZIMUTH_VALUES[0..2]` | float radians | Azimut Focused beam 1/2, Free running beam | README, XMOS |
| `AEC_AZIMUTH_VALUES[3]` | float radians | Azimut Auto selected beam (Grundlage der internen DOA-Anzeige) | README, XMOS |
| `AEC_SPENERGY_VALUES[0..2]` | float | Speech-Energie Focused 1/2, Free running | README, XMOS |
| `AEC_SPENERGY_VALUES[3]` | float | Speech-Energie Auto selected beam (>0 = Aktivität, höher = lauter/näher) | README, XMOS |
| `LED_RING_COLOR` | 12 × uint32 = 48 B | Kompletter Ringpuffer (alle 12 LEDs, ein USB-Transfer) | Chat T26, xvf_host.py |
| `LED_EFFECT` | uint8 | 0=off, 1=breath, 2=rainbow, 3=single color, 4=doa (5=Ringmodus nur laut App, nicht in README) | README, Chat T32 |
| `LED_DOA_COLOR` | 2 × uint32 | Base color + DOA/Highlight-Farbe (Beispiel: #002040 / #00C066) | README, Chat T32 |
| `LED_SPEED` | uint8 | Effektgeschwindigkeit für breath/rainbow (nicht DOA-Reaktionszeit) | README, Chat T32 |
| `LED_BRIGHTNESS` | uint8 | Helligkeit breath/rainbow | README |
| `LED_GAMMIFY` | uint8 | Gamma-Korrektur 0/1 | README |
| `LED_COLOR` | uint32 | Farbe breath/single color | README |
| `AUDIO_MGR_SELECTED_AZIMUTHS[0]` | float | Verarbeiteter Azimut (NAN = keine Sprache) | XMOS |
| `AUDIO_MGR_SELECTED_AZIMUTHS[1]` | float | Aktueller Azimut des Auto-select-Beams | XMOS |
| `detection_state` | String | `"sound"`/`"none"` (VAD-Auswertung) | Chat T26/T32 |
| `interval_ms` | Zahl | DOA-Abtastintervall (125 → ~7–8 Hz, 50 → ~15 Hz, 0 → max. 30 Hz) | Chat T28 |
| Renderfrequenz | FPS | 30 FPS (~33 ms/Durchlauf) | Chat T28 |
| Beam-Energien (Monitor) | float | z. B. Max beam energy 26426.47; Beam 1 = Beam 3 | Chat T32 |
| RT60 / AEC-Status | — | von der Console bei 30 Hz mitüberwacht; `AEC converged: No` ≠ DOA-Fehler | Chat T32 |

### C.2 Kombinationen und deren Bewertung (Pflicht für das Kapitel)
1. **`DOA_VALUE[0]` + `DOA_VALUE[1]` (Winkel + VAD):** VAD=1 → Richtung anzeigen; VAD=0 → Anzeige ausblenden. Bewertung im Chat: Das Ignorieren von `payload[1]` bei gleichzeitigem Festhalten des letzten Winkels ist die wahrscheinlichste Ursache des „Festhängens". Korrektur: `0` → `detection_state="none"`, `1` → `detection_state="sound"`; ohne VAD Richtung transparent.
2. **`AEC_AZIMUTH_VALUES[3]` + `AEC_SPENERGY_VALUES[3]` (Auto-selected beam: Richtung + Energie):** Energie > 0 → Aktivität; höhere Energie ≈ lauter/näher; Richtung = Azimut des Auto-selected beam. Dies ist die Wertegrundlage des internen Effekts; für den Nachbau die empfohlene Zielkombination (mit Haltezeit 100–200 ms).
3. **Beam-Energie-Gleichheit (Beam 1 = Beam 3):** Deutung: Beam 1 als bester Beam ausgewählt und auf Beam 3 (Auto selected) durchgereicht → interne DOA-Anzeige nutzt genau diesen Wert.
4. **`DOA_VALUE` vs. `AEC_*`-Werte:** DOA_VALUE = vereinfachte, zusammengefasste Anwendungsschnittstelle (Winkel + VAD); AEC-Werte = ausführliche Rohwerte (Richtung + Energie aller 4 Beams). Empfehlung: erst mit DOA_VALUE arbeiten, AEC-Werte diagnostisch vergleichen.
5. **12-LED-Ring + Winkelquantisierung:** 360°/12 = 30° pro LED; kleine Winkeländerungen (81°→88°→95°) wählen ggf. dieselbe LED → scheinbares Festhängen. Bewertung: Interpolation zwischen benachbarten LEDs macht kleine Änderungen sichtbar.
6. **Abtastrate + Renderloop:** Pull-Abfragen an Renderframes gekoppelt → exakte Zwischenraten unmöglich; `interval_ms=0` = 1×/Frame = max. 30 Hz; 50 ms ≈ 15 Hz (Empfehlung für Test).
7. **USB-Gesamtlast:** 30 LED-Writes + 30 DOA-Reads = ~60 Control-Transfers/s; Datenmenge winzig (~1,4 KB/s), kritisch sind Transferanzahl + Firmware-Verarbeitung; seriell ausführen.
8. **Frame-Diff + Layer-Komposition:** Engine rechnet alle Layer zusammen; nur veränderte Gesamtframes senden (`if frame.leds == previous_leds: return`); bei bewegtem State darunter spart das wenig.
9. **30 Hz + drei Bedingungen:** (a) kein paralleler Zugriff mit ReSpeaker Console (sonst `USBError: Entity not found`), (b) genau eine Hardwareabfrage pro Frame + Provider-Cache, (c) Lesen/Schreiben seriell. Nur so ist 30 Hz stabil.
10. **Haltezeit (70–150 ms bzw. 100–200 ms):** kurze Haltezeit + Ausblenden bildet das Verhalten des internen Effekts nach (Wanduhr-Beispiel: kurzes Aufblinken).
11. **Audioeinstellungen (Noise Suppression, AGC, Echo Suppression, Double-talk Sensitivity):** beeinflussen, was der DSP als Aktivität/guten Beam bewertet; nicht ohne Not ändern, nicht „Save to Flash"; `AEC converged: No` betrifft Echo-Unterdrückung, nicht DOA.
12. **`LED_EFFECT=4` + `LED_DOA_COLOR`:** interner DOA-Modus mit Base-/Highlight-Farbe; `LED_EFFECT=5` laut App „frei gesetzter Ringmodus" (nur Chat, nicht README).

### C.3 Offene Punkte / zu kennzeichnende Unsicherheiten
- `LED_EFFECT=5` (Ringmodus): nur aus App-Screenshots (Chat T32); in der öffentlichen README nicht dokumentiert → als Chat-Beobachtung kennzeichnen.
- `respeaker_get_doa.py` (Länge 4, Indizes 1/3) vs. `xvf_host.py` (Länge 2, Indizes 0/1): abweichende Legacy-Konvention; maßgeblich für unsere Implementierung ist die xvf_host.py-Variante.
- Exakte Aktualisierungsrate des internen Effekts („vermutlich interner Audiotakt") ist im Chat nur vermutet, nicht verifiziert.
- Ob `DOA_VALUE` exakt dem Auto-selected beam entspricht, ist offiziell nicht garantiert (nur abgeleitet möglich) → als offen kennzeichnen.

---

## Teil D: Anforderungen an das Sonderkapitel (Marco, verbindlich)

1. **Alle genannten Werte** (Teil C.1) in Bezug auf DOA-Effekt und Erkennung erklären — verständlich für jemanden, der das System nicht kennt.
2. **Alle auftauchenden Kombinationen** (Teil C.2) und deren Bewertung darstellen, soweit dem Chat zu entnehmen.
3. **Online-recherchierte Fakten** nur mit exakten Quellenangaben (Teil B); die Quellen selbst werden mit-validiert.
4. Das gesamte Thema DOA: unterschiedliche Erkennungsmöglichkeiten (DOA_VALUE, AEC_AZIMUTH/SPENERGY, AUDIO_MGR_SELECTED_AZIMUTHS, interner Effekt), Kombinationen und Einzelbegriffe gut verständlich erklären.
5. **Strenge Validierung in 3 Schritten:** (1) unabhängiger Subagent mit Detailauftrag, (2) Haupt-Assistent mit denselben Vorgaben, (3) Marco selbst. Für alles, was Marco findet, muss eine Rechtfertigung geliefert werden, warum es entgangen ist.
6. Stil wie bisherige Kapitel: deutscher Erklärungstext, technische Namen englisch, Tabellen/Mermaid-Diagramme, klare Kennzeichnung von Fakten (Chat vs. Quelle), Quellenangaben als Fußnoten-/Literaturliste.
