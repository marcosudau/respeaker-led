# Vergleich: Strenge Variante vs. Normal-Variante — Sonderkapitel I: DOA

**Datum:** 2026-08-02
**Anlass:** Marco möchte den Unterschied zwischen der verschärften Sonder-Vorgehensweise (3-stufige Validierung, Online-Quellen) und dem normalen Ablauf (wie Kapitel 1–12) besser einordnen können.
**Vergleichspartner:**
- **Streng:** `sonderkapitel_doa_doku_final.md` (520 Zeilen, 44 027 B) — auf Basis `sonderkapitel_doa_bereich.md` (298 Zeilen, 28 714 B)
- **Normal:** `sonderkapitel_doa_doku_normal_runde1.md` (356 Zeilen, 19 858 B) — auf Basis `sonderkapitel_doa_bereich_normal.md` (126 Zeilen, 13 359 B)

---

## 1. Unterschiede im Prozess/Ablauf

| Aspekt | Normal (Kapitel 1–12) | Streng (Sonderkapitel I) |
|---|---|---|
| **Faktenbasis** | Nur Chat-Verlauf: Ziel, Gliederung, Schwerpunkte, Entscheidungen | Chat-Verlauf **plus** Online-Recherche mit validierten Quellen (Teil B), Werte-/Kombinations-/Offene-Punkte-Kataloge (Teil C), Anforderungskatalog (Teil D) |
| **Faktenbasis-Umfang** | 126 Zeilen / 13 KB | 298 Zeilen / 29 KB (mehr als doppelt) |
| **Schreibauftrag** | Standard: „Nutze ausschließlich die Fakten der Bereichsdatei. Keine Recherche nötig." | Verschärft: Alle Werte bzgl. DOA-Effekt/Erkennung erklären, alle Kombinationen + Bewertungen, Online-Fakten **nur mit exakten Quellenangaben**, Quellen mit-validieren, offene Punkte ehrlich kennzeichnen |
| **Subagenten-Ausführung** | Max. 3 parallel | **Einzeln** (einer nach dem anderen) |
| **Validierung** | 1-stufig: Fakten-Check + Qualitäts-Check (Runde 1 → direkt final) | **3-stufig:** (1) unabhängiger Validierungs-Subagent, (2) Haupt-Assistent mit gleichen Vorgaben, (3) Marco selbst |
| **Fund-Behandlung** | Redaktionelle Korrekturen direkt einpflegen + transparent im Protokoll | Zusätzlich: **Rechtfertigungspflicht** — für alles, was Marco findet, muss begründet werden, warum es übersehen wurde |
| **Quellenvalidierung** | Keine (Quellen sind der Chat selbst) | Jede Online-Quelle wird mitgeprüft; Chat-Aussagen werden gegen offizielle Doku abgeglichen |
| **Ergebnis** | `_runde1.md` → direkt `_final.md` | `_runde1.md` → 3 Protokolle (`_schritt1`, `_schritt2`, `_korrekturen_minor`) → `_final.md` |

## 2. Unterschiede im Ergebnis (inhaltlich)

| Thema | Normal sagt… | Streng sagt… | Mehrwert der strengen Variante |
|---|---|---|---|
| **`LED_EFFECT = 5`** | „frei gesetzter Ringmodus" (als Fakt) | „nur aus App-Screenshots; **in der offiziellen README nicht dokumentiert** (dort nur 0–4)" | ✅ Diskrepanz aufgedeckt: Wert 5 ist chat-only/firmware-gebunden, kein offizieller Modus |
| **`DOA_VALUE`-Definition** | Chat-Zitat | Chat-Zitat **wörtlich in offizieller `xvf_host.py` verifiziert** | ✅ Externe Bestätigung der Quelle |
| **`respeaker_get_doa.py`** | nicht erwähnt | **Diskrepanz dokumentiert:** Beispielskript nutzt Länge 4 + Indizes 1/3 statt Länge 2 + 0/1 (Legacy-Konvention) | ✅ Warnt vor inkonsistenten Beispielen im offiziellen Repo |
| **AEC-Werte-Reihenfolge** | 4. Wert = Auto-selected beam (Chat-Behauptung) | **Offiziell belegt:** README + XMOS-Doku bestätigen Reihenfolge und „DoA indication uses the last value" | ✅ Chat-Behauptung extern abgesichert |
| **`AUDIO_MGR_SELECTED_AZIMUTHS`** | nicht erwähnt | **Zusätzliche Erkennungsmöglichkeit** dokumentiert (NAN = keine Sprache, Wert 2 = Auto-select-Azimut) — im Chat NICHT genannt | ✅ Vollständigkeit des Gesamtsystems |
| **Beamforming-Grundlagen** | nur implizit (Auto-selected beam) | Eigener Abschnitt: Free running beam, Focused beams, Auto selected beam + Audio-Mux (Quelle 3) | ✅ Verständnis des Gesamtsystems |
| **Koordinatensystem** | nicht erwähnt | linear 0–180° / square 0–360° (XMOS) | ✅ Einordnung der Winkelwerte |
| **Fixed-Beam-Modus** | nicht erwähnt | Vollständigkeitshalber dokumentiert (nur Hinweis) | ✅ Abgrenzung zu anderen Modi |
| **`LED_BRIGHTNESS`/`LED_GAMMIFY`/`LED_COLOR`/`SAVE_CONFIGURATION`** | nicht erwähnt | In LED-Parameterübersicht ergänzt | ✅ Vollständige Parameter-Referenz |
| **Standard-Verhalten** | nicht erwähnt | „rainbow beim Boot, nach 2 s doa" (README) | ✅ Kontext des Geräteverhaltens |
| **Kennzeichnung** | nur implizit („laut offizieller Dokumentation…") | Durchgängig **„Chat-Befund" / „Quelle (validiert)" / „Bewertung/Empfehlung"** mit Quellenkürzeln [Q1]–[Q6] | ✅ Nachvollziehbarkeit jeder Aussage |
| **Umfang** | 356 Zeilen / 19,9 KB | 520 Zeilen / 44 KB (+46 % Zeilen, +122 % Bytes) | ✅ Mehr Tiefe, Quellen, Diagramme |

## 3. Was beide Varianten gleich gut leisten

- Alle Kernfakten aus Turns 26–32 vollständig (Werte, Kombinationen, Ursachen, Korrekturen)
- 4 Mermaid-Diagramme (Normal) bzw. 4 (Streng) — ähnliche Abdeckung der Zusammenhänge
- Deutscher Erklärungstext, technische Namen englisch, Entscheidungen als Festlegungen
- Ehrliche Kennzeichnung offener Punkte

## 4. Erkenntnis / Einordnung für die Zukunft

1. **Die strenge Variante kostet ~2–3× so viel Aufwand** (Faktenbasis doppelt so groß, Recherche, 3 Validierungsstufen, Protokolle) und produziert ein **deutlich größeres und tieferes Dokument**.
2. **Der wichtigste Mehrwert ist die Fehler-Absicherung:** Die strenge Variante deckte eine echte Diskrepanz auf (`LED_EFFECT=5` nur chat-only) und verifizierte die Chat-Zitate wörtlich gegen die offizielle Quelle. Die Normal-Variante hätte `LED_EFFECT=5` ungeprüft als Fakt übernommen.
3. **Wann lohnt sich welche Variante:**
   - **Normal:** Wenn der Chat selbst die Primärquelle ist, keine externen Behauptungen enthält, und das Ziel eine Betriebs-/Projekt-Doku ist (wie Kapitel 1–12).
   - **Streng:** Wenn Chat-Aussagen Hardware-/Protokoll-Fakten betreffen (wie hier die ReSpeaker-Schnittstelle), die gegen offizielle Doku geprüft werden können — oder wenn Marco die höhere Sicherheit explizit will.
4. **Faustregel für künftige Sonderkapitel:** Bei hardwarenahen Werten/Protokollen → streng; bei rein projektinternen Design-Themen → normal reicht.
