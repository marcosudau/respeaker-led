# Sonderkapitel I: DOA (Direction of Arrival)

**Projekt:** LED-Controller (LEFX Schema V2) mit ReSpeaker XVF3800 USB 4-Mic Array
**Dokumenttyp:** Fachkapitel, Runde 1 (Doku-Schreiber, Einzel-Lauf mit schärferen Bedingungen)
**Datum:** 2026-08-02
**Faktenbasis:** `sonderkapitel_doa_bereich.md` (Chat-Verlauf Turns 26–32 + Online-Recherche)

> **Lesehinweis zur Kennzeichnung:** Jeder Befund ist nach folgendem Muster gekennzeichnet:
> - **Chat-Befund** = Beobachtung/Aussage aus dem Projekt-Chat (Turns 26–32, Quelle [Q6]).
> - **Quelle (validiert)** = Aussage aus einer online recherchierten, geprüften Quelle (Teil B der Faktenbasis, Quellen [Q1]–[Q5]).
> - **Bewertung/Empfehlung** = Einordnung und Handlungsempfehlung, wie sie der Faktenbasis zu entnehmen ist.
>
> Was in der Faktenbasis **nicht** steht, wird hier nicht ergänzt, sondern als offener Punkt gekennzeichnet (siehe Abschnitt 10).

---

## 1. Zweck dieses Sonderkapitels

Dieses Kapitel dokumentiert das Thema **DOA (Direction of Arrival)** für das LED-Controller-Projekt: die Richtungserkennung des ReSpeaker XVF3800, alle damit verbundenen Messwerte, die LED-Steuerung und die im Projekt beobachteten Verhaltensweisen.

Anlass war ein konkretes Fehlerbild: Der DOA-Effekt „stand immer nur auf einer Richtung", bewegte sich nicht, während andere Effekte einwandfrei funktionierten (Chat-Befund, Turn 26). Die Analyse in den Turns 26–32 führte zu einer Reihe von Erkenntnissen über die Wertegrundlage, die Abtastrate, USB-Grenzen und das Verhalten des internen LED-Effekts des ReSpeakers.

Das Kapitel erfüllt die folgenden verbindlichen Anforderungen (Teil D der Faktenbasis):

1. **Alle genannten Werte** (Teil C.1) werden in Bezug auf den DOA-Effekt und die Erkennung erklärt — verständlich für jemanden, der das System nicht kennt.
2. **Alle auftauchenden Kombinationen von Werten** (Teil C.2) und deren Bewertung werden dargestellt, soweit dem Chat zu entnehmen.
3. **Online-recherchierte Fakten** werden nur mit exakten Quellenangaben übernommen (Teil B; Quellen [Q1]–[Q5], Abrufdatum 2026-08-02).
4. Das gesamte Thema DOA wird erklärt: Beamforming-System des XVF3800, die unterschiedlichen Erkennungsmöglichkeiten (`DOA_VALUE`, `AEC_AZIMUTH_VALUES` + `AEC_SPENERGY_VALUES`, `AUDIO_MGR_SELECTED_AZIMUTHS`, interner LED-Effekt) und ihr Zusammenhang.
5. **Offene Punkte/Unsicherheiten** (Teil C.3) werden ehrlich gekennzeichnet (Abschnitt 10).

---

## 2. Was ist DOA und wie funktioniert die Richtungserkennung?

### 2.1 Grundbegriff: Direction of Arrival

**DOA (Direction of Arrival)** bedeutet „Ankunftsrichtung": die Richtung, aus der ein Schallsignal (z. B. eine Stimme) an einem Mikrofon-Array eintrifft. Ein Mikrofon-Array (mehrere räumlich versetzte Mikrofone) kann aus den winzigen Laufzeit- und Pegelunterschieden zwischen den einzelnen Mikrofonen berechnen, aus welcher Richtung der Schall kommt — typischerweise als **Azimutwinkel in Grad** (0–359°).

Der ReSpeaker XVF3800 USB 4-Mic Array ist ein professionelles **4-Mikrofon-Array** mit XMOS XVF3800-Prozessor und bietet AEC (Echo-Unterdrückung), AGC (Automatische Verstärkungsregelung), **DoA**, Beamforming, VAD (Voice Activity Detection), Noise Suppression, De-Reverberation und **360°-Sprachaufnahme (bis zu 5 m)** [Q5]. Die 4 Mikrofone sind **kreisförmig** angeordnet (quadratische Geometrie), wodurch der volle Bereich von **0–360°** abgedeckt wird [Q5].

> **Einordnung für das Projekt:** Der LED-Ring des ReSpeakers ist die sichtbare Ausgabe dieser Richtungserkennung: Die LED in der Richtung, aus der aktuell gesprochen wird, leuchtet auf. Das Projekt (LED-Controller, LEFX Schema V2) bildet diese Anzeige durch eigene Effekte nach, die auf denselben oder ähnlichen Messwerten aufbauen.

### 2.2 Das Beamforming-System des XVF3800

Beamforming ist die Technik, mit der das Array „Strahlen" (Beams) formt, die auf einzelne Sprecher gerichtet werden. Sie reduziert unerwünschte Geräusche und Nachhall, indem sie Signale aus anderen Richtungen abschwächt [Q1][Q2].

Das XVF3800-System besteht laut offizieller Dokumentation aus drei sich ergänzenden Beam-Arten [Q1][Q2]:

- **Free running beam** (frei laufender Strahl): Scannt die Umgebung kontinuierlich, identifiziert mögliche Sprecher und **schaltet einen der beiden Focused Beams auf diese Richtung**.
- **Focused beam 1 und 2** (fokussierte Strahlen): Zwei Beams, die auf erkannte Sprecherpositionen ausgerichtet werden. Sie aktualisieren sich **relativ langsam** [Q2].
- **Auto selected beam** (automatisch ausgewählter Strahl): In normalem Betrieb wählt die Audio-Pipeline automatisch das **beste Signal** für den Ausgang. Der Auto selected beam ist dabei der „durchgereichte" beste Beam [Q1][Q2].

> **Quelle (validiert):** „the system uses an array of beams to focus on speakers, reducing unwanted sounds and reverberation… The XVF3800 employs a free-running beam that scans the environment, identifies potential speakers, and switches one of the two focused beams to that direction. During normal operation, the audio processing pipeline automatically selects the best signal for output (Auto selected beam)." [Q1]

> **Quelle (validiert) — Audio-Mux (Kontext):** Der Audio-Mux legt fest, welcher Beam als Ausgang dient. Kategorie 6, Quelle 3: „The 'auto-select' beam; chooses the best of the previous three beams as an output, recommended option" — der Auto selected beam wählt also das Beste aus den drei vorherigen Beams (Focused 1, Focused 2, Free running) als Ausgang [Q2].

> **Quelle (validiert) — Umschaltverhalten:** „The auto selection algorithm will switch between beams rapidly in some circumstances. The two focused beams update relatively slowly, but the free running beam is designed to be sensitive so that it can rapidly pick up the speech signal for a new talker entering the soundscape. As a result it can also pick up any noise signals present." [Q2] — Der Free running beam ist bewusst empfindlich (auch für Rauschen), damit neue Sprecher schnell erfasst werden.

### 2.3 Aufbau des Beam-Systems (Diagramm)

```mermaid
flowchart LR
    subgraph ARRAY["Mikrofon-Array (kreisförmig, quadratische Geometrie, 0–360°) [Q5]"]
        M1["Mic 1"] --- M2["Mic 2"] --- M3["Mic 3"] --- M4["Mic 4"]
    end

    subgraph BF["Beamforming-Subsystem (XVF3800) [Q1][Q2]"]
        FRB["Free running beam<br/>(scannt Umgebung, findet Sprecher,<br/>bewusst empfindlich)"]
        FB1["Focused beam 1<br/>(langsame Aktualisierung)"]
        FB2["Focused beam 2<br/>(langsame Aktualisierung)"]
        ASB["Auto selected beam<br/>(wählt bestes Signal der 3 Beams)"]
        FRB -->|"schaltet auf Sprecherrichtung"| FB1
        FRB -->|"schaltet auf Sprecherrichtung"| FB2
        FB1 --> ASB
        FB2 --> ASB
        FRB --> ASB
    end

    ARRAY --> BF
    ASB --> OUT["Audio-Ausgang<br/>(Audio-Mux, Quelle 3)<br/>+ Richtungs-/Energiewerte"]
    ASB --> DOA_DISP["Interne DOA-LED-Anzeige<br/>(nutzt Auto selected beam) [Q1]"]
```

**Wichtigste Aussage für das Projekt:** Die **interne DOA-LED-Anzeige des ReSpeakers nutzt den Auto selected beam** — den vierten Wert von `AEC_AZIMUTH_VALUES` [Q1]. Das ist die dokumentierte Wertegrundlage des Original-Effekts, den das Projekt nachbauen möchte.

---

## 3. Die Beam-Werte: `AEC_AZIMUTH_VALUES` und `AEC_SPENERGY_VALUES`

### 3.1 `AEC_AZIMUTH_VALUES` — Azimutwinkel der vier Beams

> **Quelle (validiert):** `AEC_AZIMUTH_VALUES` (Read Only, 4 Params, radians): „The command outputs four values: Focused beam 1, Focused beam 2, Free running beam, Auto selected beam. Each value represents the azimuth angle of the corresponding beam, provided in both radians and degrees. **The DoA indication uses the last value (Auto selected beam).**" [Q1]

Beispiel aus der README: `AEC_AZIMUTH_VALUES 0.91378 (52.36 deg) 0.00000 (0.00 deg) 1.57080 (90.00 deg) 0.91378 (52.36 deg)` [Q1] — hier hat der Auto selected beam (vierter Wert) denselben Azimut wie Focused beam 1 (52,36°).

> **Quelle (validiert) — Koordinatensystem:** Das Koordinatensystem hängt von der Hardware-Konfiguration ab: **lineare Konfiguration nur 0–180°, quadratische Konfiguration 0–360°** [Q2]. Beim Projekt liegt die kreisförmige (quadratische) Anordnung vor → **0–360°** [Q5].

**Bedeutung für DOA-Effekt und Erkennung:**
- `AEC_AZIMUTH_VALUES[0]` = Azimut Focused beam 1 (Radians)
- `AEC_AZIMUTH_VALUES[1]` = Azimut Focused beam 2 (Radians)
- `AEC_AZIMUTH_VALUES[2]` = Azimut Free running beam (Radians)
- `AEC_AZIMUTH_VALUES[3]` = **Azimut Auto selected beam** — die dokumentierte Grundlage der internen DOA-Anzeige [Q1]

### 3.2 `AEC_SPENERGY_VALUES` — Speech-Energie der vier Beams

> **Quelle (validiert):** `AEC_SPENERGY_VALUES` (Read Only, 4 Params): „Speech Energy is a value that indicates whether speech is present in the beam as well as the amplitude, which is similar to VAD (Voice Activity Detection). **Non-zero spenergy means that the beam probably contains speech. Higher values indicate louder or closer speech**, however noise, echo and reverb can cause the energy level to decrease." [Q1] Die Reihenfolge ist identisch: Focused beam 1, Focused beam 2, Free running beam, Auto selected beam [Q1][Q2].

Beispiel aus der README: `AEC_SPENERGY_VALUES 2080656 0 2083455 2080656` [Q1] — Focused beam 2 hat hier Energie 0 (kein Sprachsignal), die übrigen Beams haben hohe Energie.

**Bedeutung für DOA-Effekt und Erkennung:**
- `AEC_SPENERGY_VALUES[0..2]` = Speech-Energie von Focused beam 1/2 und Free running beam
- `AEC_SPENERGY_VALUES[3]` = **Speech-Energie des Auto selected beam**: Wert > 0 = erkannte Aktivität; höhere Werte ≈ lauteres/näheres Signal. Rauschen, Echo und Nachhall können den Energiewert absenken [Q1][Q2].

> **Bewertung/Empfehlung (Chat-Befund, Turn 30):** Der vierte Wert von `AEC_SPENERGY_VALUES` passt zur Wanduhr-Beobachtung (siehe Abschnitt 9): Wert über null = erkannte Aktivität → Anzeige einschalten; Energie fehlt → ausblenden. Als Ziel-Kombination für den Nachbau des internen Effekts werden `AEC_AZIMUTH_VALUES[3]` (Richtung) + `AEC_SPENERGY_VALUES[3]` (Aktivität) empfohlen, mit kurzer Haltezeit von ~100–200 ms und anschließendem Ausblenden.

### 3.3 Der Auto selected beam als zentrale Größe

Zusammenfassend: Der **Auto selected beam** ist der Beam, den die Firmware selbst als bestes Signal ausgewählt hat. Er liefert:
- **Richtung:** `AEC_AZIMUTH_VALUES[3]` — Azimut des ausgewählten Beams
- **Aktivität:** `AEC_SPENERGY_VALUES[3]` — Speech-Energie dieses Beams

Genau diese beiden Werte sind die Grundlage der internen DOA-LED-Anzeige [Q1] und damit das Referenzverhalten, das der Projekt-Effekt nachbilden soll.

---

## 4. `DOA_VALUE` als Anwendungsschnittstelle (Winkel + VAD-Flag)

### 4.1 Definition und Format

`DOA_VALUE` ist die für Anwendungen gedachte, **zusammengefasste** Schnittstelle zur Richtungserkennung:

> **Quelle (validiert):** Aus der offiziellen Datei `xvf_host.py`:
> ```python
> "DOA_VALUE": (20, 18, 2, "ro", "uint16", "Get the doa value and if speech is detected, payload[0] = doa value, from 0 to 359, payload[1] = 1 if speech is detected, 0 if not"),
> ```
> [Q3]

> **Chat-Befund (Turn 26):** Die im Chat verwendete Definition ist **wörtlich identisch** mit der offiziellen Datei [Q3]: `payload[0]` = DOA-Wert 0–359 (Grad), `payload[1]` = 1 wenn Sprache erkannt, 0 wenn nicht.

> **Chat-Befund (Turn 32):** In der Parameteransicht der offiziellen ReSpeaker-App steht ausdrücklich: `DOA_VALUE — uint16 x2 — DoA value [0..359] and VAD flag`.

### 4.2 Was die beiden Werte bedeuten

- **`DOA_VALUE[0]`** = vereinfachter Richtungswinkel in Grad (0–359) — die Richtung, aus der aktuell (zuletzt) Schall erkannt wurde.
- **`DOA_VALUE[1]`** = **VAD-Flag (Voice Activity Detection)**: 1 = Sprachaktivität erkannt, 0 = keine. Der zweite Wert ist **kein** Ergebnis einer Spracherkennung (Speech-to-Text), sondern ein reines Aktivitäts-Flag [Chat T32].

> **Bewertung/Empfehlung (Chat-Befund, Turn 32):** `DOA_VALUE` scheint die praktische, zusammengefasste Schnittstelle für Anwendungen zu sein („Winkel + VAD-Flag"). Es ist nicht zwingend nötig, sofort auf die ausführlichen AEC-Wertesätze umzusteigen; die AEC-Werte (`AEC_AZIMUTH_VALUES`, `AEC_SPENERGY_VALUES`) sollten zunächst nur zusätzlich **diagnostisch** verglichen werden.

### 4.3 Zusammenhang der Werte (Übersicht)

> **Chat-Befund (Turn 32):**
> ```text
> AEC_AZIMUTH_VALUES[3]  → genauer Winkel des ausgewählten Beams
> AEC_SPENERGY_VALUES[3] → Energie dieses Beams
> DOA_VALUE[0]           → vereinfachter Winkel für Anwendungen
> DOA_VALUE[1]           → vereinfachtes VAD-Flag
> ```

```mermaid
flowchart LR
    subgraph FW["Firmware intern (XVF3800)"]
        ASB["Auto selected beam"]
        AZ["Azimut des Beams"]
        EN["Speech-Energie des Beams"]
        ASB --> AZ
        ASB --> EN
    end

    AZ --> AEC_AZ["AEC_AZIMUTH_VALUES[3]<br/>(genauer Winkel, Radians)"]
    EN --> AEC_SP["AEC_SPENERGY_VALUES[3]<br/>(Energie, &gt; 0 = Aktivität)"]
    ASB -->|"vereinfacht für Anwendungen"| DOA0["DOA_VALUE[0]<br/>(Winkel 0–359)"]
    EN -->|"vereinfacht für Anwendungen"| DOA1["DOA_VALUE[1]<br/>(VAD-Flag 0/1)"]
    ASB --> AUDIO1["AUDIO_MGR_SELECTED_AZIMUTHS[1]<br/>(Azimut Auto-select-Beam)"]
```

> **Offener Punkt:** Ob `DOA_VALUE` intern exakt aus dem Auto selected beam abgeleitet wird, ist offiziell **nicht garantiert** — nur abgeleitet möglich (siehe Abschnitt 10, Punkt 4).

---

## 5. Weitere Erkennungswerte und Systemzustände

### 5.1 `AUDIO_MGR_SELECTED_AZIMUTHS` — kombinierter Sprecher-Azimut

> **Quelle (validiert):** Das XVF3800 „computes an additional azimuth value which combines speech energy and azimuths to provide a single value which indicates the direction and presence of a speaker. This value can be read using the command `AUDIO_MGR_SELECTED_AZIMUTHS`. The command returns 2 values, the first of which is the processed azimuth which will be NAN if there is no speech, otherwise it will be the azimuth of the current speaker. The second is the current azimuth of the auto select beam." [Q2]

- **`AUDIO_MGR_SELECTED_AZIMUTHS[0]`** = verarbeiteter Azimut: **NAN (keine Zahl), wenn keine Sprache vorhanden**, sonst Azimut des aktuellen Sprechers. Dieser Wert kombiniert Speech-Energie und Azimute zu einem einzigen „Sprecher vorhanden + Richtung"-Signal [Q2].
- **`AUDIO_MGR_SELECTED_AZIMUTHS[1]`** = aktueller Azimut des Auto-select-Beams [Q2].

> **Einordnung:** Dies ist eine dritte, noch stärker zusammengefasste Erkennungsmöglichkeit: ein einzelner Wert, der Richtung **und** Präsenz (via NAN) in sich trägt — im Vergleich zu `DOA_VALUE` die am stärksten zusammengefasste Schnittstelle, wenn man Sprache-Erkennung und Richtung in einem Zugriff braucht (Einordnung, nicht wörtlich in der Quelle belegt). In der Faktenbasis gibt es keine Aussage dazu, dass das Projekt diesen Wert verwendet; er wird hier vollständigkeitshalber als Teil des Gesamtsystems dokumentiert.

> **Hinweis (nicht DOA-spezifisch):** Für bekannte, feste Sprecherpositionen existiert zusätzlich ein Fixed-Beam-Modus (`AEC_FIXEDBEAMSAZIMUTH_VALUES`, `AEC_FIXEDBEAMSELEVATION_VALUES`, `AEC_FIXEDBEAMSONOFF`, `AEC_FIXEDBEAMNOISETHR`, `AEC_FIXEDBEAMSGATING`). Bei aktivem Gating werden Fixed Beams mit niedriger Speech-Energie gemutet; nur ein Fixed Beam ist gleichzeitig aktiv. Dabei kann „the azimuth angle provided by the DoA function" von den festen Beam-Azimuten abweichen, da er von den Messungen des akustischen Pfads abhängt [Q2]. Dieser Modus wird im Projekt-Chat nicht verwendet und ist hier nur der Vollständigkeit halber aufgeführt.

### 5.2 Monitorwerte der ReSpeaker-App (Screenshot, Turn 32)

> **Chat-Befund (Turn 32, Monitorwerte aus der App):**
> ```text
> Direction of arrival: 266°
> Voice activity: Active
> Max beam energy: 26426.47
> Beam 1: 26426.47
> Beam 3: 26426.47
> ```

Bedeutung der einzelnen Monitorwerte:
- **Direction of arrival: 266°** — aktuell gemeldete Schallrichtung.
- **Voice activity: Active** — VAD-Status (entspricht dem VAD-Flag aus `DOA_VALUE[1]`).
- **Max beam energy: 26426.47** — höchste Speech-Energie über alle Beams.
- **Beam 1 / Beam 3: 26426.47** — Energiewerte einzelner Beams (gleicher Wert, siehe Kombination 3 in Abschnitt 7.3).

### 5.3 RT60 und AEC-Status

> **Chat-Befund (Turn 32):** Die offizielle Konsole überwacht bei 30 Hz gleichzeitig DOA, VAD, vier Beam-Energien, **RT60** und **AEC-Status** — das bestätigt, dass 30-Hz-Telemetrie mit Firmware **2.0.10** vorgesehen ist.

- **RT60** = Nachhallzeit (Reverberation Time), ein akustischer Raumparameter; wird von der Konsole mitüberwacht. *(Einordnung: Ein direkter Einfluss auf die Projekt-Effektlogik ist in der Faktenbasis nicht belegt.)*
- **AEC-Status:** `AEC converged: No` ist **allein kein DOA-Fehler** — es betrifft primär die Echo-Unterdrückung und die Far-End-Referenz, nicht die Richtungserkennung [Chat T32].

### 5.4 `detection_state` — der Effekt-Zustand im Projekt

- **`detection_state`** ist ein String-Wert in der Projekt-Implementierung: `"sound"` (Aktivität erkannt) bzw. `"none"` (keine Aktivität) [Chat T26/T32].
- **Chat-Befund (Turn 26/32):** Die damalige Implementierung meldete dem Effekt **immer** `"detection_state": "sound"` — `payload[1]` (das VAD-Flag) wurde vollständig ignoriert.
- **Bewertung/Empfehlung:** Korrektur laut Turn 32: `DOA_VALUE[1] = 0` → `detection_state="none"`, `DOA_VALUE[1] = 1` → `detection_state="sound"`; ohne VAD die Richtungsanzeige transparent machen (Details in Abschnitt 9).

---

## 6. LED-Steuerung

### 6.1 Übersicht der LED-Parameter

| Wert/Kommando | Typ/Format | Bedeutung (in Bezug auf DOA-Effekt und Erkennung) | Quelle |
|---|---|---|---|
| `LED_RING_COLOR` | 12 × uint32 = 48 Byte | Kompletter Ringpuffer: Farbe jeder der 12 LEDs; **ein** USB-Transfer, alle 12 Farben zwingend zusammen | [Q3], Chat T26 |
| `LED_EFFECT` | uint8 | Effektmodus: 0 = off, 1 = breath, 2 = rainbow, 3 = single color, **4 = doa**; Wert 5 („frei gesetzter Ringmodus") nur laut App, nicht in der README | [Q1] (Werte 0–4), Chat T32 (Wert 5) |
| `LED_DOA_COLOR` | 2 × uint32 | Farben des DOA-Modus: erster Wert = Base Color (Grundring), zweiter Wert = DOA/Highlight-Farbe (Richtungs-LED). Beispiel aus der App: Base `#002040`, Highlight `#00C066` | [Q1], Chat T32 |
| `LED_SPEED` | uint8 | Effektgeschwindigkeit primär für **breath und rainbow**; Wert 8 ist daher wahrscheinlich **nicht** die Reaktionsgeschwindigkeit der DOA-Auswertung | [Q1], Chat T32 |
| `LED_BRIGHTNESS` | uint8 | Helligkeit für breath/rainbow | [Q1] |
| `LED_GAMMIFY` | uint8 | Gamma-Korrektur 0/1 | [Q1] |
| `LED_COLOR` | uint32 | Farbe für breath und single color | [Q1] |

### 6.2 Detailbeschreibung der DOA-relevanten Parameter

**`LED_RING_COLOR`** (12 × uint32 = 48 Byte):
- **Chat-Befund (Turn 26):** „Set the LED color of ring mode, each value is the color of one LED" — wörtlich identisch mit der offiziellen `xvf_host.py`-Definition [Q3].
- **Chat-Befund (Turn 29):** `LED_RING_COLOR` ist **ein** USB-Transfer mit zwingend allen 12 Farben (`12 × uint32 = 48 Byte`). Es gibt **keine** Möglichkeit, nur einzelne LEDs zu aktualisieren. Sobald sich eine LED ändert, muss der vollständige Ringpuffer übertragen werden.
- **Bewertung/Empfehlung:** Die Frame-Diff-Optimierung (Abschnitt 8.4) entscheidet, ob der komplette Puffer übertragen wird oder nicht.

**`LED_EFFECT`**:
- **Quelle (validiert):** „Set the LED effect mode, 0 = off, 1 = breath, 2 = rainbow, 3 = single color, **4 = doa**" [Q1].
- **Chat-Befund (Turn 32):** `LED_EFFECT = 4` → interner DOA-Modus; `LED_EFFECT = 5` → „frei gesetzter Ringmodus" (nur aus App-Screenshots; offiziell nicht in der README belegt — offener Punkt, Abschnitt 10).
- Standardverhalten des Geräts: „By default, reSpeaker XVF3800 runs rainbow mode when boot, and then switch to doa mode after 2 seconds." [Q1]

**`LED_DOA_COLOR`** (2 × uint32):
- **Quelle (validiert):** „Set the LED color of doa mode, the first value is the base color and the second value is the doa color" [Q1].
- **Chat-Befund (Turn 32):** Base color `#002040` (dunkler Grundring), Highlight `#00C066` (grüne Hervorhebung) → Grundring + bei VAD-Aktivität hervorgehobene Richtung.

**`LED_SPEED`**:
- **Quelle (validiert):** „Set the effect speed of breath and rainbow mode" [Q1].
- **Bewertung (Chat T32):** Da `LED_SPEED` primär für Breath und Rainbow gedacht ist, ist der in der App gesetzte Wert 8 wahrscheinlich **nicht** die Reaktionsgeschwindigkeit der DOA-Auswertung. Die Reaktionsgeschwindigkeit des DOA-Modus ist über `LED_SPEED` nicht belegt.

### 6.3 Persistenz und Flash

- **`SAVE_CONFIGURATION` / `CLEAR_CONFIGURATION`:** speichert bzw. löscht alle schreibbaren Parameter im Flash [Q1].
- **Chat-Befund (Turn 32):** Die Audioeinstellungen (Abschnitt 7.11) vorerst **nicht verändern**, insbesondere **nicht auf „Save to Flash" klicken** — sonst werden Testwerte dauerhaft im Gerät gespeichert.
- **Chat-Befund (Turn 29):** `LED_RING_COLOR` schreibt nur den aktuellen LED-Puffer, `DOA_VALUE` liest nur einen flüchtigen Laufzeitwert; es findet **kein Flash-Schreiben** statt → kein relevanter Speicher-Verschleiß bei hohen Abfrageraten.

---

## 7. Wertekombinationen und ihre Bewertung

Alle im Chat aufgetretenen Kombinationen (Teil C.2 der Faktenbasis) mit Befund und Bewertung:

| Nr. | Kombination | Chat-Befund | Bewertung/Empfehlung |
|---|---|---|---|
| 1 | `DOA_VALUE[0]` + `DOA_VALUE[1]` (Winkel + VAD) | VAD wurde ignoriert, letzter Winkel blieb stehen | Wahrscheinlichste Ursache des „Festhängens"; VAD auswerten, ohne VAD ausblenden |
| 2 | `AEC_AZIMUTH_VALUES[3]` + `AEC_SPENERGY_VALUES[3]` (Auto-selected beam) | Wertegrundlage des internen Effekts | Zielkombination für den Nachbau, mit Haltezeit 100–200 ms |
| 3 | Beam-Energie-Gleichheit (Beam 1 = Beam 3) | Gleicher Energiewert 26426.47 | Deutung: Beam 1 als bester Beam ausgewählt und auf Beam 3 durchgereicht |
| 4 | `DOA_VALUE` vs. `AEC_*`-Werte | DOA_VALUE = vereinfachte Schnittstelle | Erst mit DOA_VALUE arbeiten, AEC-Werte diagnostisch vergleichen |
| 5 | 12-LED-Ring + Winkelquantisierung | 81°→88°→95° wählt ggf. dieselbe LED | 30°/LED; Interpolation macht kleine Änderungen sichtbar |
| 6 | Abtastrate + Renderloop | Pull an Renderframes gekoppelt | Exakte Zwischenraten unmöglich; 50 ms ≈ 15 Hz testen |
| 7 | USB-Gesamtlast | ~60 Control-Transfers/s bei 30 Hz | Datenmenge winzig; seriell ausführen |
| 8 | Frame-Diff + Layer-Komposition | Engine rechnet alle Layer zusammen | Nur geänderte Gesamtframes senden; spart bei Bewegung wenig |
| 9 | 30 Hz + drei Bedingungen | Konsole bietet 30 Hz | Kein Parallelzugriff, 1 Abfrage/Frame, seriell |
| 10 | Haltezeit (70–150 bzw. 100–200 ms) | Wanduhr-Beispiel: kurzes Aufblinken | Kurze Haltezeit + Ausblenden bildet internen Effekt nach |
| 11 | Audioeinstellungen | Beeinflussen DSP-Bewertung | Nicht ohne Not ändern, kein „Save to Flash" |
| 12 | `LED_EFFECT=4` + `LED_DOA_COLOR` | Interner DOA-Modus mit Base/Highlight | `LED_EFFECT=5` nur Chat-Beobachtung, nicht README |

### 7.1 Kombination 1: `DOA_VALUE[0]` + `DOA_VALUE[1]` (Winkel + VAD-Flag)

- **Chat-Befund (Turn 32):** Aktuelle (damalige) Implementierung: `payload[0]` → Winkel, `payload[1]` → ignorieren, `detection_state` → immer `"sound"`. **Sehr wahrscheinliche Ursache für den Festhänge-Eindruck:** Wenn kein relevantes Geräusch aktiv ist, behält `payload[0]` offenbar einfach die zuletzt erkannte Richtung.
- **Bewertung:** VAD=1 → Richtung anzeigen; VAD=0 → Anzeige ausblenden. Korrektur: `0` → `detection_state="none"`, `1` → `detection_state="sound"`; ohne VAD die Richtungsanzeige transparent machen [Chat T32].

### 7.2 Kombination 2: Auto-selected beam — Richtung + Energie (`AEC_AZIMUTH_VALUES[3]` + `AEC_SPENERGY_VALUES[3]`)

- **Chat-Befund (Turn 30):** Der interne ReSpeaker-DOA-Modus arbeitet direkt innerhalb der Firmware; laut offizieller Dokumentation verwendet die eingebaute DOA-Anzeige den **vierten Wert von `AEC_AZIMUTH_VALUES`**, also den Auto selected beam [Q1]. `AEC_SPENERGY_VALUES[3]` beschreibt die Speech-Energie dieses Beams: Wert über null = erkannte Aktivität; höhere Werte ≈ lauteres/näheres Signal.
- **Bewertung:** Dies ist die **Wertegrundlage des internen Effekts** und die empfohlene Zielkombination für den Nachbau: `AEC_AZIMUTH_VALUES[3]` als Richtung, `AEC_SPENERGY_VALUES[3]` als Aktivität, mit kurzer Haltezeit ~100–200 ms, dann ausblenden [Chat T30].

### 7.3 Kombination 3: Beam-Energie-Gleichheit (Beam 1 = Beam 3)

- **Chat-Befund (Turn 32, Monitorwerte):** `Beam 1: 26426.47` und `Beam 3: 26426.47` — identische Energiewerte.
- **Bewertung:** Beam 3 ist laut offizieller Dokumentation der Auto-selected beam. Dass Beam 1 = Beam 3 ist, bedeutet vermutlich: **Beam 1 wurde aktuell als bester Beam ausgewählt und auf Beam 3 (Auto selected) durchgereicht.** Die interne DOA-Anzeige verwendet genau diesen Auto-selected beam [Chat T32]. Gestützt wird diese „durchgereichte"-Interpretation durch die Audio-Mux-Dokumentation: Der Auto-select-Beam „chooses the best of the previous three beams as an output" [Q2].

### 7.4 Kombination 4: `DOA_VALUE` vs. `AEC_*`-Werte

- **Chat-Befund (Turn 32):** `DOA_VALUE` scheint die praktische, zusammengefasste Schnittstelle für Anwendungen zu sein; nicht zwingend sofort auf die ausführlichen AEC-Wertesätze wechseln.
- **Bewertung:** `DOA_VALUE` = vereinfachte Anwendungsschnittstelle (Winkel + VAD-Flag); `AEC_AZIMUTH_VALUES`/`AEC_SPENERGY_VALUES` = ausführliche Rohwerte (Richtung + Energie aller vier Beams). Empfehlung: **erst mit `DOA_VALUE` arbeiten**, `AEC_AZIMUTH_VALUES` und `AEC_SPENERGY_VALUES` zunächst nur zusätzlich diagnostisch vergleichen [Chat T32].

### 7.5 Kombination 5: 12-LED-Ring + Winkelquantisierung

- **Chat-Befund (Turn 28):** 12 LEDs → 360°/12 = **30° pro LED**. Winkel 81°→88°→95° kann weiterhin dieselbe LED wählen → der Effekt sieht festgefahren aus, obwohl sich der DOA-Wert laufend ändert. Erklärt einen erheblichen Teil der wahrgenommenen Schwerfälligkeit (Hardware-Problem ausgeschlossen: der darunterliegende State dreht sich weiter).
- **Bewertung:** Kleine Winkeländerungen innerhalb desselben 30°-Sektors bleiben unsichtbar. Vorschlag aus Turn 28: **Richtungsindikator zwischen zwei benachbarten LEDs interpolieren** — je näher der Winkel an der nächsten LED, desto heller. Das macht kleine Änderungen sichtbar.

### 7.6 Kombination 6: Abtastrate + Renderloop

- **Chat-Befund (Turn 28):** Renderloop = **30 FPS**, ein Durchlauf etwa alle **33 ms**. DOA-Abfrage aktuell `interval_ms=125` → real etwa **7–8 Abfragen pro Sekunde**. **Pull-Abfragen sind an Renderframes gekoppelt** → beliebige Zwischenraten nicht exakt möglich. Bei `50 ms` → praktisch eher ~15 Hz (Prüfung nur alle 33 ms). `interval_ms=0` → eine Abfrage pro Frame → maximal ~30 Hz.
- **Bewertung:** Exakte Zwischenraten (z. B. 20 Hz) sind mit der Pull-Kopplung nicht erreichbar. Empfehlung Turn 28: testweise **50 ms (~15 Hz)**; nicht direkt auf 30 Abfragen/s gehen.

### 7.7 Kombination 7: USB-Gesamtlast

- **Chat-Befund (Turn 28/29):** 30 LED-Schreibvorgänge + 30 DOA-Lesevorgänge = **~60 USB-Control-Transfers/s**. Datenmenge winzig (~1,4 KB/s bei 30 FPS, unkritisch); kritischer sind ReSpeaker-Verarbeitung, USB-Latenzen und die serielle Ausführung im Renderthread. Der Treiber hat einen sehr großzügigen Timeout und **bis zu 100 Wiederholungsversuche** → ein problematischer Transfer kann den Renderloop länger blockieren.
- **Bewertung:** Relevant sind die **Anzahl der Control-Transfers** und die **Firmware-Verarbeitungszeit**, nicht die Datenmenge. Lesen/Schreiben seriell ausführen, USB-Laufzeiten und Fehler protokollieren [Chat T29].

### 7.8 Kombination 8: Frame-Diff + Layer-Komposition

- **Chat-Befund (Turn 29):** Frame-Diff-Optimierung umgesetzt als:
  ```python
  if frame.leds == previous_leds:
      return
  device.write("LED_RING_COLOR", frame.leds)
  previous_leds = list(frame.leds)
  ```
  Wirkung: statischer Ring → nach dem ersten Frame keine weiteren LED-Transfers; langsame quantisierte Animation → identische Zwischenframes übersprungen; flüssige Animation → weiterhin bis zu 30 Transfers/s.
- **Einordnung:** Im aktuellen Test dreht sich der darunterliegende State weiter; die Engine rechnet erst **alle Layer zusammen** und sendet dann den vollständigen Endframe → diese Optimierung spart dort nur wenig. Empfehlung: identische Gesamtframes nicht erneut übertragen [Chat T29].

### 7.9 Kombination 9: 30 Hz + drei Bedingungen

- **Chat-Befund (Turn 31):** In der offiziellen ReSpeaker-App kann man bis **30 Hz** Live-Telemetrie auswählen — starkes Indiz, dass der ReSpeaker regelmäßige Telemetrieabfragen mit 30 Hz verträgt. Die App liest nicht nur einen Winkel, sondern gleichzeitig DOA, Voice Activity und Beam-Energien. **30 DOA-Abfragen/s sind grundsätzlich plausibel und geräteseitig vorgesehen.** Keine Beschädigung zu erwarten; schlimmstenfalls verzögerte Frames, USB-Retries oder vorübergehend hängender Service.
- **Drei Bedingungen (Chat-Befund Turn 31):**
  1. **ReSpeaker Console und LED-Controller dürfen nicht gleichzeitig zugreifen** — genau solche parallelen Prozesse hatten bereits `USBError: Entity not found`-Fehler verursacht.
  2. **Nur eine Hardwareabfrage pro Frame** — theoretisch könnte jedes aktive Pull-Overlay seinen Provider separat aufrufen (bei mehreren DOA-Overlays: 60–90 USB-Abfragen). Der Provider soll zentral pro Renderframe cachen und allen Effekten denselben Messwert liefern.
  3. **DOA-Lesen und LED-Schreiben seriell lassen** — keine konkurrierenden USB-Threads, keine unkontrollierte Warteschlange.
**Ziel-Einstellung (Chat-Befund Turn 31):**

| Parameter | Zielwert |
|---|---|
| Renderfrequenz | 30 Hz |
| DOA-Abfrage | einmal pro Renderframe |
| Maximale DOA-Reads | 30 pro Sekunde |
| LED-Ausgabe | nur bei verändertem Gesamtframe |
| Provider-Cache | ein Messwert pro Frame für alle DOA-Effekte |

- **Bewertung:** Die offizielle App verwendet neben der Richtung ausdrücklich **Voice Activity** und **Beam Energy** → Aktivität und Richtung müssen **gemeinsam** ausgewertet werden [Chat T31].

### 7.10 Kombination 10: Haltezeit

- **Chat-Befund (Turn 30/32):** Optional sehr kurze Haltezeit von **~70–150 ms** (Turn 32) bzw. **~100–200 ms** (Turn 30, Ziel-Provider-Kombination). Die Haltezeit hält die Richtungsanzeige kurz nach dem letzten erkannten Signal sichtbar, bevor sie ausblendet (Erläuterung, nicht wörtlich im Chat belegt).
- **Bewertung:** Kurze Haltezeit + Ausblenden bildet das Verhalten des internen Effekts nach — Wanduhr-Beispiel: Der Sekundenzeiger lässt die LED **einmal pro Sekunde kurz aufblinken** [Chat T30].

### 7.11 Kombination 11: Audioeinstellungen

- **Chat-Befund (Turn 32):** Noise Suppression, AGC, Echo Suppression und Double-talk Sensitivity können beeinflussen, **was der DSP als Aktivität oder guten Beam bewertet**.
- **Bewertung:** Vorerst **nicht verändern**; insbesondere nicht auf **„Save to Flash"** klicken. `AEC converged: No` ist allein kein DOA-Fehler (betrifft primär Echo-Unterdrückung und Far-End-Referenz) [Chat T32].

### 7.12 Kombination 12: `LED_EFFECT=4` + `LED_DOA_COLOR`

- **Chat-Befund (Turn 32):** `LED_EFFECT = 4` → interner DOA-Modus; `LED_DOA_COLOR` → Base color `#002040` + Highlight `#00C066` → Grundring + bei VAD-Aktivität hervorgehobene Richtung.
- **Quelle (validiert):** `LED_EFFECT` 4 = doa [Q1]; `LED_DOA_COLOR`: erster Wert = Base Color, zweiter = DOA-Farbe [Q1].
- **Bewertung:** `LED_EFFECT=5` („frei gesetzter Ringmodus") ist nur eine Chat-Beobachtung aus den App-Screenshots und **nicht** in der öffentlichen README dokumentiert (dort nur 0–4) → offener Punkt (Abschnitt 10).

---

## 8. Abtastrate, Renderloop und USB-Grenzen

### 8.1 Renderloop und Abtastraten im Überblick

| Einstellung | Real erreichbare Abfragefrequenz | Erklärung |
|---|---|---|
| Renderloop | 30 FPS (~33 ms pro Durchlauf) | fester Takt des Effekt-Renderings [Chat T28] |
| `interval_ms = 125` | ~7–8 Abfragen/s | Ausgangszustand der Fehleranalyse [Chat T28] |
| `interval_ms = 50` | praktisch ~15 Hz | Prüfung nur alle 33 ms möglich; empfohlener Testwert [Chat T28] |
| `interval_ms = 0` | 1 Abfrage pro Frame → max. ~30 Hz | Obergrenze der Pull-Abfragen [Chat T28] |

- **Chat-Befund (Turn 28):** Pull-Abfragen sind an Renderframes gekoppelt → **beliebige Zwischenraten sind nicht exakt möglich**. Eine „20-Hz"-Einstellung lässt sich über die Frame-Kopplung nicht sauber realisieren.

### 8.2 Was bei Überschreitung der Grenzen passiert (Kaputtgehen?)

- **Chat-Befund (Turn 29):** Physischer Hardwaredefekt **sehr unwahrscheinlich**. `DOA_VALUE` liest nur einen flüchtigen Laufzeitwert, `LED_RING_COLOR` schreibt den aktuellen LED-Puffer; **kein Flash-Schreiben** → kein relevanter Speicher-Verschleiß.
- **Mögliche Folgen zu hoher Rate:** Service erreicht FPS nicht mehr; LED-Animationen ruckeln/verzögern; USB-Transfers liefern Retry, Timeout oder Stall; ReSpeaker reagiert zeitweise nicht und muss evtl. per USB neu verbunden werden; im ungünstigsten Fall blockiert der Renderthread längere Zeit [Chat T29].
- **Treiber-Verhalten:** Der Treiber wiederholt Firmware-`RETRY` bis zu 100-mal; alles synchron → der Controller bleibt stehen, statt Anfragen aufzustauen (schützt vor unkontrollierter Überlastung, kann aber sichtbaren Stillstand verursachen) [Chat T29].

### 8.3 30 Hz: plausibel, aber nur unter Bedingungen

- **Chat-Befund (Turn 31/32):** 30 Hz Live Telemetry in der offiziellen ReSpeaker Console = starkes Indiz, dass der ReSpeaker 30 Hz verträgt; die Konsole überwacht bei 30 Hz gleichzeitig DOA, VAD, vier Beam-Energien, RT60 und AEC-Status — mit Firmware **2.0.10** vorgesehen. 30 Hz beschädigt nichts, ist aber vermutlich unnötig [Chat T29].
- **Bedingungen für stabilen Betrieb:** (a) kein paralleler Zugriff mit der ReSpeaker Console, (b) genau **eine** Hardwareabfrage pro Frame + Provider-Cache, (c) Lesen und Schreiben seriell [Chat T31] (Details in Abschnitt 7.9).

### 8.4 Frame-Diff-Optimierung

- **Chat-Befund (Turn 29):** `if frame.leds == previous_leds: return` → statischer Ring: nach dem ersten Frame keine weiteren LED-Transfers; langsame quantisierte Animation: identische Zwischenframes übersprungen; flüssige Animation: weiterhin bis zu 30 Transfers/s.
- **Einordnung:** Da die Engine erst alle Layer zusammenrechnet und dann den vollständigen Endframe sendet, spart die Optimierung bei bewegtem State darunter nur wenig [Chat T29].
- **Bewertung:** Identische Gesamtframes nicht erneut übertragen; Datenmenge (~1,4 KB/s) ist unkritisch — relevant sind Transferanzahl und Firmware-Verarbeitungszeit [Chat T29].

### 8.5 Datenfluss: Erkennung → Provider → Effekt (Diagramm)

```mermaid
flowchart LR
    HW["ReSpeaker XVF3800<br/>Firmware 2.0.10"] -->|"USB-Control-Transfer<br/>DOA_VALUE / AEC_*-Werte"| DRV["USB-Treiber<br/>großzügiger Timeout,<br/>bis zu 100 Retries"]
    DRV -->|"max. 1 Abfrage pro Frame"| PROV["DOA-Provider<br/>Cache: ein Messwert pro Frame<br/>für alle DOA-Effekte"]
    PROV -->|"Winkel + VAD/Energie"| FX["Effekt-Layer<br/>VAD-Auswertung, Haltezeit,<br/>Interpolation, detection_state"]
    FX -->|"gefüllte Layer"| RENDER["Renderloop 30 FPS<br/>Layer-Komposition<br/>Frame-Diff: nur geänderte Gesamtframes"]
    RENDER -->|"LED_RING_COLOR<br/>48 Byte (12 × uint32)"| HW
```

---

## 9. Das Verhalten des internen Effekts und der Nachbau

### 9.1 Arbeitsweise des internen Effekts

> **Chat-Befund (Turn 30):**
> ```text
> kurzes Geräusch erkannt
> → Auto-selected beam bestimmt Richtung
> → LED an dieser Richtung kurz einschalten
> → bei fehlender Energie wieder ausblenden
> ```

> **Chat-Befund (Turn 30, Wanduhr-Beispiel):** Der originale Door-Effekt (im ReSpeaker gespeichert) funktioniert richtig gut — „da ist Bewegung drin", Anzeige nur während Geräuschen: Der Sekundenzeiger einer Wanduhr lässt die LED **einmal pro Sekunde kurz aufblinken**.

**Vermutete interne Logik (Chat T32):**
```text
VAD = 1 → Richtung anzeigen
VAD = 0 → Richtungsanzeige ausblenden
```

**Vorteile des internen Effekts (Chat-Befund Turn 30):**
- direkter Zugriff auf interne DSP-/Beamforming-Werte;
- keine USB-Abtastverzögerung;
- vermutlich Aktualisierung mit dem internen Audiotakt (Vermutung — siehe offener Punkt 3, Abschnitt 10.1);
- Zugriff auf den Auto-selected beam;
- Aktivitätsinformationen über die Beam-Energie;
- Anzeige nur während erkannter Aktivität.

### 9.2 Warum der Projekt-Effekt „festhing"

Zwei zusammenwirkende Ursachen (Chat-Befunde):
1. **`payload[1]` (VAD-Flag) wurde ignoriert** und `detection_state` immer auf `"sound"` gesetzt → der zuletzt gemessene Winkel blieb dauerhaft sichtbar, auch wenn kein Geräusch mehr aktiv war (Turn 26/32).
2. **Winkelquantisierung auf 12 LEDs (30°/LED):** Kleine Winkeländerungen (81°→88°→95°) wählen weiterhin dieselbe LED → der Effekt wirkt festgefahren, obwohl sich der DOA-Wert laufend ändert (Turn 28).

### 9.3 Der Nachbau (konkrete Korrektur-Schritte)

> **Chat-Befund (Turn 32, verbindliche nächste Implementierungsschritte):**
> 1. DOA **einmal pro Renderframe** abfragen (bei 30 FPS max. 30 Hz).
> 2. **VAD-Flag nicht mehr ignorieren:** `0` → `detection_state="none"`, `1` → `detection_state="sound"`.
> 3. Ohne VAD die **Richtungsanzeige transparent** machen.
> 4. Optional sehr kurze **Haltezeit ~70–150 ms** anbieten.
> 5. Providerwerte **einmal pro Frame cachen** (auch bei mehreren DOA-Effekten).
> 6. **Identische LED-Gesamtframes nicht erneut übertragen**.
> 7. `AEC_AZIMUTH_VALUES` und `AEC_SPENERGY_VALUES` zunächst nur zusätzlich **diagnostisch** vergleichen.

> **Ziel-Provider (Chat-Befund Turn 30):** Vergleichsprovider, der gleichzeitig protokolliert: `DOA_VALUE`, `AEC_AZIMUTH_VALUES[3]`, `AEC_SPENERGY_VALUES[3]`. Ziel-Provider: `AEC_AZIMUTH_VALUES[3]` als Richtung und `AEC_SPENERGY_VALUES[3]` als Aktivität; **kurze Haltezeit ~100–200 ms, dann ausblenden**.

> **Zusätzlich (Chat-Befund Turn 28):** **Richtungsindikator zwischen zwei benachbarten LEDs interpolieren** — je näher der Winkel an der nächsten LED, desto heller; USB-Lesedauer und Alter des letzten Winkels protokollieren; testweise 50 ms (~15 Hz).

### 9.4 Nachbau-Logik (Diagramm)

```mermaid
flowchart TD
    A["DOA einmal pro Renderframe abfragen<br/>(Provider-Cache, max. 30 Hz)"] --> B{"VAD-Flag<br/>(bzw. Beam-Energie > 0)?"}
    B -->|"1 = sound"| C["Richtung anzeigen<br/>detection_state = sound"]
    C --> D["Haltezeit<br/>70–150 ms (DOA_VALUE)<br/>100–200 ms (AEC-Provider)"]
    D --> E["Interpolation zwischen<br/>benachbarten LEDs<br/>(30°-Quantisierung auflösen)"]
    E --> A
    B -->|"0 = none"| F["detection_state = none<br/>Richtungsanzeige transparent / ausblenden"]
    F --> A
```

---

## 10. Offene Punkte und Quellenlage

### 10.1 Offene Punkte (aus Teil C.3 der Faktenbasis, ehrlich gekennzeichnet)

| Nr. | Offener Punkt | Status/Kennzeichnung |
|---|---|---|
| 1 | **`LED_EFFECT = 5`** („frei gesetzter Ringmodus") | Nur Chat-Beobachtung aus App-Screenshots (Turn 32); in der öffentlichen README **nicht** dokumentiert (dort nur 0–4) — vermutlich firmware-/app-spezifisch (Firmware 2.0.10). **Als Chat-Beobachtung kennzeichnen, nicht als Quelle belegt.** |
| 2 | **`respeaker_get_doa.py`-Legacy-Konvention** | Das offizielle Beispielskript deklariert `DOA_VALUE` mit **Länge 4** (statt 2 wie `xvf_host.py`) und liest `result[3]` als SPEECH_DETECTED, `result[1]` als DOA_VALUE. Hinweis: Die `read()`-Methode fügt 1 Status-Byte hinzu (`length = data[2] + 1`) und liefert bei uint16 `response.tolist()` → die Indizes 1/3 deuten auf einen zusätzlichen Status-Offset. **Maßgeblich für die Projekt-Implementierung ist die `xvf_host.py`-Variante (Länge 2, Indizes 0/1); die Skript-Variante ist eine abweichende Legacy-Konvention.** Expliziter Prüfpunkt der Quellenvalidierung. |
| 3 | **Interne Aktualisierungsrate des Effekts** | „Vermutlich Aktualisierung mit dem internen Audiotakt" — im Chat nur vermutet, **nicht verifiziert**. |
| 4 | **`DOA_VALUE` = Auto-selected beam?** | `DOA_VALUE` kann intern durchaus aus demselben Beamforming-System abgeleitet sein; die Dokumentation **garantiert aber nicht**, dass es exakt derselbe Wert mit demselben Aktualisierungs-/Aktivitätsverhalten ist. Dokumentiert ist ausdrücklich nur der Auto-selected beam als Grundlage der internen LED-Anzeige. → als offen kennzeichnen. |
| 5 | **Zwei Haltezeit-Angaben** | Turn 30 nennt 100–200 ms (AEC-Provider), Turn 32 nennt 70–150 ms (DOA_VALUE-Variante). Die Faktenbasis enthält keine abschließende Festlegung, welcher Wert maßgeblich ist; beide sind als Option dokumentiert. |

### 10.2 Quellenlage

Die Faktenbasis unterscheidet strikt zwischen:
- **Chat-Befunden** (Turns 26–32, Quelle [Q6]) — Projektbeobachtungen, Implementierungsdetails, Bewertungen;
- **Online-recherchierten, validierten Fakten** ([Q1]–[Q5], abgerufen 2026-08-02) — offizielle Dokumentation des Herstellers und XMOS.

Validierungsergebnisse der Quellen:
- Die im Chat (Turn 26) zitierten Definitionen von `DOA_VALUE` und `LED_RING_COLOR` sind **wörtlich identisch** mit der offiziellen `xvf_host.py` [Q3]. ✅
- Die README listet für `LED_EFFECT` nur 0–4; der Chat-Wert 5 ist dort **nicht** belegt → Chat-Beobachtung (offener Punkt 1). 
- Das Beam-System (Free running beam, Focused beams, Auto selected beam) ist in README [Q1] und XMOS-Doku [Q2] konsistent beschrieben; die Audio-Mux-Doku [Q2] bestätigt die „durchgereichte"-Interpretation von Beam 1 → Beam 3.
- Der Ablauf der Quellenprüfung selbst (inklusive der Legacy-Abweichung von `respeaker_get_doa.py`, offener Punkt 2) ist Teil der geforderten Quellen-Validierung.

---

## 11. Quellenverzeichnis

Alle Quellen abgerufen am **2026-08-02**.

| Kürzel | Quelle | URL |
|---|---|---|
| [Q1] | ReSpeaker XVF3800 USB 4-Mic Array — Offizielle Host-Control-Dokumentation (GitHub README, `host_control/README.md`) | https://github.com/respeaker/reSpeaker_XVF3800_USB_4MIC_ARRAY/blob/master/host_control/README.md |
| [Q2] | XMOS XVF3800-Dokumentation, Version 3.2.1 — Using the Host Application (Beamforming-Subsystem, `AEC_AZIMUTH_VALUES`, `AEC_SPENERGY_VALUES`, `AUDIO_MGR_SELECTED_AZIMUTHS`, Audio-Mux) | https://www.xmos.com/documentation/XM-014888-PC/html/modules/fwk_xvf/doc/user_guide/03_using_the_host_application.html |
| [Q3] | Offizielles Host-Skript `xvf_host.py` (python_control) — Definitionen von `DOA_VALUE` und `LED_RING_COLOR` | https://github.com/respeaker/reSpeaker_XVF3800_USB_4MIC_ARRAY/blob/master/python_control/xvf_host.py |
| [Q4] | Offizielles Beispielskript `respeaker_get_doa.py` (python_control) — abweichende Legacy-Konvention (Länge 4, Indizes 1/3) | https://github.com/respeaker/reSpeaker_XVF3800_USB_4MIC_ARRAY/blob/master/python_control/respeaker_get_doa.py |
| [Q5] | Seeed Studio Wiki — ReSpeaker XVF3800 USB 4-Mic Array (Produktübersicht: 4-Mic-Array, 360°-Sprachaufnahme bis 5 m, Firmware-Beispiele) | https://wiki.seeedstudio.com/respeaker_xvf3800_introduction |
| [Q6] | Projekt-Chat-Verlauf LEFX Schema V2, Turns 26–32 (`chat_history_lefx_schema_v2---db0c18aa-4ee2-4ce5-94d3-e38e01bf80a5.md`, Z. 3151–3555) | intern (Projektarchiv) |

**Ergänzender Verweis innerhalb von [Q1]:** DoA-Winkeldiagramm des Herstellers: https://github.com/respeaker/reSpeaker_XVF3800_USB_4MIC_ARRAY/blob/master/doc/doa.jpg

---

*Ende des Sonderkapitels I: DOA. Erstellt auf Basis der Faktenbasis `sonderkapitel_doa_bereich.md`; nichts über die Faktenbasis hinaus ergänzt; alle Unsicherheiten gemäß Teil C.3 als offene Punkte gekennzeichnet.*
