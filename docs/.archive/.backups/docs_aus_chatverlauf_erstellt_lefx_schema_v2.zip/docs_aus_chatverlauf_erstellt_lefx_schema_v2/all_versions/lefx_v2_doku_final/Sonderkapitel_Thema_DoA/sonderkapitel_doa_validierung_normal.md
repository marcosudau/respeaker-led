# Validierung — Sonderkapitel I: DOA (Normal-Variante)

**Geprüfte Datei:** `sonderkapitel_doa_doku_normal_runde1.md` (356 Zeilen, 19 858 B)
**Referenz:** `sonderkapitel_doa_bereich_normal.md` (126 Zeilen, 13 359 B) — nur Chat-Fakten Turns 26–32
**Prüfer:** Haupt-Assistent (Standard-Validierung wie bei Kapiteln 1–12: Fakten-Check + Qualitäts-Check)
**Datum:** 2026-08-02

---

## 1. Fakten-Check

| Prüfpunkt | Ergebnis |
|---|---|
| Parameteransicht `DOA_VALUE` + `LED_RING_COLOR` (Adresse/Größe/Typ/Beschreibung) | ✅ §2.1, wörtlich |
| Debug-Logging (Sample, ungültige Payloads, Speech-Flag nicht ausgewertet, 166 Tests, nichts committet) | ✅ §2.2 |
| Service-Cleanup Turn 27 (23:15:57, Ports 8765–8770, Jobobjekt, `os._exit()`, 167 Tests) | ✅ §1.1 |
| Renderloop 30 FPS / 33 ms | ✅ §4.1 |
| Abtastraten 125 ms ≈ 7–8 Hz / 50 ms ≈ 15 Hz / 0 ≈ max. 30 Hz; Pull an Frames gekoppelt | ✅ §4.1 |
| USB-Grenzen: ~60 Transfers/s, ~1,4 KB/s, 100 Retries, 48 Byte/Transfer, synchron | ✅ §4.2, §4.3 |
| Frame-Diff-Code + 3 Szenarien + „Engine rechnet alle Layer zusammen" | ✅ §4.4 |
| 12 LEDs = 30°/LED; 81°→88°→95°; Interpolation | ✅ §3 (U2), §7 (O1) |
| VAD-Flag ignoriert → detection_state immer „sound" → letzte Richtung bleibt | ✅ §3 (U1/U3), §5.6 |
| Auto-selected beam (`AEC_AZIMUTH_VALUES[3]` + `AEC_SPENERGY_VALUES[3]`) | ✅ §5.2 |
| Vorteile interner Effekt (7 Punkte) | ✅ §5.3 |
| Verhalten interner Effekt (Geräusch → Richtung → LED → ausblenden) | ✅ §5.4 |
| Monitorwerte 266° / Active / 26426.47 / Beam 1 = Beam 3 | ✅ §5.7 |
| `LED_EFFECT` 4/5, `LED_DOA_COLOR` #002040/#00C066, `LED_SPEED` (breath/rainbow) | ✅ §5.8 |
| Audioeinstellungen, „Save to Flash", `AEC converged: No` | ✅ §5.9 |
| Drei 30-Hz-Bedingungen (kein Parallelzugriff, 1 Abfrage/Frame + Cache, seriell) | ✅ §6.2 |
| Ziel-Einstellungen (30 Hz, 1×/Frame, 30 Reads/s, Frame-Diff, Provider-Cache) | ✅ §6.1 |
| 7 konkrete Korrekturschritte (VAD, Haltezeit 70–150 ms, Cache, Frame-Diff, AEC diagnostisch) | ✅ §6.3 |
| 30-Hz-Begründung (App, Firmware 2.0.10) | ✅ §6.6 |
| Entscheidungen A1–A5 als Festlegungen | ✅ §6.5 |
| Gliederung 1–7 exakt eingehalten | ✅ |
| **Keine Erfindungen** (keine Online-Werte: `AUDIO_MGR_SELECTED_AZIMUTHS`, FixedBeam, XMOS, GitHub, Seeed, `SAVE_CONFIGURATION`, `GAMMIFY`, doa.jpg, 0–180° — alle 0 Treffer) | ✅ |

**Fakten-Check: BESTANDEN** — alle Chat-Fakten vollständig und korrekt, keine Zusatzinhalte.

## 2. Qualitäts-Check

| Prüfpunkt | Ergebnis |
|---|---|
| Deutscher Text, Feldnamen englisch | ✅ |
| Keine Dialogform / „Ich" | ✅ |
| Tabellen (14): Parameter, Kennzeichnungen, Ursachen, Abtastraten, USB-Folgen, Frame-Diff-Szenarien, Wertezusammenhang, Monitorwerte, Vergleich intern/extern, Ziel-Einstellungen, 3 Bedingungen, Korrekturliste, Festlegungen, Offene Punkte | ✅ |
| Mermaid-Diagramme (4): Ursache-Wirkung, Verhalten interner Effekt, Datenfluss extern/intern, Ziel-Datenfluss | ✅ |
| Code-Fences geschlossen (4 Mermaid + 1 Python + 2 Text-Blöcke) | ✅ |
| Entscheidungen A1–A5 als Festlegungen mit „wird umgesetzt" | ✅ |
| Offene Punkte (O1–O9) ehrlich aus Chat-Fakten abgeleitet | ✅ |

**Qualitäts-Check: BESTANDEN** — keine Runde 2 nötig; Fassung als Vergleichsbasis geeignet.

## 3. Fazit

Die Normal-Variante ist inhaltlich vollständig und sauber — sie erklärt das DOA-Thema allein aus den Chat-Fakten, ohne externe Absicherung. Sie ist damit der direkte Vergleichspartner zur strengen Variante (`sonderkapitel_doa_doku_final.md`). Siehe Vergleichsdokument `sonderkapitel_doa_vergleich_streng_vs_normal.md`.
