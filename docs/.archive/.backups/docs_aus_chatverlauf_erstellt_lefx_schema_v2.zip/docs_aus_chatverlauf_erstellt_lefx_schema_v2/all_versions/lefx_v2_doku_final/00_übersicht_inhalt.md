# LEFX Schema V2 – Dokumentation: Inhaltsübersicht

**Inhaltsverzeichnis** der freigegebenen Dokumentation zum LED-Controller (LEFX Schema V2).
Alle zwölf Kapitel sind inhaltlich freigegeben und liegen als Final-Fassungen in diesem Ordner. Die Kapitelüberschriften verlinken auf die jeweilige Datei; darunter steht die Gliederung des Kapitels.

---

## Gesamtstruktur

```text
docs/
├── index.md
├── getting_started.md
├── api_guide.md
├── cli_guide.md
├── troubleshooting.md
├── effects.md
│
├── effect-system/          → die 12 Kapitel (01–12)
├── effect-development/     → Templates, Tutorials, Snippets
├── examples/               → effects/
├── dev/                    → index, architecture, build, public_entry_points
├── planning/               → nur tatsächlich offene Planungen (z. B. v3/)
└── archive/                → historische Dokumente, strikt getrennt
```

**Grundsätze:**

- Aktuelle Dokumentation, aktive Planung und historisches Archiv sind strikt getrennt.
- Kapitel 3 (Layer und Komposition) steht bewusst vor Kapitel 4 (Typen und Lebenszyklen).
- Push und Pull sind Bezugsmodi für Runtime-Eingaben, keine Overlay-Untertypen.
- Freie Parametrisierung steht vor optionalen Presets.
- Alle alten Dokumentationsdateien werden vollständig archiviert (auch leere, doppelte oder abgelöste Zwischenstände).

---

## [Kapitel 1: Überblick und Grundidee](01_überblick_und_grundidee.md)

**Ziel:** Das System grundsätzlich verstehen, ohne bereits Schemafelder, Commands oder Layerdetails zu kennen.

1. Was ist das Effektsystem?
2. Warum wurde die Logik getrennt?
3. Das mentale Grundmodell
4. Drei Typen, vier Lebenszyklusformen
5. Verantwortungsgrenzen
6. Ein vollständiger Datenfluss
7. Artefakte in einem Satz
8. Nächste Einstiege

---

## [Kapitel 2: Begriffe und Systemobjekte](02_begriffe_und_systemobjekte.md)

**Ziel:** Eindeutig unterscheiden können, ob von einer bearbeitbaren Quelle, einem gebauten Paket, einer Definition, einer Konfiguration oder einer laufenden Instanz die Rede ist.

1. Warum feste Begriffe notwendig sind
2. Die Objektkette (Quelle → Paket → Definition → Instanz)
3. LEFX-Quelle
4. LEFX-Paket
5. Definition
6. Preset
7. Konfiguration und Runtime-Eingaben
8. Steuerungskommando
9. Laufende Instanz
10. Overlay-Channel
11. Layer
12. LEFXSET
13. IDs und Namensräume
14. Sprachregel „Effekt“
15. Veraltete Begriffe

---

## [Kapitel 3: Layer und Komposition](03_layer_und_komposition.md)

**Ziel:** Verständlich zeigen, wie laufende Instanzen angeordnet, ersetzt, aktualisiert und beendet werden. *(Auf Marcos Wunsch vor Kapitel 4 gezogen: Layerprinzip als Grundlage für das Typenverständnis.)*

1. Layer als interne Engine-Struktur
2. Prioritätsstapel
3. Background State und Primary State
4. Setzen, Ersetzen und Löschen eines States
5. Lifecycle eines kontrollierten Overlays
6. Lifecycle eines zeitgesteuerten Overlays
7. Event-Queue
8. Transparenz und Komposition
9. Rückkehr zum darunterliegenden Bild
10. Verantwortung der Engine

### Layer-Stapel (von oben nach unten)

```text
Event                  (EVENT_LAYER)
Controlled Overlay     (ONGOING_OVERLAY_LAYER)
Timed Overlay          (TEMP_OVERLAY_LAYER)
Primary State          (STATE_LAYER)
Background State       (BACKGROUND_STATE_LAYER)
```

---

## [Kapitel 4: Typen und Lebenszyklen](04_typen_und_lebenszyklen.md)

**Ziel:** Sicher entscheiden können, welcher Typ und welcher Lebenszyklus zur jeweiligen Anzeige passt.

1. Vergleichsmatrix aller Lebenszyklusformen
2. State
3. Kontrolliertes Overlay (Push/Pull als Bezugsmodi)
4. Zeitgesteuertes Overlay
5. Event
6. Entscheidungshilfe
7. Ungültige Kombinationen

### Lebenszyklus-Matrix

| Typ | Modus | Laufzeit | Runtime-Eingaben |
|---|---|---|---|
| State | immer kontrolliert | unbestimmt | nein |
| Overlay | `controlled` | unbestimmt | ja |
| Overlay | `timed` | endlich | nein |
| Event | fest vorgegeben | endlich | nein |

---

## [Kapitel 5: Schema V2](05_schema_v2.md)

**Ziel:** Verbindliche technische Referenz für jede gültige Definition.

1. Zweck des Schemas
2. Aufbau einer `EffectDefinition`
3. Identität und Metadaten
4. Typ und Overlay-Modus
5. Konfigurationsschema
6. Runtime-Input-Schema
7. Defaults
8. Capabilities
9. Layer-Regeln
10. Farbmodell und Komposition
11. Animation und Richtung
12. Input-Sampling
13. Bedingte Pflichtfelder
14. Übergreifende Invarianten
15. Ungültige Kombinationen
16. Verweis auf vollständige Beispiele

---

## [Kapitel 6: Parameter und Werte](06_parameter_und_werte.md)

**Ziel:** Erklären, welche Werte Definitionen anbieten, wie Eingaben benutzerfreundlich angenommen und intern strikt vereinheitlicht werden.

1. Aufgabe eines Parameters
2. Konfigurationsauflösung
3. Verpflichtende und optionale Werte
4. Standardparameter
5. Farbmodelle
6. Komfortnotationen und Aliase
7. Kanonische interne Werte
8. Grenzen und Validierungsfehler

### Konfigurationsauflösung

```text
Definition-Defaults → Preset → explizite Werte des Steuerungskommandos
→ Validierung und Kanonisierung
```

---

## [Kapitel 7: Runtime-Eingaben](07_runtime_eingaben.md)

**Ziel:** Den vollständigen Datenweg kontrollierter Overlays erklären, ohne Push und Pull zu Untertypen aufzuwerten.

1. Konfiguration gegenüber Runtime-Eingabe
2. Warum nur kontrollierte Overlays veränderliche Eingaben besitzen
3. Overlay-Channel
4. Push als Bezugsmodus
5. Pull als Bezugsmodus
6. Sampling-Intervall
7. Heartbeat und Karenzzeit
8. Input-Health
9. Fehlende Werte und `None`
10. DoA-Datenfluss
11. Verantwortungsgrenze zur Integration

---

## [Kapitel 8: Pakete, IDs und Presets](08_pakete_ids_und_presets.md)

**Ziel:** Erklären, wie Definitionen verpackt, identifiziert, vorkonfiguriert und zu Sets zusammengestellt werden.

1. Quelle gegenüber gebautem Paket
2. Anatomie eines LEFX-Pakets
3. Source-ID
4. Package-ID
5. Definition-ID
6. Qualifizierte ID
7. Preset-ID
8. Globale Namensräume
9. Preset-Auflösung
10. LEFXSET
11. Thematische Paketsets
12. Versionen und Kompatibilität

---

## [Kapitel 9: Bedienung über CLI und API](09_bedienung_cli_api.md)

**Ziel:** Ein einheitliches Bedienmodell erklären, ohne CLI und HTTP als zwei verschiedene Systeme erscheinen zu lassen.

1. Steuerungskommando als gemeinsames Modell
2. Verb-zuerst-Grammatik
3. State-Kommandos
4. Overlay-Kommandos
5. Event-Kommandos
6. Aktivierungsmodus
7. Listen und Detailabfragen
8. HTTP-Entsprechungen
9. Validierungsfehler und Vorschläge

### Kanonische Kommandos

```text
set state      clear state
set overlay    update overlay    clear overlay
emit event
list           show
```

---

## [Kapitel 10: Validierung und Build](10_validierung_und_build.md)

**Ziel:** Den Weg von einer bearbeitbaren Quelle zu einem geprüften Distributionspaket erklären.

1. Qualitätsgrenze des Builds
2. Quellenvalidierung
3. Import- und Strukturprüfung
4. Schema- und Vertragsprüfung
5. Smoke-Render
6. LEFX-Build
7. Paketverifikation
8. LEFXSET aus vorgebauten LEFX-Paketen
9. Standard-Build
10. Cache und Cleanup
11. Typische Fehler

### Build-Pipeline

```text
Quelle → validieren → importieren → Vertrag prüfen → Probe-Frame rendern
→ LEFX bauen → LEFX verifizieren → optional in LEFXSET aufnehmen
```

---

## [Kapitel 11: Architekturgrenzen](11_architekturgrenzen.md)

**Ziel:** Verbindlich festlegen, welche Logik in Paket, Engine, Integration und Schnittstelle gehört.

1. Verantwortungsmatrix
2. Autarkie eines LEFX-Pakets
3. Aufgaben der Engine
4. Aufgaben von Integrationen
5. Aufgaben von CLI und API
6. Erlaubte Abhängigkeiten
7. Lokale Hilfsmodule und Assets
8. Threads, I/O und Laufzeitgrenzen
9. Verbotene Kopplungen
10. Gültige und ungültige Beispiele

---

## [Kapitel 12: Status und Ausblick](12_status_und_ausblick.md)

**Ziel:** Klar trennen zwischen umgesetzt, verifiziert, noch offen und nur als Zukunftsidee vorgemerkt.

1. Status von LEFX V2
2. Umgesetzte Kernfunktionen
3. Verifizierte Bereiche
4. Bewusst offene Arbeiten
5. Stand der DoA-Integration
6. Überarbeitung des produktiven Effektkatalogs
7. Kompatibilitätsgrenzen
8. Mögliche V3-Themen
9. Verweis auf das historische Archiv

### Statusmatrix

| Status | Bedeutung |
|---|---|
| Implementiert | Bestandteil des aktuellen Systems |
| Verifiziert | durch automatisierte oder praktische Prüfung bestätigt |
| Offen | gehört grundsätzlich noch zur aktuellen Ausbaustufe |
| V3-Idee | nicht beschlossen und nicht Teil von V2 |

---

## [Anhang A: Zielstruktur von `docs`](12_status_und_ausblick.md)

Zielstruktur des `docs`-Verzeichnisses mit `effect-system/`, `effect-development/`, `examples/`, `dev/`, `planning/` und `archive/` – enthalten in Kapitel 12.

## [Anhang B: Bereinigungs- und Migrationsverfahren](12_status_und_ausblick.md)

Verfahren zur vollständigen Archivierung aller alten Dokumentationsdateien (auch leerer, doppelter oder abgelöster Zwischenstände) mit Migrationstabelle – enthalten in Kapitel 12.

---

*Alle Kapitel 1–12 sind laut Dokumentationsfahrplan inhaltlich freigegeben. Die Original-Final-Dateien (`kapitelN_doku_final.md`) liegen im übergeordneten Verzeichnis; dieser Ordner enthält die gebündelte, umbenannte Fassung.*
